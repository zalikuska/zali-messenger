import Foundation

struct WebAssets {

    // MARK: - Inline HTML (with embedded CSS + JS)

    static let html = #"""
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <style id="zali-base-style">
:root {
    --lime: #cbff00;
    --lime-dim: rgba(203,255,0,.1);
    --lime-glow: rgba(203,255,0,.25);
    --lime-soft: rgba(203,255,0,.06);
    --bg: #090b0e;
    --sidebar: rgba(11,13,16,.9);
    --text: #f2f2f2;
    --text2: rgba(255,255,255,.5);
    --text3: rgba(255,255,255,.25);
    --border: rgba(255,255,255,.07);
    --red: #ff4d6d;
    --accent-rgb: 203,255,0;
    --r-msg: 18px;
    --contact-suggest-bg: rgba(8,10,14,.98);
    --contact-suggest-border: rgba(255,255,255,.18);
    --contact-suggest-shadow: 0 22px 48px rgba(0,0,0,.42);
    --contact-suggest-max-h: 340px;
    --contact-suggest-pad: 12px;
    --contact-suggest-gap: 8px;
    --contact-suggest-item-pad-y: 12px;
    --contact-suggest-item-pad-x: 12px;
    --contact-suggest-font: 14px;
    --contact-suggest-hint: rgba(255,255,255,.58);
    --msg-gap: 2;
    --control-h: 40px;
    --control-h-sm: 40px;
}

* {
    box-sizing: border-box;
}

html,
body {
    width: 100%;
    height: 100%;
    margin: 0;
    overflow: hidden;
    background: var(--bg);
    color: var(--text);
    font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", "Segoe UI", system-ui, sans-serif;
    font-size: 14px;
    letter-spacing: 0;
    scrollbar-color: rgba(var(--accent-rgb),.45) rgba(255,255,255,.04);
}

::-webkit-scrollbar {
    width: 10px;
    height: 10px;
}

::-webkit-scrollbar-track {
    background: rgba(255,255,255,.03);
}

::-webkit-scrollbar-thumb {
    border: 2px solid rgba(0,0,0,.25);
    border-radius: 999px;
    background: linear-gradient(180deg, rgba(var(--accent-rgb),.82), rgba(var(--accent-rgb),.36));
}

button,
input {
    font: inherit;
}

button {
    border: 0;
}

[hidden] {
    display: none !important;
}

.app {
    width: 100vw;
    height: 100vh;
    display: grid;
    grid-template-rows: 40px 1fr;
    position: relative;
    background:
        radial-gradient(circle at 16% 12%, rgba(var(--accent-rgb),.12), transparent 22%),
        radial-gradient(circle at 72% 18%, rgba(255,255,255,.05), transparent 18%),
        radial-gradient(circle at 50% 120%, rgba(var(--accent-rgb),.08), transparent 28%),
        var(--bg);
}

.app::before {
    content: '';
    position: absolute;
    inset: 0;
    pointer-events: none;
    background-image:
        linear-gradient(rgba(255,255,255,.015) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255,255,255,.015) 1px, transparent 1px);
    background-size: 64px 64px;
    -webkit-mask-image: radial-gradient(circle at center, rgba(0,0,0,.65), transparent 85%);
    mask-image: radial-gradient(circle at center, rgba(0,0,0,.65), transparent 85%);
    opacity: .35;
}

.titlebar {
    display: grid;
    grid-template-columns: 220px 1fr 220px;
    align-items: center;
    min-width: 0;
    padding: 0 14px;
    border-bottom: 1px solid var(--border);
    background: linear-gradient(180deg, rgba(255,255,255,.04), rgba(0,0,0,.22));
    backdrop-filter: blur(16px);
    -webkit-user-select: none;
}

.tb-c {
    min-width: 0;
    text-align: center;
    color: var(--text2);
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
}

.tb-brand {
    color: var(--text);
}

.tb-sep {
    margin: 0 8px;
    color: var(--text3);
}

.tb-chat {
    color: var(--lime);
}

.tb-r {
    display: flex;
    justify-content: flex-end;
}

.ws-pill {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    min-width: 128px;
    height: 26px;
    padding: 0 10px;
    border: 1px solid var(--border);
    border-radius: 999px;
    color: var(--text2);
    font-size: 11px;
    font-weight: 700;
    background: rgba(255,255,255,.03);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04), 0 6px 18px rgba(0,0,0,.18);
}

.ws-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--red);
    box-shadow: 0 0 12px rgba(255, 77, 109, .6);
}

.ws-pill.on .ws-dot {
    background: var(--lime);
    box-shadow: 0 0 12px var(--lime-glow);
}

.body {
    min-height: 0;
    display: grid;
    grid-template-columns: 280px 1fr;
    gap: 16px;
    padding: 16px;
}

.sidebar {
    min-width: 0;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    border: 1px solid var(--border);
    border-radius: 18px;
    background:
        linear-gradient(180deg, rgba(255,255,255,.025), rgba(255,255,255,.01)),
        var(--sidebar);
    box-shadow: 0 14px 36px rgba(0,0,0,.14), inset 0 1px 0 rgba(255,255,255,.02);
    backdrop-filter: blur(8px);
}

.brand {
    padding: 22px 22px 14px;
    color: var(--text);
    font-size: 20px;
    font-weight: 900;
    letter-spacing: .02em;
}

.brand em {
    color: var(--lime);
    font-style: normal;
}

.sidebar-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 22px 18px 14px 22px;
}

.sidebar-head .brand {
    padding: 0;
    white-space: nowrap;
}

.mode-switch {
    display: inline-flex;
    align-items: center;
    padding: 3px;
    border: 1px solid var(--border);
    border-radius: 999px;
    background: rgba(255,255,255,.035);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.03);
}

.mode-btn {
    height: 30px;
    padding: 0 12px;
    border-radius: 999px;
    background: transparent;
    color: var(--text2);
    font-size: 11px;
    font-weight: 900;
    letter-spacing: .08em;
    text-transform: uppercase;
    cursor: pointer;
    transition: background .18s ease, color .18s ease, box-shadow .18s ease, transform .18s ease;
}

.mode-btn:hover {
    color: var(--text);
    background: rgba(255,255,255,.04);
}

.mode-btn.active {
    background: linear-gradient(180deg, rgba(var(--accent-rgb), .98), rgba(var(--accent-rgb), .82));
    color: #050505;
    box-shadow: 0 8px 18px rgba(var(--accent-rgb), .18);
}

.mode-btn:active {
    transform: translateY(1px);
}

.search-wrap {
    position: relative;
    margin: 0 12px 10px;
    padding: 10px 12px 0;
}

.search-icon {
    position: absolute;
    left: 28px;
    top: 50%;
    width: 18px;
    height: 18px;
    transform: translateY(-50%);
    background-color: var(--text2);
    -webkit-mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none'%3E%3Ccircle cx='11' cy='11' r='6.75' stroke='black' stroke-width='2.25'/%3E%3Cpath d='M16.25 16.25L20 20' stroke='black' stroke-width='2.25' stroke-linecap='round'/%3E%3C/svg%3E") center / contain no-repeat;
    mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none'%3E%3Ccircle cx='11' cy='11' r='6.75' stroke='black' stroke-width='2.25'/%3E%3Cpath d='M16.25 16.25L20 20' stroke='black' stroke-width='2.25' stroke-linecap='round'/%3E%3C/svg%3E") center / contain no-repeat;
    opacity: .9;
    pointer-events: none;
}

.search-input {
    width: 100%;
    height: 38px;
    padding: 0 14px 0 48px;
    border: 1px solid var(--border);
    border-radius: 10px;
    outline: none;
    background: linear-gradient(180deg, rgba(255,255,255,.05), rgba(255,255,255,.02));
    color: var(--text);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.03), 0 8px 18px rgba(0,0,0,.08);
    transition: transform .18s ease, border-color .18s ease, box-shadow .18s ease, background .18s ease;
}

.search-input:focus {
    border-color: var(--lime);
    box-shadow: 0 0 0 2px var(--lime-dim);
}

.nav-label {
    padding: 0 18px 8px;
    color: var(--text3);
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
}

.contacts-tools {
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 0 12px 10px;
    padding: 0 12px 10px;
}

.contacts-suggest-wrap {
    display: none;
    padding: 0 16px 8px;
    position: relative;
    z-index: 5;
}

.contacts-suggest-wrap:not([hidden]) {
    display: block;
}

.contacts-suggest-wrap[hidden] {
    display: none !important;
}

.contacts-suggest {
    display: flex;
    flex-direction: column;
    gap: var(--contact-suggest-gap);
    max-height: var(--contact-suggest-max-h);
    overflow: auto;
    padding: var(--contact-suggest-pad);
    border: 1px solid var(--contact-suggest-border);
    border-radius: 12px;
    background: var(--contact-suggest-bg);
    box-shadow: var(--contact-suggest-shadow);
    animation: suggest-drop .18s ease-out;
}

.contact-suggest-item {
    display: grid;
    grid-template-columns: 34px 1fr auto;
    gap: 10px;
    align-items: center;
    width: 100%;
    padding: var(--contact-suggest-item-pad-y) var(--contact-suggest-item-pad-x);
    border: 1px solid transparent;
    border-radius: 10px;
    background: rgba(255,255,255,.05);
    color: var(--text);
    cursor: pointer;
    text-align: left;
    transition: transform .18s ease, background .18s ease, border-color .18s ease;
}

.contact-suggest-item:hover {
    background: rgba(255,255,255,.1);
    border-color: rgba(var(--accent-rgb),.28);
}

.contact-suggest-ava {
    width: 34px;
    height: 34px;
    display: grid;
    place-items: center;
    border-radius: 50%;
    background: var(--lime);
    color: #050505;
    font-size: 12px;
    font-weight: 900;
}

.contact-suggest-meta {
    min-width: 0;
}

.contact-suggest-name {
    font-weight: 800;
    line-height: 1.1;
    font-size: var(--contact-suggest-font);
}

.contact-suggest-hint {
    margin-top: 2px;
    color: var(--contact-suggest-hint);
    font-size: 11px;
}

.contact-suggest-plus {
    color: var(--lime);
    font-size: 20px;
    font-weight: 900;
    line-height: 1;
}

.contact-input {
    flex: 1;
    min-width: 0;
    height: 38px;
    padding: 0 12px;
    border: 1px solid var(--border);
    border-radius: 10px;
    outline: none;
    background: rgba(255,255,255,.03);
    color: var(--text);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.03);
    transition: transform .18s ease, border-color .18s ease, box-shadow .18s ease, background .18s ease;
}

.contact-input:focus {
    border-color: var(--lime);
    box-shadow: 0 0 0 2px var(--lime-dim);
}

.contact-input:disabled {
    opacity: .55;
    cursor: not-allowed;
}

.contact-input:hover {
    background: rgba(255,255,255,.05);
}

.contacts {
    min-height: 0;
    flex: 1;
    overflow-y: auto;
    margin: 0 12px 12px;
    padding: 0 8px 10px;
}

body[data-nav-mode="servers"] .search-wrap,
body[data-nav-mode="servers"] .contacts-tools,
body[data-nav-mode="servers"] .contacts-suggest-wrap {
    display: none;
}

body[data-nav-mode="servers"] .contacts {
    padding: 0 8px 10px;
}

.contact {
    display: grid;
    grid-template-columns: 38px 1fr auto;
    align-items: center;
    gap: 10px;
    min-width: 0;
    min-height: 50px;
    padding: 8px 10px 8px 8px;
    border: 0;
    border-radius: 0;
    background: transparent;
    backdrop-filter: none;
    -webkit-backdrop-filter: none;
    cursor: pointer;
    transition: color .18s ease, opacity .18s ease, background .18s ease, box-shadow .18s ease, transform .18s ease;
    animation: contact-in .26s cubic-bezier(.2,.8,.2,1) both;
}

.contact:hover,
.contact.active {
    background: rgba(255,255,255,.03);
    color: var(--text);
}

.contact.active {
    background: rgba(var(--accent-rgb), .10);
    box-shadow: inset 0 0 0 1px rgba(var(--accent-rgb), .18);
    border-radius: 12px;
    animation: contact-active .24s cubic-bezier(.2,.8,.2,1) both;
}

.contact.active .ava {
    box-shadow:
        0 0 0 1px rgba(var(--accent-rgb), .18),
        0 0 0 4px rgba(var(--accent-rgb), .08);
    animation: avatar-pulse .55s ease-out both;
}

.contact.active .contact-name {
    color: var(--text);
}

.contact.active .contact-prev {
    color: var(--text2);
}

.ava,
.msg-ava,
.chat-hdr-ava {
    position: relative;
    z-index: 1;
    display: grid;
    place-items: center;
    border-radius: 50%;
    overflow: hidden;
    background: var(--lime);
    color: #050505;
    font-weight: 900;
    box-shadow: 0 0 0 1px rgba(255,255,255,.04);
}

.ava {
    width: 38px;
    height: 38px;
}

.contact-info {
    min-width: 0;
}

.avatar-img {
    width: 100%;
    height: 100%;
    display: block;
    object-fit: cover;
    border-radius: inherit;
}

.me-ava {
    cursor: pointer;
}

.me-ava:hover {
    box-shadow:
        0 0 0 1px rgba(255,255,255,.08),
        0 0 0 6px rgba(var(--accent-rgb), .08);
}

.contact-remove {
    width: 24px;
    height: 24px;
    align-self: center;
    justify-self: end;
    border-radius: 50%;
    background: transparent;
    color: var(--text3);
    cursor: pointer;
    font-size: 18px;
    line-height: 1;
    transition: transform .18s ease, color .18s ease, background .18s ease, box-shadow .18s ease;
}

.contact-remove:hover {
    color: var(--red);
    background: rgba(255,255,255,.06);
    box-shadow: 0 0 0 2px rgba(255,77,109,.08);
}

.contact-name {
    overflow: hidden;
    color: var(--text);
    font-size: 13px;
    font-weight: 800;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.contact-prev {
    overflow: hidden;
    margin-top: 3px;
    color: var(--text2);
    font-size: 11px;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.badge {
    min-width: 20px;
    height: 20px;
    padding: 0 6px;
    border-radius: 999px;
    display: grid;
    place-items: center;
    background: var(--lime);
    color: #050505;
    font-size: 10px;
    font-weight: 900;
    animation: badge-pop .22s cubic-bezier(.2,.9,.18,1) both;
}

.server-list {
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: stretch;
    gap: 8px;
}

.server-item {
    position: relative;
    display: grid;
    grid-template-columns: 44px minmax(0, 1fr) auto;
    align-items: center;
    gap: 12px;
    width: 100%;
    min-width: 0;
    min-height: 58px;
    padding: 10px 12px 10px 10px;
    border: 1px solid transparent;
    border-radius: 16px;
    background: transparent;
    color: var(--text);
    cursor: pointer;
    box-shadow: none;
    transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease, background .18s ease, color .18s ease;
    animation: contact-in .26s cubic-bezier(.2,.8,.2,1) both;
}

.server-item:hover {
    background: rgba(255,255,255,.03);
    color: var(--text);
    transform: translateY(-1px);
}

.server-item.active {
    background: rgba(var(--accent-rgb), .10);
    border-color: rgba(var(--accent-rgb), .18);
    box-shadow: inset 0 0 0 1px rgba(var(--accent-rgb), .10);
}

.server-item.active .server-avatar {
    box-shadow:
        0 0 0 1px rgba(var(--accent-rgb), .18),
        0 0 0 4px rgba(var(--accent-rgb), .08),
        0 10px 20px rgba(0,0,0,.16);
}

.server-item.active::before {
    content: '';
    position: absolute;
    left: -8px;
    top: 50%;
    width: 4px;
    height: 22px;
    border-radius: 999px;
    transform: translateY(-50%);
    background: var(--lime);
    box-shadow: 0 0 10px var(--lime-glow);
}

.server-avatar {
    position: relative;
    width: 40px;
    height: 40px;
    display: grid;
    place-items: center;
    border-radius: 50%;
    color: #fff;
    font-size: 18px;
    font-weight: 900;
    text-shadow: 0 1px 2px rgba(0,0,0,.22);
    box-shadow:
        0 0 0 1px rgba(255,255,255,.05),
        0 10px 20px rgba(0,0,0,.16);
}

.server-meta {
    min-width: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 2px;
}

.server-name {
    color: var(--text);
    font-size: 13px;
    font-weight: 800;
    line-height: 1.15;
    word-break: break-word;
}

.server-prev {
    color: var(--text2);
    font-size: 11px;
    line-height: 1.3;
    white-space: normal;
    word-break: break-word;
}

.server-badge {
    align-self: center;
    justify-self: end;
    border: 2px solid var(--sidebar);
}

.server-create {
    background: rgba(255,255,255,.025);
    border-style: dashed;
    color: var(--lime);
}

.server-create-plus {
    width: 40px;
    height: 40px;
    border: 1px dashed rgba(var(--accent-rgb), .22);
    background: rgba(255,255,255,.03);
    color: var(--lime);
    font-size: 24px;
    line-height: 1;
    font-weight: 900;
}

.server-empty {
    display: grid;
    place-items: center;
    min-height: 100%;
    padding: 24px 0;
    text-align: center;
}

.me {
    display: flex;
    align-items: center;
    gap: 10px;
    min-height: 68px;
    margin: 0 12px 12px;
    padding: 12px 14px;
    border-top: 1px solid var(--border);
    background: transparent;
}

.me-info {
    min-width: 0;
    flex: 1;
}

.me-name {
    font-weight: 900;
}

.me-sub {
    margin-top: 2px;
    color: var(--text2);
    font-size: 11px;
}

.online-dot {
    display: inline-block;
    width: 7px;
    height: 7px;
    margin-right: 5px;
    border-radius: 50%;
    background: var(--lime);
}

.online-dot.guest {
    background: #ffcc66;
    box-shadow: 0 0 12px rgba(255, 204, 102, .5);
}

.settings-btn {
    width: 34px;
    height: 34px;
    border-radius: 8px;
    background: rgba(255,255,255,.04);
    color: var(--text);
    cursor: pointer;
    border: 1px solid var(--border);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
    transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease, color .18s ease, background .18s ease;
}

.settings-btn:hover {
    border-color: var(--lime);
    color: var(--lime);
    box-shadow: 0 0 0 2px var(--lime-dim);
}

.main,
.view {
    min-width: 0;
    min-height: 0;
}

.main {
    position: relative;
    overflow: hidden;
    border: 1px solid var(--border);
    border-radius: 18px;
    background:
        linear-gradient(180deg, rgba(255,255,255,.025), rgba(0,0,0,.16)),
        rgba(255,255,255,.01);
    box-shadow: 0 14px 36px rgba(0,0,0,.14), inset 0 1px 0 rgba(255,255,255,.02);
    backdrop-filter: blur(8px);
}

.view {
    position: absolute;
    inset: 0;
    display: none;
}

.view.active {
    display: grid;
    animation: view-enter .24s cubic-bezier(.2,.8,.2,1) both;
}

#viewChat {
    grid-template-rows: auto auto minmax(0, 1fr) auto;
    gap: 20px;
    padding: 16px 16px 2px;
    background: rgba(0,0,0,.12);
}

#viewSettings {
    grid-template-rows: 72px 1fr;
    background: rgba(0,0,0,.16);
}

.chat-hdr,
.logs-bar {
    display: flex;
    align-items: center;
    gap: 12px;
    min-width: 0;
    padding: 0 22px;
    border-bottom: 1px solid var(--border);
    background: rgba(255,255,255,.02);
    backdrop-filter: blur(8px);
    animation: row-fade .24s cubic-bezier(.2,.8,.2,1) both;
}

.chat-hdr-ava {
    width: 42px;
    height: 42px;
}

.chat-hdr-info {
    min-width: 0;
    flex: 1;
}

.chat-hdr-name,
.logs-title {
    color: var(--text);
    font-weight: 900;
}

.chat-hdr-name {
    display: flex;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
}

.chat-hdr-title {
    min-width: 0;
}

.chat-hdr-count {
    flex: 0 0 auto;
    padding: 4px 10px;
    border: 1px solid var(--border);
    border-radius: 999px;
    color: var(--text2);
    background: rgba(255,255,255,.03);
    font-size: 11px;
    font-weight: 800;
    white-space: nowrap;
}

.chat-hdr-sub {
    display: flex;
    flex-direction: column;
    gap: 3px;
    margin-top: 3px;
    color: var(--text2);
    font-size: 12px;
}

.chat-hdr-desc {
    line-height: 1.2;
}

.chat-hdr-key {
    display: inline-block;
    max-width: 100%;
    color: var(--lime);
    font-family: "SF Mono", "Menlo", "Monaco", Consolas, monospace;
    font-size: 10px;
    line-height: 1.3;
    word-break: break-all;
    overflow-wrap: anywhere;
}

.chat-hdr-actions {
    display: flex;
    align-items: center;
    flex: 0 0 auto;
    gap: 8px;
}

#chatHdr:not(.server-mode) .chat-hdr-actions {
    margin-left: auto;
}

.server-settings-btn {
    width: 34px;
    height: 34px;
    border: 1px solid var(--border);
    border-radius: 10px;
    background: rgba(255,255,255,.04);
    color: var(--text);
    cursor: pointer;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
    transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease, color .18s ease, background .18s ease;
}

.chat-call-btn {
    width: 40px;
    font-size: 15px;
}

.server-settings-btn:hover {
    border-color: rgba(var(--accent-rgb), .28);
    background: rgba(var(--accent-rgb), .08);
    box-shadow: 0 0 0 2px var(--lime-dim);
}

#viewChat.server-mode {
    grid-template-rows: auto auto 1fr auto;
}

.server-channel-list {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: nowrap;
    justify-content: flex-start;
    overflow-x: auto;
    overflow-y: hidden;
    padding: 12px 2px 28px;
    margin-right: -2px;
    scrollbar-width: thin;
    scrollbar-color: rgba(var(--accent-rgb), .35) transparent;
    scroll-snap-type: x proximity;
    -webkit-overflow-scrolling: touch;
}

.chat-hdr.server-mode {
    justify-content: flex-start;
    gap: 14px;
}

.chat-hdr.server-mode .server-channel-list {
    margin-left: auto;
    max-width: min(58vw, 860px);
    padding-top: 14px;
    padding-bottom: 28px;
}

.server-channel-list::-webkit-scrollbar {
    height: 8px;
}

.server-channel-list::-webkit-scrollbar-track {
    background: transparent;
}

.server-channel-list::-webkit-scrollbar-thumb {
    background: rgba(var(--accent-rgb), .28);
    border-radius: 999px;
}

.server-channel {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    min-height: 34px;
    padding: 0 12px;
    border: 1px solid var(--border);
    border-radius: 999px;
    background: rgba(255,255,255,.03);
    color: var(--text2);
    cursor: pointer;
    flex: 0 0 auto;
    scroll-snap-align: start;
    transition: transform .18s ease, background .18s ease, border-color .18s ease, color .18s ease, box-shadow .18s ease;
}

.server-channel:hover {
    color: var(--text);
    border-color: rgba(var(--accent-rgb), .18);
    background: rgba(255,255,255,.05);
}

.server-channel.active {
    color: #050505;
    background: linear-gradient(180deg, rgba(var(--accent-rgb), .98), rgba(var(--accent-rgb), .82));
    border-color: rgba(var(--accent-rgb), .36);
    box-shadow: 0 8px 20px rgba(var(--accent-rgb), .22);
}

.server-channel-hash {
    font-size: 11px;
    font-weight: 900;
    opacity: .8;
}

.server-channel-name {
    font-size: 11px;
    font-weight: 900;
    letter-spacing: .02em;
    text-transform: uppercase;
}

.server-channel-hash.voice {
    color: var(--lime);
    font-size: 12px;
}

.voice-panel {
    display: grid;
    gap: 12px;
    padding: 0 16px;
    margin-top: -2px;
}

.voice-room-card {
    display: grid;
    gap: 14px;
    padding: 16px 18px;
    border: 1px solid var(--border);
    border-radius: 18px;
    background:
        radial-gradient(circle at top right, rgba(var(--accent-rgb), .12), transparent 34%),
        rgba(255,255,255,.03);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04), 0 18px 42px rgba(0,0,0,.16);
}

.voice-room-card.active {
    border-color: rgba(var(--accent-rgb), .3);
    box-shadow:
        inset 0 1px 0 rgba(255,255,255,.05),
        0 0 0 1px rgba(var(--accent-rgb), .06),
        0 18px 42px rgba(0,0,0,.16);
}

.voice-room-top {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
}

.voice-room-title {
    color: var(--text);
    font-size: 14px;
    font-weight: 900;
}

.voice-room-sub {
    margin-top: 4px;
    color: var(--text2);
    font-size: 12px;
}

.voice-room-state {
    flex: 0 0 auto;
    padding: 5px 10px;
    border-radius: 999px;
    border: 1px solid var(--border);
    background: rgba(255,255,255,.03);
    color: var(--text2);
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .08em;
}

.voice-room-actions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
}

.voice-meter-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 10px;
}

.voice-meter {
    display: grid;
    gap: 8px;
    padding: 12px 12px 10px;
    border: 1px solid rgba(255,255,255,.08);
    border-radius: 14px;
    background: rgba(255,255,255,.025);
}

.voice-meter-head {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: 10px;
}

.voice-meter-name {
    color: var(--text2);
    font-size: 11px;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: .08em;
}

.voice-meter-value {
    color: var(--text);
    font-size: 11px;
    font-weight: 900;
    letter-spacing: .04em;
}

.voice-meter-track {
    position: relative;
    height: 10px;
    overflow: hidden;
    border-radius: 999px;
    border: 1px solid rgba(255,255,255,.08);
    background:
        linear-gradient(90deg, rgba(255,255,255,.04), rgba(255,255,255,.02)),
        rgba(0,0,0,.22);
}

.voice-meter-fill {
    position: absolute;
    inset: 0 auto 0 0;
    width: 0%;
    border-radius: inherit;
    background: linear-gradient(90deg, rgba(var(--accent-rgb), 1), rgba(var(--accent-rgb), .35));
    box-shadow: 0 0 18px rgba(var(--accent-rgb), .22);
    transition: width .08s linear;
}

.voice-meter-fill.remote {
    background: linear-gradient(90deg, rgba(99, 205, 255, 1), rgba(99, 205, 255, .32));
    box-shadow: 0 0 18px rgba(99, 205, 255, .18);
}

.voice-meter[data-level="0"] .voice-meter-fill {
    opacity: .55;
}

.voice-meter[data-level="0"] .voice-meter-value {
    color: var(--text3);
}

.voice-health {
    display: grid;
    gap: 10px;
}

.voice-health-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 10px;
}

.voice-health-card {
    display: grid;
    gap: 5px;
    min-height: 78px;
    padding: 12px 12px 11px;
    border: 1px solid rgba(255,255,255,.08);
    border-radius: 14px;
    background:
        radial-gradient(circle at top right, rgba(255,255,255,.05), transparent 34%),
        rgba(255,255,255,.025);
}

.voice-health-card[data-tone="good"] {
    border-color: rgba(var(--accent-rgb), .22);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
}

.voice-health-card[data-tone="warn"] {
    border-color: rgba(255, 186, 73, .18);
}

.voice-health-card[data-tone="bad"] {
    border-color: rgba(255, 77, 109, .22);
}

.voice-health-card[data-tone="idle"] {
    opacity: .88;
}

.voice-health-name {
    color: var(--text3);
    font-size: 10px;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: .12em;
}

.voice-health-value {
    color: var(--text);
    font-size: 12px;
    font-weight: 900;
    line-height: 1.15;
}

.voice-health-sub {
    color: var(--text2);
    font-size: 11px;
    line-height: 1.35;
}

.voice-btn {
    min-height: 34px;
    padding: 0 14px;
    border: 1px solid rgba(var(--accent-rgb), .16);
    border-radius: 999px;
    background: linear-gradient(180deg, rgba(var(--accent-rgb), .98), rgba(var(--accent-rgb), .84));
    color: #0b0b0b;
    font-size: 11px;
    font-weight: 900;
    letter-spacing: .08em;
    text-transform: uppercase;
    cursor: pointer;
    transition: transform .18s ease, box-shadow .18s ease, filter .18s ease, border-color .18s ease;
}

.voice-btn:hover {
    filter: brightness(1.05);
    box-shadow: 0 0 0 3px var(--lime-dim);
}

.voice-btn.danger {
    border-color: rgba(255,77,109,.24);
    background: linear-gradient(180deg, rgba(255,77,109,.96), rgba(255,77,109,.82));
    color: #fff;
}

.voice-room-participants {
    display: grid;
    gap: 8px;
}

.voice-trace {
    display: grid;
    gap: 8px;
}

.voice-trace-list {
    display: grid;
    gap: 6px;
    padding: 10px 12px;
    border: 1px solid rgba(255,255,255,.06);
    border-radius: 14px;
    background: rgba(255,255,255,.02);
}

.voice-trace-line {
    display: flex;
    gap: 8px;
    align-items: baseline;
    min-width: 0;
    color: var(--text2);
    font-size: 10px;
    line-height: 1.3;
    word-break: break-word;
}

.voice-trace-ts {
    flex: 0 0 auto;
    color: var(--text3);
    font-variant-numeric: tabular-nums;
}

.voice-trace-stage {
    min-width: 0;
    color: var(--text2);
}

.voice-trace-success .voice-trace-stage {
    color: rgba(186, 255, 0, .92);
}

.voice-trace-warn .voice-trace-stage {
    color: rgba(255, 125, 154, .96);
}

.voice-trace-error .voice-trace-stage {
    color: rgba(255, 92, 118, .98);
}

.voice-room-label {
    color: var(--text3);
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .08em;
}

.voice-participants {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.voice-participant {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    min-height: 28px;
    padding: 0 10px;
    border: 1px solid var(--border);
    border-radius: 999px;
    background: rgba(255,255,255,.03);
    color: var(--text2);
    font-size: 11px;
    font-weight: 800;
}

.voice-participant.mine {
    border-color: rgba(var(--accent-rgb), .24);
    color: var(--text);
}

.voice-empty {
    color: var(--text3);
    font-size: 12px;
}

#viewChat .chat-hdr,
#viewChat .voice-panel,
#viewChat .msgs,
#viewChat .input-area {
    border: 0;
    border-radius: 0;
    background: transparent;
    box-shadow: none;
    backdrop-filter: none;
    -webkit-backdrop-filter: none;
}

#viewChat .chat-hdr {
    padding: 14px 18px;
    align-items: center;
    border-bottom: 1px solid var(--border);
}

#viewChat .voice-panel {
    padding: 0 18px 4px;
}

#viewChat .msgs {
    min-height: 0;
    padding: 16px 16px 124px;
    overflow-y: auto;
    scroll-padding-bottom: 124px;
}

#viewChat .input-area {
    margin-top: 0;
    padding: 14px 14px 18px;
    border-top: 1px solid var(--border);
    align-self: end;
    position: relative;
    z-index: 2;
    background: linear-gradient(180deg, rgba(10,12,16,.05), rgba(10,12,16,.82));
    backdrop-filter: blur(10px);
    transform: none;
}

.settings-topbar {
    justify-content: space-between;
    align-items: flex-start;
    gap: 18px;
    padding-top: 14px;
    padding-bottom: 14px;
}

.settings-topcopy {
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.settings-kicker {
    color: var(--lime);
    font-size: 10px;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: .14em;
}

.settings-lead {
    max-width: 760px;
    margin: 0;
    color: var(--text2);
    font-size: 12px;
    line-height: 1.5;
}

.hdr-btn,
.btn-flat {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: var(--control-h-sm);
    padding: 0 12px;
    border: 1px solid var(--border);
    border-radius: 12px;
    background: linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,.03));
    color: var(--text);
    cursor: pointer;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04), 0 6px 18px rgba(0,0,0,.14);
    line-height: 1;
    transition: transform .18s ease, border-color .18s ease, box-shadow .18s ease, background .18s ease;
}

.hdr-btn:hover,
.btn-flat:hover {
    border-color: var(--lime);
    box-shadow: 0 0 0 2px rgba(var(--accent-rgb),.08);
}

.settings-body {
    padding: 24px;
}

.settings-scroll {
    overflow-y: auto;
}

.settings-shell {
    display: flex;
    flex-direction: column;
    gap: 20px;
    max-width: 1280px;
    width: 100%;
    margin: 0 auto;
}

.settings-card {
    position: relative;
    overflow: hidden;
    padding: 18px;
    border: 1px solid var(--border);
    border-radius: 18px;
    background:
        linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015)),
        rgba(255,255,255,.02);
    box-shadow: 0 18px 48px rgba(0,0,0,.16);
    backdrop-filter: blur(12px);
    animation: card-rise .3s cubic-bezier(.2,.8,.2,1) both;
}

.settings-card::before {
    content: '';
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: linear-gradient(135deg, rgba(var(--accent-rgb),.08), transparent 28%);
    opacity: .6;
}

.settings-hero {
    display: grid;
    grid-template-columns: minmax(0, 1.2fr) auto;
    gap: 20px;
    align-items: center;
}

.settings-hero-copy {
    position: relative;
    z-index: 1;
}

.settings-hero-copy h2 {
    margin: 4px 0 8px;
    color: var(--text);
    font-size: 22px;
    line-height: 1.18;
}

.settings-hero-copy p {
    margin: 0;
    max-width: 760px;
    color: var(--text2);
    font-size: 13px;
    line-height: 1.6;
}

.settings-chips {
    position: relative;
    z-index: 1;
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    justify-content: flex-end;
}

.settings-chip {
    padding: 8px 12px;
    border: 1px solid var(--border);
    border-radius: 999px;
    background: rgba(255,255,255,.04);
    color: var(--text);
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .08em;
}

.settings-grid {
    display: grid;
    grid-template-columns: minmax(0, 1.05fr) minmax(360px, .95fr);
    gap: 20px;
    align-items: start;
}

.settings-column {
    display: grid;
    gap: 20px;
}

.settings-card-head {
    position: relative;
    z-index: 1;
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 14px;
    margin-bottom: 14px;
}

.settings-card-head--tight {
    align-items: center;
}

.settings-card-title {
    margin: 4px 0 0;
    color: var(--text);
    font-size: 15px;
    font-weight: 900;
}

.settings-card-note {
    flex: none;
    color: var(--text3);
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .08em;
}

.settings-theme-grid {
    position: relative;
    z-index: 1;
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 10px;
}

.settings-theme-grid .btn-theme {
    min-height: 42px;
    padding: 0 14px;
    border: 1px solid transparent;
    border-radius: 12px;
    color: #0b0b0b;
    cursor: pointer;
    font-size: 11px;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: .08em;
    box-shadow: 0 10px 24px rgba(0,0,0,.18);
    transition: transform .18s ease, box-shadow .18s ease, filter .18s ease, border-color .18s ease;
    animation: chip-pop .22s cubic-bezier(.2,.9,.18,1) both;
}

.settings-theme-grid .btn-theme:hover {
    filter: saturate(1.08) brightness(1.04);
    border-color: rgba(255,255,255,.2);
    box-shadow: 0 0 0 2px rgba(255,255,255,.12);
}

.avatar-editor {
    position: relative;
    z-index: 1;
    display: grid;
    grid-template-columns: 84px minmax(0, 1fr);
    gap: 16px;
    align-items: center;
}

.avatar-editor-preview {
    display: grid;
    place-items: center;
}

.avatar-preview {
    width: 72px;
    height: 72px;
    font-size: 24px;
    box-shadow:
        0 0 0 1px rgba(255,255,255,.04),
        0 0 0 6px rgba(var(--accent-rgb), .06);
}

.avatar-editor-copy {
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.avatar-editor-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.theme-lime { background: #cbff00; }
.theme-cyber { background: #ff0055; color: #fff !important; }
.theme-matrix { background: #00ff33; }
.theme-ocean { background: #00d2ff; }
.theme-mono { background: #fff; }

.settings-control-box {
    position: relative;
    z-index: 1;
    padding: 10px 12px;
    border: 1px solid rgba(255,255,255,.05);
    border-radius: 14px;
    background: rgba(255,255,255,.02);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.03);
}

.settings-stack {
    position: relative;
    z-index: 1;
    display: grid;
    gap: 12px;
}

.settings-control-row {
    display: grid;
    grid-template-columns: 88px minmax(0, 1fr) 64px;
    gap: 12px;
    align-items: center;
}

.settings-label {
    color: var(--text2);
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .08em;
}

.settings-value {
    color: var(--lime);
    font-size: 13px;
    font-weight: 900;
    text-align: right;
}

.settings-range {
    width: 100%;
    accent-color: var(--lime);
    cursor: pointer;
}

.settings-log-body {
    position: relative;
    z-index: 1;
    max-height: 320px;
    border: 1px solid rgba(255,255,255,.05);
    border-radius: 14px;
    background: rgba(0,0,0,.18);
}

.settings-input {
    width: 100%;
    min-height: var(--control-h);
    padding: 12px 14px;
    border: 1px solid var(--border);
    border-radius: 12px;
    outline: none;
    background: rgba(255,255,255,.03);
    color: var(--text);
    font-family: inherit;
    font-size: 14px;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
    transition: border-color .18s ease, box-shadow .18s ease, transform .18s ease;
}

.settings-input:focus {
    border-color: var(--lime);
    box-shadow: 0 0 0 3px var(--lime-dim);
}

.color-picker {
    display: grid;
    grid-template-columns: 128px minmax(0, 1fr);
    gap: 12px;
    align-items: center;
    padding: 12px;
    border: 1px solid var(--border);
    border-radius: 18px;
    background: rgba(255,255,255,.02);
}

.color-picker--compact {
    grid-template-columns: 112px minmax(0, 1fr);
    padding: 10px;
}

.color-wheel {
    --wheel-color: var(--lime);
    --thumb-x: 50%;
    --thumb-y: 50%;
    position: relative;
    width: 128px;
    aspect-ratio: 1;
    border: 0;
    border-radius: 50%;
    cursor: crosshair;
    background:
        radial-gradient(circle at center, rgba(0,0,0,.18), rgba(0,0,0,.28) 66%, transparent 67%),
        conic-gradient(from 0deg, #ff0000, #ffff00, #00ff00, #00ffff, #0000ff, #ff00ff, #ff0000);
    box-shadow:
        inset 0 0 0 1px rgba(255,255,255,.08),
        0 12px 28px rgba(0,0,0,.22);
    user-select: none;
    pointer-events: auto;
    touch-action: none;
    flex: none;
    z-index: 1;
}

.color-wheel::before {
    content: '';
    position: absolute;
    inset: 14px;
    border-radius: 50%;
    background:
        radial-gradient(circle at center, rgba(12,14,18,.88), rgba(12,14,18,.96) 70%, rgba(12,14,18,1));
    box-shadow: inset 0 0 0 1px rgba(255,255,255,.05);
}

.color-wheel::after {
    content: '';
    position: absolute;
    inset: 0;
    border-radius: 50%;
    box-shadow: inset 0 0 0 1px rgba(255,255,255,.06);
}

.color-wheel--small {
    width: 112px;
}

.color-wheel--tiny {
    width: 64px;
}

.color-wheel--tiny::before {
    inset: 8px;
}

.color-wheel--tiny .color-wheel-center {
    display: none;
}

.color-wheel--tiny .color-wheel-thumb {
    width: 14px;
    height: 14px;
}

.color-wheel-thumb {
    position: absolute;
    left: var(--thumb-x);
    top: var(--thumb-y);
    width: 18px;
    height: 18px;
    transform: translate(-50%, -50%);
    border: 2px solid #fff;
    border-radius: 50%;
    background: var(--wheel-color);
    box-shadow: 0 0 0 4px rgba(0,0,0,.24), 0 10px 20px rgba(0,0,0,.28);
    z-index: 1;
    pointer-events: none;
}

.color-wheel-center {
    position: absolute;
    inset: 0;
    display: grid;
    place-items: center;
    color: var(--text);
    font-size: 12px;
    font-weight: 900;
    letter-spacing: .16em;
    z-index: 0;
    pointer-events: none;
}

.color-wheel *,
.color-wheel::before,
.color-wheel::after {
    pointer-events: none;
}

.color-picker-side {
    min-width: 0;
    display: grid;
    gap: 8px;
}

.role-color-editor {
    display: flex;
    align-items: center;
    gap: 8px;
    min-width: 0;
}

.color-hex-input {
    text-transform: uppercase;
}

.color-picker-help {
    margin: 0;
}

.settings-textarea {
    width: 100%;
    min-height: 94px;
    padding: 12px 14px;
    border: 1px solid var(--border);
    border-radius: 12px;
    outline: none;
    resize: vertical;
    background: rgba(255,255,255,.03);
    color: var(--text);
    font-family: inherit;
    font-size: 14px;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
    transition: border-color .18s ease, box-shadow .18s ease, transform .18s ease;
}

.settings-textarea:focus {
    border-color: var(--lime);
    box-shadow: 0 0 0 3px var(--lime-dim);
}

.settings-textarea--compact {
    min-height: 132px;
    resize: vertical;
    line-height: 1.45;
}

.settings-inline-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    align-items: center;
}

.server-overlay {
    position: fixed;
    inset: 0;
    z-index: 60;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    padding: 24px;
    background: rgba(4, 6, 10, .78);
    backdrop-filter: blur(16px);
    overflow-y: auto;
}

.server-overlay[hidden] {
    display: none;
}

.server-modal {
    width: min(960px, 100%);
    max-height: none;
    margin: auto;
    overflow: visible;
    display: flex;
    flex-direction: column;
    gap: 16px;
    padding: 22px;
    border: 1px solid rgba(255,255,255,.08);
    border-radius: 24px;
    background:
        radial-gradient(circle at top left, rgba(var(--accent-rgb),.11), transparent 28%),
        linear-gradient(180deg, rgba(22,24,28,.98), rgba(10,12,16,.98));
    box-shadow: 0 30px 90px rgba(0,0,0,.52), 0 0 0 1px rgba(var(--accent-rgb),.06);
}

.server-modal-head {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
}

.server-modal-headcopy {
    min-width: 0;
}

.server-modal-kicker {
    display: inline-flex;
    margin-bottom: 6px;
    color: var(--lime);
    font-size: 12px;
    font-weight: 900;
    letter-spacing: .18em;
    text-transform: uppercase;
}

.server-modal-head h2 {
    margin: 0;
    font-size: 26px;
    line-height: 1.1;
}

.server-modal-head p {
    margin: 8px 0 0;
    color: var(--text2);
    line-height: 1.5;
}

.server-modal-close {
    width: 40px;
    height: 40px;
    border: 1px solid var(--border);
    border-radius: 12px;
    background: rgba(255,255,255,.04);
    color: var(--text);
    cursor: pointer;
    font-size: 22px;
    line-height: 1;
}

.server-modal-grid {
    min-height: 0;
    display: grid;
    grid-template-columns: 1.02fr .98fr;
    gap: 14px;
    align-items: start;
}

.server-modal-grid.is-discover {
    grid-template-columns: minmax(0, 1fr);
}

.server-modal-card {
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 12px;
    padding: 16px;
    border: 1px solid var(--border);
    border-radius: 18px;
    background: rgba(255,255,255,.02);
}

.server-modal-grid.is-discover .server-discover-card {
    width: min(760px, 100%);
}

.server-form {
    display: grid;
    gap: 10px;
}

.server-assets {
    display: grid;
    gap: 10px;
    margin-top: 12px;
}

.server-asset-card {
    display: grid;
    grid-template-columns: 88px minmax(0, 1fr);
    gap: 12px;
    padding: 12px;
    border: 1px solid var(--border);
    border-radius: 16px;
    background: rgba(255,255,255,.02);
}

.server-asset-preview {
    display: grid;
    place-items: center;
    overflow: hidden;
    border: 1px solid rgba(255,255,255,.08);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
}

.server-avatar-preview {
    width: 88px;
    height: 88px;
    border-radius: 50%;
    background: linear-gradient(180deg, rgba(var(--accent-rgb),.98), rgba(var(--accent-rgb),.82));
    color: #050505;
    font-size: 26px;
    font-weight: 900;
}

.server-banner-card {
    grid-template-columns: 150px minmax(0, 1fr);
}

.server-banner-preview {
    width: 150px;
    min-height: 88px;
    border-radius: 16px;
    background:
        radial-gradient(circle at 20% 20%, rgba(var(--accent-rgb), .36), transparent 28%),
        linear-gradient(135deg, rgba(255,255,255,.12), rgba(255,255,255,.04));
    color: var(--text);
    font-size: 16px;
    font-weight: 900;
    letter-spacing: .08em;
}

.server-asset-copy {
    min-width: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 8px;
}

.server-asset-title {
    color: var(--text);
    font-weight: 900;
    font-size: 13px;
}

.server-asset-sub {
    color: var(--text2);
    font-size: 11px;
    line-height: 1.5;
}

.server-asset-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.server-link-card {
    display: grid;
    gap: 8px;
    padding: 12px;
    border: 1px solid var(--border);
    border-radius: 16px;
    background: rgba(255,255,255,.02);
}

.server-link-row {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto auto;
    gap: 8px;
    align-items: center;
}

.server-discover-head-actions {
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.server-discover-toolbar {
    display: grid;
    gap: 8px;
}

.server-discover-list {
    display: grid;
    gap: 10px;
    min-height: 200px;
    max-height: 42vh;
    overflow-y: auto;
    padding-right: 4px;
}

.server-discover-row {
    display: grid;
    gap: 8px;
    padding: 12px;
    border: 1px solid var(--border);
    border-radius: 16px;
    background: rgba(255,255,255,.02);
}

.server-discover-item {
    width: 100%;
    justify-content: flex-start;
    text-align: left;
}

.server-discover-item .server-meta {
    flex: 1;
    min-width: 0;
}

.server-discover-actions {
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-end;
    gap: 8px;
}

.server-discover-actions .btn-flat {
    min-width: 104px;
}

.server-toggle {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 14px;
    border: 1px solid var(--border);
    border-radius: 12px;
    background: rgba(255,255,255,.03);
    cursor: pointer;
}

.server-toggle input {
    width: 18px;
    height: 18px;
    accent-color: var(--lime);
}

.server-toggle strong {
    display: block;
    color: var(--text);
    font-size: 13px;
}

.server-toggle small {
    display: block;
    margin-top: 2px;
    color: var(--text2);
    font-size: 11px;
}

.server-member-add {
    display: grid;
    grid-template-columns: minmax(0, 1.25fr) 110px auto;
    gap: 8px;
}

.server-role-create {
    display: grid;
    grid-template-columns: minmax(0, 1fr);
    gap: 10px;
    position: relative;
    z-index: 3;
    isolation: isolate;
}

.server-role-create .settings-input {
    position: relative;
    z-index: 4;
    min-width: 0;
    cursor: text;
    pointer-events: auto;
}

.server-role-create-btn {
    position: relative;
    z-index: 4;
    justify-self: start;
    width: auto;
    min-height: var(--control-h);
    padding-inline: 16px;
    pointer-events: auto;
}

.server-role-create .color-picker--compact {
    position: relative;
    z-index: 1;
    margin-top: 2px;
}

.server-role-perms {
    display: grid;
    gap: 8px;
    padding: 12px;
    border: 1px solid var(--border);
    border-radius: 16px;
    background: rgba(255,255,255,.02);
}

.server-roles-list {
    display: grid;
    gap: 8px;
    min-height: 180px;
    max-height: 34vh;
    overflow-y: auto;
    padding-right: 4px;
}

.server-role-card {
    display: grid;
    gap: 10px;
    padding: 12px;
    border: 1px solid var(--border);
    border-radius: 16px;
    background: rgba(255,255,255,.02);
}

.server-role-head {
    display: grid;
    grid-template-columns: 16px minmax(0, 1fr) auto;
    gap: 10px;
    align-items: center;
}

.server-role-head--draft {
    cursor: pointer;
}

.server-role-chip {
    width: 16px;
    height: 16px;
    border-radius: 999px;
    box-shadow: 0 0 0 1px rgba(255,255,255,.08);
}

.server-role-name {
    overflow: hidden;
    font-weight: 800;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.server-role-meta {
    color: var(--text2);
    font-size: 11px;
}

.server-role-summary {
    margin-top: 4px;
    margin-left: 26px;
}

.server-role-controls {
    display: grid;
    grid-template-columns: minmax(0, 1fr);
    gap: 10px;
}

.server-role-body {
    display: grid;
    gap: 10px;
}

.server-role-card.draft-role.collapsed .server-role-body {
    display: none;
}

.server-role-toggle {
    min-height: 34px;
    padding-inline: 12px;
    white-space: nowrap;
    justify-self: end;
}

.server-role-actions {
    display: flex;
    justify-content: flex-end;
    gap: 8px;
}

.server-role-card.owner-role {
    border-color: rgba(var(--accent-rgb), .20);
    background: rgba(var(--accent-rgb), .05);
}

.server-perm-grid {
    display: grid;
    gap: 8px;
}

.server-perm-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 14px;
    padding: 10px 12px;
    border: 1px solid var(--border);
    border-radius: 12px;
    background: rgba(255,255,255,.02);
}

.server-perm-row input {
    accent-color: var(--lime);
}

.server-members-list {
    min-height: 180px;
    max-height: 38vh;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding-right: 4px;
}

.server-members-list.is-loading {
    opacity: .65;
    pointer-events: none;
}

.server-member-row {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 124px 34px;
    gap: 8px;
    align-items: center;
    padding: 10px 12px;
    border: 1px solid var(--border);
    border-radius: 14px;
    background: rgba(255,255,255,.02);
}

.server-member-name {
    overflow: hidden;
    color: var(--text);
    font-weight: 800;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.server-member-meta {
    color: var(--text2);
    font-size: 11px;
}

.server-member-role {
    width: 100%;
}

.server-member-remove {
    width: 34px;
    height: 34px;
    border-radius: 10px;
    background: rgba(255,255,255,.04);
    color: var(--text);
    cursor: pointer;
    line-height: 1;
}

.server-member-remove:hover {
    color: var(--red);
    background: rgba(255,77,109,.08);
}

.server-member-row.owner {
    border-color: rgba(var(--accent-rgb), .22);
    background: rgba(var(--accent-rgb), .06);
}

.server-member-row.owner .server-member-remove,
.server-member-row.owner .server-member-role {
    opacity: .45;
    pointer-events: none;
}

.server-modal-error {
    min-height: 18px;
    color: var(--red);
    font-size: 12px;
}

.server-modal-actions {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 10px;
    padding: 12px 0 0;
    margin-top: auto;
    position: sticky;
    bottom: 0;
    z-index: 2;
    background: linear-gradient(180deg, rgba(10,12,16,0), rgba(10,12,16,.88) 44%, rgba(10,12,16,.98));
    backdrop-filter: blur(10px);
}

.server-modal-actions .auth-btn.primary {
    min-height: 40px;
}

.server-delete-btn {
    color: var(--red);
}

.settings-help {
    margin: 0;
    color: var(--text3);
    font-size: 11px;
    line-height: 1.55;
}

.crypto-key-value {
    display: inline-block;
    max-width: 100%;
    padding: 2px 8px;
    margin: 0 4px;
    border: 1px solid rgba(var(--accent-rgb), .18);
    border-radius: 999px;
    background: rgba(255,255,255,.04);
    color: var(--text);
    font-family: "SF Mono", "Menlo", "Monaco", Consolas, monospace;
    font-size: 11px;
    word-break: break-all;
    overflow-wrap: anywhere;
}

.settings-card--logs {
    min-height: 0;
}

.settings-card--danger {
    border-color: rgba(255,255,255,.08);
    background:
        linear-gradient(180deg, rgba(255,77,109,.08), rgba(255,255,255,.015)),
        rgba(255,255,255,.02);
}

.settings-logout {
    position: relative;
    z-index: 1;
    width: 100%;
    justify-content: center;
    border-radius: 12px;
    background: rgba(255,77,109,.08);
    border-color: rgba(255,77,109,.18);
    transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease, color .18s ease, background .18s ease;
}

.settings-logout:hover {
    border-color: var(--red);
    color: var(--red);
    box-shadow: 0 0 0 2px rgba(255,77,109,.12);
}

.settings-body .log-body {
    padding: 14px;
    font-size: 11px;
}

.msgs {
    min-height: 0;
    overflow-y: auto;
    padding: 18px 22px;
    overflow-anchor: none;
}

.msg {
    display: flex;
    gap: 9px;
    align-items: flex-end;
    margin: 0 0 calc(var(--msg-gap) * 1px);
}

.server-msg {
    display: flex;
    gap: 10px;
    align-items: flex-start;
    justify-content: flex-start;
    margin: 0 0 calc(var(--msg-gap) * 1px);
}

.msg.out {
    justify-content: flex-end;
}

.msg.call-msg .bwrap {
    width: fit-content;
    max-width: min(560px, 74%);
}

.msg.single,
.msg.group-start {
    margin-top: calc((var(--msg-gap) + 1) * 1px);
}

.msg.group-mid,
.msg.group-end {
    margin-top: calc(var(--msg-gap) * 1px);
}

.msg-ava {
    width: 28px;
    height: 28px;
    margin-top: 0;
    font-size: 11px;
}

.server-msg-ava {
    width: 34px;
    height: 34px;
    margin-top: 2px;
    font-size: 12px;
}

.msg-ava-spacer {
    visibility: hidden;
}

.server-msg-ava-spacer {
    visibility: hidden;
}

.bwrap {
    display: inline-flex;
    flex-direction: column;
    align-items: flex-start;
    width: fit-content;
    max-width: min(620px, 74%);
}

.msg.out .bwrap {
    align-items: flex-end;
}

.call-card {
    display: grid;
    gap: 10px;
    padding: 10px 12px;
    border: 1px solid var(--border);
    border-radius: 16px;
    background: rgba(255,255,255,.03);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
}

.call-card-top {
    display: flex;
    align-items: center;
    gap: 10px;
}

.call-card-icon {
    display: grid;
    place-items: center;
    width: 30px;
    height: 30px;
    border-radius: 10px;
    background: rgba(255,255,255,.06);
    font-size: 15px;
    flex: 0 0 auto;
}

.call-card-copy {
    min-width: 0;
}

.call-card-title {
    color: var(--text);
    font-size: 13px;
    font-weight: 900;
}

.call-card-sub {
    margin-top: 2px;
    color: var(--text2);
    font-size: 11px;
}

.call-card-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 6px 12px;
    color: var(--text3);
    font-size: 10px;
}

.server-msg-main {
    display: inline-flex;
    flex-direction: column;
    align-items: flex-start;
    width: fit-content;
    max-width: min(820px, 88%);
}

.server-msg-meta {
    display: flex;
    align-items: baseline;
    gap: 8px;
    margin: 0 0 6px;
    min-width: 0;
}

.server-msg-name {
    color: var(--text);
    font-weight: 900;
    line-height: 1.2;
}

.server-msg-time {
    color: var(--text3);
    font-size: 11px;
    font-weight: 700;
    white-space: nowrap;
}

.server-msg .bubble {
    max-width: 100%;
}

.server-msg .reaction-row {
    margin-top: 6px;
}

.bubble {
    position: relative;
    isolation: isolate;
    overflow-wrap: anywhere;
    padding: 10px 13px;
    border: 1px solid var(--border);
    border-radius: 18px;
    background: linear-gradient(180deg, rgba(255,255,255,.08), rgba(255,255,255,.04));
    color: var(--text);
    line-height: 1.45;
    box-shadow: 0 10px 24px rgba(0,0,0,.12);
}

.out .bubble {
    border: 1px solid transparent;
    background:
        linear-gradient(180deg, rgba(var(--accent-rgb),.98), rgba(var(--accent-rgb),.90)) padding-box,
        linear-gradient(180deg, rgba(255,255,255,.28), rgba(95,110,0,.18)) border-box;
    color: #111100;
    box-shadow:
        0 10px 24px rgba(0,0,0,.12),
        inset 0 1px 0 rgba(255,255,255,.24),
        inset 0 -1px 0 rgba(85, 104, 0, .10);
}

.bubble.media-card {
    padding: 10px;
    border-color: rgba(255,255,255,.06);
    background: #2b2d31;
    color: #dbdee1;
}

.out .bubble.media-card {
    border-color: rgba(255,255,255,.06);
    background: #2b2d31;
    color: #dbdee1;
}

.media-only {
    display: inline-block;
    padding: 0;
    border: 0;
    background: transparent;
}

.msg.gif-only .bwrap {
    max-width: min(520px, 74%);
}

.reaction-row {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    margin-top: 6px;
    align-self: flex-start;
}

.msg.out .reaction-row {
    align-self: flex-end;
    justify-content: flex-end;
}

.reaction-chip {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    min-height: 24px;
    padding: 0 9px;
    border: 1px solid var(--border);
    border-radius: 999px;
    background: rgba(255,255,255,.06);
    color: var(--text);
    cursor: pointer;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
}

.reaction-chip:hover,
.reaction-chip:focus-visible {
    border-color: var(--lime);
    box-shadow: 0 0 0 2px var(--lime-dim);
    outline: 0;
}

.reaction-chip.mine {
    border-color: rgba(var(--accent-rgb),.45);
    background: rgba(var(--accent-rgb),.14);
}

.reaction-emoji {
    font-size: 12px;
    line-height: 1;
}

.reaction-count {
    font-size: 11px;
    font-weight: 800;
}

.reaction-btn {
    width: 30px;
    height: 30px;
    border: 1px solid var(--border);
    border-radius: 999px;
    background: rgba(255,255,255,.06);
    color: var(--text);
    cursor: pointer;
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
}

.reaction-btn:hover,
.reaction-btn:focus-visible {
    border-color: var(--lime);
    box-shadow: 0 0 0 2px var(--lime-dim);
    outline: 0;
}

.reaction-btn.active {
    border-color: rgba(var(--accent-rgb),.55);
    background: rgba(var(--accent-rgb),.16);
}

.reaction-menu {
    position: fixed;
    z-index: 80;
    display: none;
    gap: 6px;
    padding: 8px;
    border: 1px solid var(--border);
    border-radius: 14px;
    background: rgba(10,12,15,.96);
    box-shadow: 0 18px 42px rgba(0,0,0,.38);
    backdrop-filter: blur(12px);
}

.reaction-menu.visible {
    display: flex;
}

.reaction-menu .reaction-btn {
    flex: none;
}

.msg-text {
    white-space: pre-wrap;
}

.msg-text a,
.msg-attachments a,
.msg-link-previews a {
    color: inherit;
    text-decoration: underline;
    text-underline-offset: 2px;
}

.msg-attachments {
    display: grid;
    gap: 10px;
    margin-top: 8px;
}

.msg-attachments:first-child {
    margin-top: 0;
}

.media,
.media-tenor iframe {
    display: block;
    width: 100%;
    border: 0;
    border-radius: 12px;
    background: rgba(0,0,0,.18);
}

.media-img,
.media-video {
    max-width: 100%;
}

.media-video {
    width: 100%;
    max-height: 360px;
}

.media-tenor {
    overflow: hidden;
    min-height: 220px;
}

.media-tenor iframe {
    width: 100%;
    height: 100%;
}

.media-tenor-pending {
    display: grid;
    place-items: center;
    gap: 8px;
    padding: 18px;
    background: linear-gradient(145deg, rgba(255,255,255,.08), rgba(255,255,255,.03));
}

.tenor-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 120px;
    padding: 10px 14px;
    border: 1px solid rgba(0,0,0,.14);
    border-radius: 10px;
    background: rgba(0,0,0,.28);
    color: #fff;
    font-size: 13px;
    font-weight: 800;
    box-shadow: 0 6px 18px rgba(0,0,0,.14);
}

.tenor-hint {
    color: var(--text2);
    font-size: 12px;
}

.discord-media-shell {
    overflow: hidden;
    border-radius: 12px;
    background: #000;
    border: 1px solid rgba(255,255,255,.04);
    box-shadow: 0 1px 0 rgba(0,0,0,.35), inset 0 0 0 1px rgba(255,255,255,.02);
    overflow-anchor: none;
}

.discord-media-shell video,
.discord-media-shell img {
    display: block;
    width: 100%;
    max-width: 100%;
    height: auto;
}

.discord-media-shell-video {
    min-height: 0;
}

.discord-media-shell-video video {
    width: 100%;
    height: 100%;
    max-height: 360px;
    object-fit: contain;
}

.discord-media-shell-gif {
    background: transparent;
    min-height: 0;
    min-height: 220px;
}

.discord-media-shell-gif video {
    width: 100%;
    height: 100%;
    object-fit: contain;
    background: transparent !important;
}

.discord-media-shell-image.discord-media-shell-gif img,
.discord-media-shell-image .media-gif-like {
    width: 100%;
    height: 100%;
    object-fit: contain;
    max-height: 70vh;
}

.discord-media-shell-image img {
    object-fit: cover;
}

.discord-media-shell-video video {
    background: #000;
}

.discord-media-shell-gif {
    background: transparent;
}

.media-unknown {
    padding: 10px 12px;
    border: 1px dashed var(--border);
    border-radius: calc(var(--r-msg) - 6px);
    color: var(--text2);
}

.file-chip {
    display: inline-flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: center;
    gap: 8px;
    padding: 10px 12px;
    border: 1px solid transparent;
    border-radius: 18px;
    background:
        linear-gradient(180deg, rgba(255,255,255,.08), rgba(255,255,255,.04)) padding-box,
        linear-gradient(180deg, rgba(255,255,255,.16), rgba(255,255,255,.05)) border-box;
    color: var(--text);
    text-decoration: none;
    box-shadow:
        0 10px 24px rgba(0,0,0,.10),
        inset 0 1px 0 rgba(255,255,255,.06);
}

.file-chip:hover,
.file-chip:focus-visible {
    box-shadow:
        0 10px 24px rgba(0,0,0,.10),
        inset 0 1px 0 rgba(255,255,255,.08),
        0 0 0 2px rgba(var(--accent-rgb),.10);
    outline: 0;
}

.file-chip-name {
    font-weight: 700;
    line-height: 1.2;
}

.file-chip-size {
    color: var(--text2);
    font-size: 11px;
    line-height: 1.2;
}

.file-chip.compact {
    padding: 9px 11px;
}


.btime {
    margin-top: 2px;
    color: var(--text3);
    font-size: 10px;
}

.out .btime {
    text-align: right;
}

.date-sep {
    display: flex;
    justify-content: center;
    margin: 18px 0;
}

.date-sep span {
    padding: 5px 10px;
    border-radius: 999px;
    background: rgba(255,255,255,.06);
    color: var(--text2);
    font-size: 11px;
    font-weight: 800;
    animation: chip-pop .22s cubic-bezier(.2,.9,.18,1) both;
}

.input-area {
    display: flex;
    flex-direction: column;
    gap: 14px;
    padding: 14px 18px 16px;
    border-top: 1px solid rgba(255,255,255,.08);
    background: transparent;
}

.draft-attachments {
    display: none;
    flex-wrap: wrap;
    gap: 10px;
}

.draft-attachments.has-items {
    display: flex;
}

.draft-att {
    position: relative;
    width: 128px;
    padding: 8px;
    border: 1px solid var(--border);
    border-radius: 14px;
    background: rgba(255,255,255,.03);
    animation: card-rise .22s cubic-bezier(.2,.8,.2,1) both;
}

.draft-att-remove {
    position: absolute;
    top: 6px;
    right: 6px;
    width: 22px;
    height: 22px;
    border-radius: 50%;
    background: rgba(0,0,0,.6);
    color: #fff;
    cursor: pointer;
    transition: transform .18s ease, background .18s ease, color .18s ease;
}

.draft-att-remove:hover {
    background: rgba(0,0,0,.8);
    color: var(--lime);
}

.draft-att .media,
.draft-att .file-chip {
    width: 100%;
    max-height: 84px;
    min-height: 84px;
    object-fit: cover;
}

.draft-att .discord-media-shell {
    width: 100%;
    height: 84px;
}

.draft-att .discord-media-shell video,
.draft-att .discord-media-shell img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.draft-att .file-chip {
    display: grid;
    place-items: center;
    text-align: center;
    padding: 10px;
}

.draft-att-name {
    margin-top: 8px;
    overflow: hidden;
    color: var(--text2);
    font-size: 11px;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.input-bar {
    display: grid;
    grid-template-columns: 44px 1fr 44px;
    align-items: center;
    gap: 12px;
    width: calc(100% + 6px);
    margin: 0 -3px;
    padding: 12px;
    border: 1px solid var(--border);
    border-radius: 14px;
    background: rgba(255,255,255,.028);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.03);
}

#msgInput {
    min-width: 0;
    height: 40px;
    max-height: 140px;
    resize: none;
    border: 0;
    outline: 0;
    background: transparent;
    color: var(--text);
    line-height: 1.35;
    padding: 7px 0;
}

.attach-btn,
.send-btn {
    width: 44px;
    height: 40px;
    border-radius: 12px;
    display: grid;
    place-items: center;
    cursor: pointer;
    transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease, background .18s ease, color .18s ease;
}

.attach-btn {
    background: rgba(255,255,255,.04);
    color: var(--text);
    border: 1px solid var(--border);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
}

.attach-btn:hover,
.input-bar.drop-active {
    border-color: var(--lime);
    box-shadow: 0 0 0 2px var(--lime-dim);
}

.send-btn {
    background: var(--lime);
    color: #050505;
    box-shadow: 0 0 18px rgba(var(--accent-rgb),.28);
    transform-origin: bottom right;
}

.send-btn:hover {
    box-shadow: 0 0 0 2px rgba(var(--accent-rgb),.12);
}

.send-btn:disabled {
    cursor: default;
    opacity: .35;
}

.log-body,
.settings-body {
    min-height: 0;
    overflow-y: auto;
}

.log-body {
    padding: 14px 18px;
    font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
    font-size: 12px;
}

.log-entry {
    padding: 7px 0;
    border-bottom: 1px solid rgba(255,255,255,.04);
    color: var(--text2);
}

.log-SUCCESS {
    color: var(--lime);
}

.log-ERROR {
    color: var(--red);
}

.log-WARN {
    color: #ffcc66;
}

.ts {
    margin-right: 8px;
    color: var(--text3);
}

@media (max-width: 1100px) {
    .settings-hero,
    .settings-grid {
        grid-template-columns: 1fr;
    }

    .server-modal-grid {
        grid-template-columns: 1fr;
    }

    .settings-chips {
        justify-content: flex-start;
    }

    .settings-control-row {
        grid-template-columns: 72px minmax(0, 1fr) 56px;
    }
}

@media (max-width: 760px) {
    #viewSettings {
        grid-template-rows: auto 1fr;
    }

    .settings-topbar {
        flex-direction: column;
        align-items: stretch;
    }

    .settings-body {
        padding: 16px;
    }

    .settings-card {
        padding: 16px;
        border-radius: 16px;
    }

    .server-modal {
        padding: 18px;
        border-radius: 18px;
    }

    .server-modal-head {
        flex-direction: column;
    }

    .server-member-add {
        grid-template-columns: 1fr;
    }

    .server-role-create {
        grid-template-columns: 1fr;
    }

    .server-link-row {
        grid-template-columns: 1fr;
    }

    .server-member-row {
        grid-template-columns: 1fr;
    }

    .server-asset-card,
    .server-banner-card {
        grid-template-columns: 1fr;
    }

    .server-avatar-preview,
    .server-banner-preview {
        width: 100%;
    }

    .settings-theme-grid {
        grid-template-columns: 1fr;
    }

    .avatar-editor {
        grid-template-columns: 1fr;
        justify-items: start;
    }

    .chat-hdr.server-mode {
        flex-wrap: wrap;
    }

    .chat-hdr.server-mode .server-channel-list {
        margin-left: 0;
        max-width: 100%;
        width: 100%;
    }

    .settings-control-row {
        grid-template-columns: 1fr;
        gap: 8px;
    }

    .settings-value {
        text-align: left;
    }
}

.empty-state,
.contacts-loading {
    display: grid;
    place-items: center;
    min-height: 100%;
    color: var(--text3);
    text-align: center;
    gap: 4px;
    animation: fade-up .28s cubic-bezier(.2,.8,.2,1) both;
}

.empty-ttl {
    color: var(--text);
    font-weight: 900;
}

.empty-sub {
    color: var(--text2);
    font-size: 12px;
}

.sk {
    position: relative;
    overflow: hidden;
    border-radius: 8px;
    background: rgba(255,255,255,.06);
}

.sk::after {
    content: "";
    position: absolute;
    inset: 0;
    transform: translateX(-100%);
    background: linear-gradient(90deg, transparent, rgba(255,255,255,.09), transparent);
    animation: shimmer 1.4s infinite;
}

.sk-contact {
    width: calc(100% - 20px);
    height: 50px;
    margin: 8px 10px;
}

.sk-bubble {
    height: 38px;
    margin: 10px 0;
}

.sk-w1 { width: 34%; }
.sk-w2 { width: 52%; }
.sk-w3 { width: 66%; }
.sk-self { margin-left: auto; }

.auth-overlay {
    position: fixed;
    inset: 0;
    z-index: 50;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px;
    background: rgba(4, 6, 10, .76);
    backdrop-filter: blur(16px);
    opacity: 0;
    visibility: hidden;
    pointer-events: none;
    transition:
        opacity .24s ease,
        visibility 0s linear .24s;
}

.auth-overlay.visible {
    opacity: 1;
    visibility: visible;
    pointer-events: auto;
    transition:
        opacity .24s ease,
        visibility 0s linear 0s;
}

.auth-card {
    width: min(460px, 100%);
    padding: 28px;
    border: 1px solid rgba(255,255,255,.08);
    border-radius: 24px;
    background:
        radial-gradient(circle at top left, rgba(var(--accent-rgb),.1), transparent 28%),
        linear-gradient(180deg, rgba(26,28,32,.96), rgba(12,14,18,.97));
    box-shadow: 0 30px 90px rgba(0,0,0,.52), 0 0 0 1px rgba(var(--accent-rgb),.06);
    transform: translateY(18px) scale(.98);
    opacity: 0;
    transition:
        transform .36s cubic-bezier(.2,.8,.2,1),
        opacity .24s ease,
        box-shadow .24s ease;
    position: relative;
    overflow: hidden;
}

.auth-card::before {
    content: "";
    position: absolute;
    inset: 0;
    background:
        radial-gradient(circle at top right, rgba(var(--accent-rgb),.14), transparent 32%),
        radial-gradient(circle at bottom left, rgba(255,255,255,.05), transparent 26%);
    pointer-events: none;
    opacity: .8;
}

.auth-overlay.visible .auth-card {
    transform: translateY(0) scale(1);
    opacity: 1;
    animation: auth-pop .42s cubic-bezier(.2,.9,.18,1) both;
}

.auth-brand {
    color: var(--lime);
    font-size: 12px;
    font-weight: 900;
    letter-spacing: .18em;
    text-transform: uppercase;
}

.auth-card h1 {
    margin: 10px 0 8px;
    font-size: 28px;
    line-height: 1.1;
    position: relative;
    z-index: 1;
}

.auth-card p {
    margin: 0 0 20px;
    color: var(--text2);
    line-height: 1.5;
    position: relative;
    z-index: 1;
}

.auth-form {
    display: flex;
    flex-direction: column;
    gap: 12px;
    position: relative;
    z-index: 1;
}

.auth-input {
    width: 100%;
    height: 44px;
    padding: 0 14px;
    border: 1px solid var(--border);
    border-radius: 12px;
    outline: none;
    background: rgba(255,255,255,.03);
    color: var(--text);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
    transition:
        border-color .2s ease,
        box-shadow .2s ease,
        transform .2s ease,
        background .2s ease;
}

.auth-input:focus {
    border-color: var(--lime);
    box-shadow: 0 0 0 3px var(--lime-dim);
    background: rgba(255,255,255,.06);
}

.auth-input--compact {
    flex: 1 1 auto;
    min-width: 0;
}

.auth-actions {
    display: grid;
    grid-template-columns: 1fr;
    gap: 10px;
}

.auth-network {
    display: grid;
    gap: 10px;
    padding: 14px;
    border: 1px solid rgba(255,255,255,.06);
    border-radius: 16px;
    background: rgba(255,255,255,.02);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.03);
}

.auth-network-head {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
}

.auth-network-title {
    color: var(--text);
    font-size: 12px;
    font-weight: 900;
    letter-spacing: .08em;
    text-transform: uppercase;
}

.auth-network-note {
    color: var(--text2);
    font-size: 11px;
    font-weight: 700;
}

.auth-network-row {
    display: flex;
    gap: 10px;
    align-items: center;
}

.auth-network-help {
    margin: 0;
    color: var(--text2);
    font-size: 12px;
    line-height: 1.45;
}

.auth-btn {
    min-height: 40px;
    border-radius: 12px;
    border: 1px solid transparent;
    cursor: pointer;
    font-weight: 800;
    transition:
        transform .2s ease,
        box-shadow .2s ease,
        background .2s ease,
        border-color .2s ease,
        opacity .2s ease;
    position: relative;
    z-index: 1;
}

.auth-btn:hover {
    box-shadow: 0 0 0 2px rgba(0,0,0,.16);
}

.auth-btn:active {
    transform: translateY(1px) scale(.99);
}

.auth-btn.primary {
    background: var(--lime);
    color: #050505;
    box-shadow: 0 14px 28px rgba(var(--accent-rgb),.2);
}

.auth-btn--ghost {
    min-width: 108px;
    border: 1px solid rgba(var(--accent-rgb), .16);
    background: rgba(255,255,255,.04);
    color: var(--text);
}

.auth-btn.secondary {
    border: 1px solid var(--border);
    background: rgba(255,255,255,.04);
    color: var(--text);
}

.auth-footer {
    display: flex;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
}

.auth-link {
    min-height: 28px;
    padding: 0;
    background: none;
    color: var(--lime);
    cursor: pointer;
    font-weight: 700;
    transition: transform .2s ease, opacity .2s ease;
}

.auth-link:hover {
    opacity: .92;
}

.auth-error {
    min-height: 18px;
    color: var(--red);
    font-size: 12px;
    position: relative;
    z-index: 1;
}

.auth-overlay.visible .auth-form > * {
    animation: auth-field-in .42s cubic-bezier(.2,.8,.2,1) both;
}

.auth-overlay.visible .auth-form > *:nth-child(1) { animation-delay: .05s; }
.auth-overlay.visible .auth-form > *:nth-child(2) { animation-delay: .09s; }
.auth-overlay.visible .auth-form > *:nth-child(3) { animation-delay: .13s; }
.auth-overlay.visible .auth-form > *:nth-child(4) { animation-delay: .17s; }
.auth-overlay.visible .auth-form > *:nth-child(5) { animation-delay: .21s; }
.auth-overlay.visible .auth-form > *:nth-child(6) { animation-delay: .25s; }
.auth-overlay.visible .auth-form > *:nth-child(7) { animation-delay: .29s; }

.contacts .contact:nth-child(1),
.msgs .msg:nth-child(1),
.settings-shell > .settings-card:nth-child(1),
.settings-theme-grid .btn-theme:nth-child(1),
.draft-attachments .draft-att:nth-child(1) { animation-delay: .02s; }

.contacts .contact:nth-child(2),
.msgs .msg:nth-child(2),
.settings-shell > .settings-card:nth-child(2),
.settings-theme-grid .btn-theme:nth-child(2),
.draft-attachments .draft-att:nth-child(2) { animation-delay: .05s; }

.contacts .contact:nth-child(3),
.msgs .msg:nth-child(3),
.settings-shell > .settings-card:nth-child(3),
.settings-theme-grid .btn-theme:nth-child(3),
.draft-attachments .draft-att:nth-child(3) { animation-delay: .08s; }

.contacts .contact:nth-child(4),
.msgs .msg:nth-child(4),
.settings-shell > .settings-card:nth-child(4),
.settings-theme-grid .btn-theme:nth-child(4),
.draft-attachments .draft-att:nth-child(4) { animation-delay: .11s; }

.contacts .contact:nth-child(5),
.msgs .msg:nth-child(5),
.settings-shell > .settings-card:nth-child(5),
.settings-theme-grid .btn-theme:nth-child(5),
.draft-attachments .draft-att:nth-child(5) { animation-delay: .14s; }

.contacts .contact:nth-child(6),
.msgs .msg:nth-child(6),
.settings-shell > .settings-card:nth-child(6),
.settings-theme-grid .btn-theme:nth-child(6),
.draft-attachments .draft-att:nth-child(6) { animation-delay: .17s; }

.contacts .contact:nth-child(7),
.msgs .msg:nth-child(7),
.settings-shell > .settings-card:nth-child(7),
.settings-theme-grid .btn-theme:nth-child(7),
.draft-attachments .draft-att:nth-child(7) { animation-delay: .20s; }

.contacts .contact:nth-child(8),
.msgs .msg:nth-child(8),
.settings-shell > .settings-card:nth-child(8),
.settings-theme-grid .btn-theme:nth-child(8),
.draft-attachments .draft-att:nth-child(8) { animation-delay: .23s; }

@keyframes shimmer {
    to {
        transform: translateX(100%);
    }
}

@keyframes view-enter {
    from {
        opacity: 0;
        transform: translateY(6px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes row-fade {
    from {
        opacity: 0;
        transform: translateY(4px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes contact-in {
    from {
        opacity: 0;
        transform: translateX(-4px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

@keyframes contact-active {
    0% {
        transform: scale(.995);
    }
    100% {
        transform: scale(1);
    }
}

@keyframes avatar-pulse {
    0% {
        box-shadow:
            0 0 0 1px rgba(var(--accent-rgb), .10),
            0 0 0 0 rgba(var(--accent-rgb), .18);
    }
    100% {
        box-shadow:
            0 0 0 1px rgba(var(--accent-rgb), .18),
            0 0 0 4px rgba(var(--accent-rgb), .08);
    }
}

@keyframes badge-pop {
    0% {
        opacity: 0;
        transform: scale(.88);
    }
    100% {
        opacity: 1;
        transform: scale(1);
    }
}

@keyframes card-rise {
    from {
        opacity: 0;
        transform: translateY(8px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes chip-pop {
    from {
        opacity: 0;
        transform: translateY(4px) scale(.98);
    }
    to {
        opacity: 1;
        transform: translateY(0) scale(1);
    }
}

@keyframes msg-in {
    from {
        opacity: 0;
        transform: translateY(8px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes bubble-pop {
    from {
        opacity: 0;
        transform: scale(.98);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

@keyframes fade-up {
    from {
        opacity: 0;
        transform: translateY(6px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes auth-pop {
    0% {
        transform: translateY(22px) scale(.96);
        filter: blur(2px);
    }
    70% {
        transform: translateY(-2px) scale(1.01);
        filter: blur(0);
    }
    100% {
        transform: translateY(0) scale(1);
        filter: blur(0);
    }
}

@keyframes auth-field-in {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes suggest-drop {
    from {
        opacity: 0;
        transform: translateY(-6px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@media (prefers-reduced-motion: reduce) {
    .auth-overlay,
    .auth-card,
    .auth-input,
    .auth-btn,
    .auth-link,
    .contacts-suggest,
    .contact-suggest-item,
    .view.active,
    .contact,
    .msg,
    .bubble,
    .settings-card,
    .settings-theme-grid .btn-theme,
    .draft-att,
    .badge,
    .date-sep span,
    .empty-state,
    .contacts-loading {
        transition: none !important;
    }

    .auth-overlay.visible .auth-card,
    .auth-overlay.visible .auth-form > *,
    .contacts-suggest,
    .view.active,
    .contact,
    .msg,
    .bubble,
    .settings-card,
    .settings-theme-grid .btn-theme,
    .draft-att,
    .badge,
    .date-sep span,
    .empty-state,
    .contacts-loading {
        animation: none !important;
    }
}

@media (max-width: 760px) {
    .titlebar {
        grid-template-columns: 1fr auto;
    }

    .tb-l {
        display: none;
    }

    .tb-c {
        text-align: left;
    }

    .body {
        grid-template-columns: 96px 1fr;
    }

    .voice-meter-grid,
    .voice-health-grid {
        grid-template-columns: 1fr;
    }

    .sidebar-head,
    .search-wrap,
    .contacts-tools,
    .nav-label,
    .contact-info,
    .me > div,
    .badge,
    .contact-remove {
        display: none;
    }

    .server-channel {
        min-height: 32px;
        padding: 0 10px;
    }

    .server-channel-name {
        font-size: 10px;
    }

    .contact {
        grid-template-columns: 38px;
        justify-content: center;
    }

    .bwrap {
        max-width: 86%;
    }

    .draft-att {
        width: calc(50% - 5px);
    }
}

</style>
    <title>ZaliMessenger</title>

    <script>
    // Inject persisted custom CSS overrides from UserDefaults (set by native Swift layer)
    (function() {
        if (window.__ZALI_SAVED_CSS) {
            var s = document.createElement('style');
            s.id = 'zali-custom-style';
            s.textContent = window.__ZALI_SAVED_CSS;
            document.head.appendChild(s);
        }
    })();
    </script>

    <script>
    window.__ZALI_CONFIG = {};
    </script>
</head>
<body>
    <div class="app">

        <!-- TITLE BAR -->
        <header class="titlebar" id="titlebar">
            <div class="tb-l"></div>
            <div class="tb-c">
                <span class="tb-brand">ZaliMessenger</span>
                <span class="tb-sep">/</span>
                <span class="tb-chat" id="tbChat">Загрузка...</span>
            </div>
            <div class="tb-r">
                <div class="ws-pill" id="wsPill">
                    <span class="ws-dot" id="wsDot"></span>
                    <span id="wsLabel">Подключение...</span>
                </div>
            </div>
        </header>

        <div class="body">

            <!-- SIDEBAR -->
            <nav class="sidebar">
                <div class="sidebar-head">
                    <div class="brand">ZALI <em>MSG</em></div>
                    <div class="mode-switch" role="tablist" aria-label="Выбор раздела">
                        <button class="mode-btn" id="modeDmBtn" type="button" aria-pressed="true">ЛС</button>
                        <button class="mode-btn" id="modeServersBtn" type="button" aria-pressed="false">Сервера</button>
                    </div>
                </div>
                <div class="search-wrap">
                    <span class="search-icon" aria-hidden="true"></span>
                    <input id="searchInput" class="search-input" placeholder="Поиск..." autocomplete="off">
                </div>
                <div class="contacts-tools">
                    <input id="contactInput" class="contact-input" placeholder="Добавить контакт" autocomplete="off">
                </div>
                <div class="contacts-suggest-wrap" id="contactSuggestionsWrap" hidden>
                    <div class="contacts-suggest" id="contactSuggestions" hidden></div>
                </div>
                <div class="nav-label">Диалоги</div>
                <div class="contacts" id="contacts">
                    <div class="contacts-loading">
                        <div class="sk sk-contact"></div>
                        <div class="sk sk-contact"></div>
                        <div class="sk sk-contact"></div>
                    </div>
                </div>
                <div class="me">
                    <div class="ava me-ava" id="meAva">Z</div>
                    <div class="me-info">
                        <div class="me-name" id="meName">Zalikus</div>
                        <div class="me-sub" id="meSub"><span class="online-dot"></span> В сети</div>
                    </div>
                    <button class="settings-btn" id="settingsBtn" type="button" title="Настройки">⚙</button>
                </div>
            </nav>

            <!-- CONTENT -->
            <div class="main">

                <!-- CHAT VIEW -->
                <div id="viewChat" class="view active">
                    <div class="chat-hdr" id="chatHdr">
                        <div class="chat-hdr-ava" id="chatHdrAva">A</div>
                        <div class="chat-hdr-info">
                            <div class="chat-hdr-name" id="chatHdrName">Alice</div>
                            <div class="chat-hdr-sub" id="chatHdrSub">Личное сообщение</div>
                        </div>
                        <div class="chat-hdr-actions">
                            <button class="server-settings-btn chat-call-btn" id="chatCallBtn" type="button" title="Позвонить" hidden>📞</button>
                            <button class="server-settings-btn" id="serverSettingsBtn" type="button" title="Настройки сервера" hidden>⚙</button>
                        </div>
                        <div class="server-channel-list" id="serverChannelList" hidden></div>
                    </div>

                    <div class="voice-panel" id="voicePanel" hidden></div>

                    <div class="msgs" id="msgs"></div>

                    <div class="input-area">
                        <div class="draft-attachments" id="draftAttachments"></div>
                        <div class="input-bar" id="inputBar">
                            <button class="attach-btn" id="attachBtn" type="button" title="Прикрепить картинку или GIF">📎</button>
                            <input id="attachmentInput" type="file" accept="image/*,video/*,.gif,.webp,.png,.jpg,.jpeg,.mp4,.webm" multiple hidden>
                            <textarea id="msgInput" placeholder="Сообщение..." autocomplete="off" maxlength="4000" rows="1"></textarea>
                            <button class="send-btn" id="sendBtn" disabled>
                                <svg viewBox="0 0 24 24" fill="currentColor" width="17" height="17">
                                    <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- SETTINGS VIEW (CUSTOMIZATION, LOGS & CRYPTO) -->
                <div id="viewSettings" class="view">
                    <div class="logs-bar settings-topbar">
                        <div class="settings-topcopy">
                            <span class="settings-kicker">Центр управления</span>
                            <span class="logs-title">Настройки</span>
                            <p class="settings-lead">Кастомизация интерфейса, журнал событий и действия аккаунта в одном месте.</p>
                        </div>
                        <button class="btn-flat" id="closeSettings">Назад</button>
                    </div>
                    <div class="settings-body settings-scroll">
                        <div class="settings-shell">
                            <section class="settings-card settings-hero">
                                <div class="settings-hero-copy">
                                    <span class="settings-kicker">Быстрый обзор</span>
                                    <h2>Настройте внешний вид, проверьте журнал и управляйте параметрами без лишних переходов.</h2>
                                    <p>Меню разделено на понятные блоки, чтобы основные действия были под рукой и не терялись в длинном списке.</p>
                                </div>
                                <div class="settings-chips">
                                    <span class="settings-chip">Styler</span>
                                    <span class="settings-chip">Logs</span>
                                    <span class="settings-chip">Crypto</span>
                                    <span class="settings-chip">Account</span>
                                </div>
                            </section>

                            <section class="settings-card">
                                <div class="settings-card-head">
                                    <div>
                                        <span class="settings-kicker">Profile</span>
                                        <h3 class="settings-card-title">Аватар профиля</h3>
                                    </div>
                                    <span class="settings-card-note" id="avatarTargetLabel">sync</span>
                                </div>
                                <div class="avatar-editor">
                                    <div class="avatar-editor-preview">
                                        <div class="ava avatar-preview" id="avatarPreview">Z</div>
                                    </div>
                                    <div class="avatar-editor-copy">
                                        <p class="settings-help">Загрузите картинку для своего профиля — она сохранится на сервере и будет видна всем вашим собеседникам на других устройствах. После обновления аватар автоматически подтянется в списке контактов, шапке чата и профиле.</p>
                                        <div class="avatar-editor-actions">
                                            <button class="btn-flat avatar-upload-btn" id="avatarUploadBtn" type="button">Загрузить</button>
                                            <button class="btn-flat" id="avatarResetBtn" type="button">Сбросить аватар</button>
                                        </div>
                                    </div>
                                </div>
                            </section>

                            <div class="settings-grid">
                                <div class="settings-column">
                                    <section class="settings-card">
                                        <div class="settings-card-head">
                                            <div>
                                                <span class="settings-kicker">Styler</span>
                                                <h3 class="settings-card-title">Цветовая схема</h3>
                                            </div>
                                            <span class="settings-card-note">zali_styler</span>
                                        </div>
                                        <div class="theme-buttons settings-theme-grid">
                                            <button class="btn-theme theme-lime" data-theme="lime" type="button">Lime</button>
                                            <button class="btn-theme theme-cyber" data-theme="cyber" type="button">Cyberpunk</button>
                                            <button class="btn-theme theme-matrix" data-theme="matrix" type="button">Matrix</button>
                                            <button class="btn-theme theme-ocean" data-theme="ocean" type="button">Ocean</button>
                                            <button class="btn-theme theme-mono" data-theme="mono" type="button">Monochrome</button>
                                        </div>
                                    </section>

                                    <section class="settings-card">
                                        <div class="settings-card-head">
                                            <div>
                                                <span class="settings-kicker">Styler</span>
                                                <h3 class="settings-card-title">Закругление сообщений</h3>
                                            </div>
                                            <span class="settings-card-note" id="radiusVal">18px</span>
                                        </div>
                                        <div class="settings-control-box">
                                            <input type="range" id="sliderRadius" min="0" max="24" value="18" class="settings-range">
                                        </div>
                                    </section>

                                    <section class="settings-card">
                                            <div class="settings-card-head">
                                                <div>
                                                    <span class="settings-kicker">Styler</span>
                                                    <h3 class="settings-card-title">Интервал сообщений</h3>
                                                </div>
                                            <span class="settings-card-note" id="msgGapVal">1px</span>
                                        </div>
                                        <div class="settings-control-box">
                                            <input type="range" id="sliderMsgGap" min="0" max="8" value="1" class="settings-range">
                                        </div>
                                    </section>

                                    <section class="settings-card">
                                        <div class="settings-card-head">
                                            <div>
                                                <span class="settings-kicker">Contacts</span>
                                                <h3 class="settings-card-title">Выпадающий список контактов</h3>
                                            </div>
                                            <span class="settings-card-note">Поведение</span>
                                        </div>
                                        <div class="settings-stack">
                                            <div class="settings-control-row">
                                                <span class="settings-label">Размер</span>
                                                <input type="range" id="sliderSuggestHeight" min="220" max="520" value="340" class="settings-range">
                                                <span class="settings-value" id="suggestHeightVal">340px</span>
                                            </div>
                                            <div class="settings-control-row">
                                                <span class="settings-label">Контраст</span>
                                                <input type="range" id="sliderSuggestContrast" min="40" max="100" value="85" class="settings-range">
                                                <span class="settings-value" id="suggestContrastVal">85%</span>
                                            </div>
                                            <div class="settings-control-row">
                                                <span class="settings-label">Плотность</span>
                                                <input type="range" id="sliderSuggestDensity" min="0" max="24" value="12" class="settings-range">
                                                <span class="settings-value" id="suggestDensityVal">12</span>
                                            </div>
                                        </div>
                                    </section>
                                </div>

                                <div class="settings-column">
                                    <section class="settings-card settings-card--logs">
                                        <div class="settings-card-head settings-card-head--tight">
                                            <div>
                                                <span class="settings-kicker">Telemetry</span>
                                                <h3 class="settings-card-title">Журнал событий</h3>
                                            </div>
                                            <button class="btn-flat" id="clearLogs" type="button">Очистить</button>
                                        </div>
                                        <div class="log-body settings-log-body" id="logBody"></div>
                                    </section>

                                    <section class="settings-card">
                                        <div class="settings-card-head">
                                            <div>
                                                <span class="settings-kicker">Security</span>
                                                <h3 class="settings-card-title">Ключ шифрования</h3>
                                            </div>
                                            <span class="settings-card-note">zali_crypto</span>
                                        </div>
                                        <div class="settings-stack">
                                            <input type="text" id="inputCryptoKey" class="settings-input" placeholder="Введите общий E2E-ключ">
                                            <p class="settings-help">Текущий ключ: <code id="currentCryptoKeyValue" class="crypto-key-value">не задан</code></p>
                                            <p class="settings-help" id="currentCryptoKeyMeta">Контекст: общий ключ</p>
                                            <p class="settings-help">Измените секретную фразу для E2E-шифрования. Для чтения переписки собеседники должны использовать одинаковый ключ, и он не должен храниться в коде.</p>
                                        </div>
                                    </section>

                                    <section class="settings-card">
                                        <div class="settings-card-head">
                                            <div>
                                                <span class="settings-kicker">Network</span>
                                                <h3 class="settings-card-title">Сервер и WebRTC</h3>
                                            </div>
                                            <span class="settings-card-note">public</span>
                                        </div>
                                        <div class="settings-stack">
                                            <input type="url" id="inputApiBaseUrl" class="settings-input" placeholder="http://localhost:3000">
                                            <input type="url" id="inputWsBaseUrl" class="settings-input" placeholder="ws://localhost:3000/ws">
                                            <textarea id="inputIceServers" class="settings-textarea settings-textarea--compact" rows="5" placeholder='[{"urls":["stun:stun.l.google.com:19302"]},{"urls":"turns:turn.example.com:5349","username":"user","credential":"pass"}]'></textarea>
                                            <div class="settings-control-box">
                                                <div class="settings-stack">
                                                    <input type="url" id="inputTurnUrl" class="settings-input" placeholder="turns:turn.example.com:5349">
                                                    <input type="text" id="inputTurnUsername" class="settings-input" placeholder="TURN username">
                                                    <input type="password" id="inputTurnCredential" class="settings-input" placeholder="TURN credential">
                                                    <label class="server-toggle settings-toggle">
                                                        <input id="inputTurnRelayOnly" type="checkbox" checked>
                                                        <span>
                                                            <strong>Relay only</strong>
                                                            <small>Использовать TURN как основной путь для медиа</small>
                                                        </span>
                                                    </label>
                                                    <div class="settings-inline-actions">
                                                        <button class="btn-flat" id="networkTurnApplyBtn" type="button">Добавить TURN</button>
                                                        <button class="btn-flat" id="networkTurnFillBtn" type="button">Заполнить пример</button>
                                                    </div>
                                                    <p class="settings-help">TURN помогает звонкам работать вне локальной сети. Обычно нужен `turns://` адрес, логин и credential от coturn.</p>
                                                </div>
                                            </div>
                                            <div class="settings-inline-actions">
                                                <button class="btn-flat" id="networkConfigSaveBtn" type="button">Сохранить сеть</button>
                                                <button class="btn-flat" id="networkConfigResetBtn" type="button">Сбросить</button>
                                            </div>
                                            <p class="settings-help">API и WebSocket лучше указывать публичными `https`/`wss` адресами. Для работы через интернет добавьте TURN-сервер в список ICE.</p>
                                        </div>
                                    </section>

                                    <section class="settings-card settings-card--danger">
                                        <div class="settings-card-head">
                                            <div>
                                                <span class="settings-kicker">Account</span>
                                                <h3 class="settings-card-title">Сеанс</h3>
                                            </div>
                                            <span class="settings-card-note">Безопасно</span>
                                        </div>
                                        <p class="settings-help">Завершите текущий вход, если хотите переключить аккаунт или выйти из гостевого режима.</p>
                                        <button class="btn-flat settings-logout" id="settingsLogoutBtn" type="button">Выйти из аккаунта</button>
                                    </section>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="server-overlay" id="serverOverlay" hidden>
        <div class="server-modal" role="dialog" aria-modal="true" aria-labelledby="serverModalTitle">
            <div class="server-modal-head">
                <div class="server-modal-headcopy">
                    <span class="server-modal-kicker" id="serverModalKicker">Создание сервера</span>
                    <h2 id="serverModalTitle">Создать сервер</h2>
                    <p id="serverModalHint">Настройте имя, оформление и права доступа.</p>
                </div>
                <button class="server-modal-close" id="serverModalClose" type="button" aria-label="Закрыть">×</button>
            </div>

            <div class="server-modal-grid">
                <section class="server-modal-card" id="serverBasicsCard">
                    <div class="settings-card-head settings-card-head--tight">
                        <div>
                            <span class="settings-kicker">Basics</span>
                            <h3 class="settings-card-title">Параметры сервера</h3>
                        </div>
                        <span class="settings-card-note" id="serverModalModeNote">create</span>
                    </div>
                    <div class="server-form">
                        <input id="serverNameInput" class="settings-input" type="text" maxlength="64" placeholder="Название сервера">
                        <input id="serverIconInput" class="settings-input" type="text" maxlength="8" placeholder="Иконка, символ или эмодзи">
                        <div class="color-picker">
                            <div class="color-wheel" id="serverColorWheel" tabindex="0" aria-label="Цвет сервера">
                                <div class="color-wheel-thumb"></div>
                                <div class="color-wheel-center">RGB</div>
                            </div>
                            <div class="color-picker-side">
                                <input id="serverColorInput" type="hidden" value="#cbff00">
                                <input id="serverColorHexInput" class="settings-input color-hex-input" type="text" maxlength="7" value="#cbff00" aria-label="HEX цвет сервера">
                                <p class="settings-help color-picker-help">Выберите цвет колесом или введите HEX.</p>
                            </div>
                        </div>
                        <textarea id="serverDescriptionInput" class="settings-textarea" rows="4" maxlength="180" placeholder="Описание сервера"></textarea>
                        <label class="server-toggle">
                            <input id="serverPublicInput" type="checkbox" checked>
                            <span>
                                <strong>Публичный сервер</strong>
                                <small>Виден всем пользователям</small>
                            </span>
                        </label>
                    </div>
                    <div class="server-assets">
                        <div class="server-asset-card">
                            <div class="server-asset-preview server-avatar-preview" id="serverAvatarPreview">S</div>
                            <div class="server-asset-copy">
                                <div class="server-asset-title">Аватар сервера</div>
                                <div class="server-asset-sub">Круглая иконка в списке серверов</div>
                                <div class="server-asset-actions">
                                    <button class="btn-flat" id="serverAvatarUploadBtn" type="button">Загрузить</button>
                                    <button class="btn-flat" id="serverAvatarRemoveBtn" type="button">Удалить</button>
                                </div>
                            </div>
                        </div>
                        <div class="server-asset-card server-banner-card">
                            <div class="server-asset-preview server-banner-preview" id="serverBannerPreview">BAN</div>
                            <div class="server-asset-copy">
                                <div class="server-asset-title">Баннер сервера</div>
                                <div class="server-asset-sub">Широкая шапка для сервера</div>
                                <div class="server-asset-actions">
                                    <button class="btn-flat" id="serverBannerUploadBtn" type="button">Загрузить</button>
                                    <button class="btn-flat" id="serverBannerRemoveBtn" type="button">Удалить</button>
                                </div>
                            </div>
                        </div>
                        <div class="server-link-card">
                            <div class="server-asset-title">Ссылка входа</div>
                            <div class="server-asset-sub">Сюда можно вставить адрес сервера, по которому будут входить пользователи.</div>
                            <div class="server-link-row">
                                <input id="serverJoinLinkInput" class="settings-input" type="text" placeholder="Ссылка на сервер">
                                <button class="btn-flat" id="serverJoinLinkGenerateBtn" type="button">Сгенерировать</button>
                                <button class="btn-flat" id="serverJoinLinkCopyBtn" type="button">Копировать</button>
                            </div>
                        </div>
                    </div>
                </section>

                <section class="server-modal-card" id="serverRolesCard">
                    <div class="settings-card-head settings-card-head--tight">
                        <div>
                            <span class="settings-kicker">Roles</span>
                            <h3 class="settings-card-title">Роли сервера</h3>
                        </div>
                        <span class="settings-card-note" id="serverRolesCount">0</span>
                    </div>
                    <div class="server-role-create">
                        <input id="serverRoleNameInput" class="settings-input" type="text" maxlength="64" placeholder="Название роли" autocomplete="off" autocapitalize="none" spellcheck="false" inputmode="text">
                        <button class="btn-flat server-role-create-btn" id="serverRoleCreateBtn" type="button">Создать роль</button>
                        <div class="color-picker color-picker--compact">
                            <div class="color-wheel color-wheel--small" id="serverRoleColorWheel" tabindex="0" aria-label="Цвет роли">
                                <div class="color-wheel-thumb"></div>
                                <div class="color-wheel-center">RGB</div>
                            </div>
                            <div class="color-picker-side">
                                <input id="serverRoleColorInput" type="hidden" value="#cbff00">
                                <input id="serverRoleColorHexInput" class="settings-input color-hex-input" type="text" maxlength="7" value="#cbff00" aria-label="HEX цвет роли">
                            </div>
                        </div>
                    </div>
                    <div class="server-role-perms">
                        <label class="server-perm-row">
                            <span>Может читать каналы</span>
                            <input id="serverRolePermView" type="checkbox" checked>
                        </label>
                        <label class="server-perm-row">
                            <span>Может писать</span>
                            <input id="serverRolePermSend" type="checkbox" checked>
                        </label>
                        <label class="server-perm-row">
                            <span>Может управлять</span>
                            <input id="serverRolePermManage" type="checkbox">
                        </label>
                    </div>
                    <div class="server-roles-list" id="serverRolesList"></div>
                </section>

                <section class="server-modal-card" id="serverMembersCard">
                    <div class="settings-card-head settings-card-head--tight">
                        <div>
                            <span class="settings-kicker">Members</span>
                            <h3 class="settings-card-title">Участники и роли</h3>
                        </div>
                        <span class="settings-card-note" id="serverMembersCount">0</span>
                    </div>
                    <div class="server-member-add">
                        <input id="serverMemberInput" class="settings-input" type="text" maxlength="64" placeholder="Логин участника">
                        <select id="serverMemberRole" class="settings-input"></select>
                        <button class="btn-flat" id="serverMemberAddBtn" type="button">Добавить</button>
                    </div>
                    <div class="server-members-list" id="serverMembersList"></div>
                </section>

                <section class="server-modal-card server-discover-card" id="serverDiscoverCard" hidden>
                    <div class="settings-card-head settings-card-head--tight">
                        <div>
                            <span class="settings-kicker">Public</span>
                            <h3 class="settings-card-title">Публичные серверы</h3>
                        </div>
                        <div class="server-discover-head-actions">
                            <span class="settings-card-note" id="serverDiscoverCount">0</span>
                            <button class="btn-flat" id="serverDiscoverRefreshBtn" type="button">Обновить</button>
                        </div>
                    </div>
                    <div class="server-discover-toolbar">
                        <input id="serverDiscoverQuery" class="settings-input" type="text" placeholder="Поиск публичных серверов">
                    </div>
                    <div class="server-discover-list" id="serverDiscoverList"></div>
                </section>
            </div>

            <div class="server-modal-error" id="serverModalError"></div>
            <div class="server-modal-actions">
                <button class="btn-flat" id="serverModalCancel" type="button">Отмена</button>
                <button class="btn-flat server-delete-btn" id="serverDeleteBtn" type="button" hidden>Удалить сервер</button>
                <button class="auth-btn primary" id="serverSaveBtn" type="button">Создать</button>
            </div>
        </div>
    </div>

    <div class="auth-overlay visible" id="authOverlay">
        <div class="auth-card">
            <div class="auth-brand">ZaliMessenger</div>
            <h1 id="authTitle">Вход в аккаунт</h1>
            <p id="authHint">Войдите, чтобы синхронизировать сообщения и контакты.</p>
            <form class="auth-form" id="authForm">
                <input id="authUsername" class="auth-input" type="text" placeholder="Логин" autocomplete="off" autocapitalize="none" spellcheck="false">
                <input id="authPassword" class="auth-input" type="password" placeholder="Пароль" autocomplete="off">
                <div class="auth-actions">
                    <button id="authLoginBtn" class="auth-btn primary" type="submit">Войти</button>
                </div>
                <div class="auth-network">
                    <div class="auth-network-head">
                        <div class="auth-network-title">Адрес сервера</div>
                        <div class="auth-network-note" id="authNetworkNote">Автоматически подставляется из настроек</div>
                    </div>
                    <div class="auth-network-row">
                        <input id="authApiBaseUrl" class="auth-input auth-input--compact" type="url" placeholder="http://127.0.0.1:3000" autocomplete="off">
                        <button id="authNetworkSaveBtn" class="auth-btn auth-btn--ghost" type="button">Сохранить</button>
                    </div>
                    <p class="auth-network-help">Если сервер не найден, укажите публичный `https://` адрес и попробуйте снова.</p>
                </div>
                <div class="auth-footer">
                    <button id="authGuestBtn" class="auth-link" type="button">Продолжить как гость</button>
                    <button id="authRegisterBtn" class="auth-link" type="button">Создать аккаунт</button>
                </div>
                <div class="auth-error" id="authError"></div>
            </form>
        </div>
    </div>
    <script>
// --- MODULE: bus.js ---
class ZaliBus {
    constructor() {
        this.handlers = new Map(); // "address:command" -> function
        this.listeners = new Map(); // eventName -> Array<function>
    }

    /**
     * Register a command handler for a specific module namespace and command.
     * @param {string} address - Namespace (e.g. 'zali_crypto')
     * @param {string} command - Action name (e.g. 'encrypt')
     * @param {Function} handler - The handler function
     */
    registerCommand(address, command, handler) {
        const key = `${address}:${command}`;
        if (this.handlers.has(key)) {
            console.warn(`[zali_bus] Command handler for ${key} is already registered. Overwriting.`);
        }
        this.handlers.set(key, handler);
    }

    /**
     * Call a registered command and return its result.
     * @param {string} addressCommand - In format "namespace:command"
     * @param  {...any} args - Arguments passed to the handler
     */
    send(addressCommand, ...args) {
        if (this.handlers.has(addressCommand)) {
            const handler = this.handlers.get(addressCommand);
            return handler(...args);
        } else {
            console.error(`[zali_bus] No handler registered for command: ${addressCommand}`);
            return null;
        }
    }

    /**
     * Register a listener for an event broadcasted by pub/sub.
     * @param {string} event - Event name
     * @param {Function} callback - Callback function
     */
    subscribe(event, callback) {
        if (!this.listeners.has(event)) {
            this.listeners.set(event, []);
        }
        this.listeners.get(event).push(callback);
    }

    /**
     * Publish an event to all subscribers.
     * @param {string} event - Event name
     * @param  {...any} args - Arguments passed to the subscribers
     */
    publish(event, ...args) {
        if (this.listeners.has(event)) {
            this.listeners.get(event).forEach(cb => {
                try {
                    cb(...args);
                } catch (e) {
                    console.error(`[zali_bus] Error in subscriber for event ${event}:`, e);
                }
            });
        }
    }
}
window.ZaliBus = ZaliBus;


// --- MODULE: loader.js ---
class ZaliLoader {
    constructor() {
        this.bus = new ZaliBus();
        this.modules = new Map();
    }

    /**
     * Registers a module.
     * @param {Object} module - Module instance must have a name string and optionally an init() method.
     */
    register(module) {
        if (!module || !module.name) {
            console.error("[zali_loader] Failed to register invalid module:", module);
            return;
        }
        this.modules.set(module.name, module);
        console.log(`[zali_loader] Module registered: ${module.name}`);
    }

    /**
     * Initializes all registered modules.
     */
    init() {
        console.log("[zali_loader] Bootstrapping modules...");

        // Register a system command to retrieve module info
        this.bus.registerCommand('loader', 'get_modules', () => Array.from(this.modules.keys()));

        // Initialize each module
        for (let [name, module] of this.modules) {
            try {
                if (typeof module.init === 'function') {
                    module.init(this);
                    console.log(`[zali_loader] Module initialized successfully: ${name}`);
                }
            } catch (e) {
                console.error(`[zali_loader] Error during initialization of module ${name}:`, e);
            }
        }

        console.log("[zali_loader] Bootstrap finished.");
    }
}
window.ZaliLoader = ZaliLoader;


// --- MODULE: styler.js ---
class ZaliStyler {
    constructor() {
        this.name = 'zali_styler';
        this.currentKey = '';
        
        // Custom premium themes matching rich aesthetics
        this.themes = {
            lime: {
                '--accent-rgb': '203,255,0',
                '--lime': '#cbff00',
                '--lime-dim': 'rgba(203,255,0,.1)',
                '--lime-glow': 'rgba(203,255,0,.25)',
                '--lime-soft': 'rgba(203,255,0,.06)',
                '--bg': '#090b0e',
                '--sidebar': 'rgba(11,13,16,.9)',
                '--text': '#f2f2f2',
                '--text2': 'rgba(255,255,255,.5)',
                '--text3': 'rgba(255,255,255,.25)',
                '--border': 'rgba(255,255,255,.07)',
            },
            cyber: {
                '--accent-rgb': '255,0,85',
                '--lime': '#ff0055',
                '--lime-dim': 'rgba(255,0,85,.15)',
                '--lime-glow': 'rgba(255,0,85,.35)',
                '--lime-soft': 'rgba(255,0,85,.08)',
                '--bg': '#0a0512',
                '--sidebar': 'rgba(20,10,32,.92)',
                '--text': '#00ffcc',
                '--text2': 'rgba(0,255,204,.6)',
                '--text3': 'rgba(0,255,204,.3)',
                '--border': 'rgba(0,255,204,.15)',
            },
            matrix: {
                '--accent-rgb': '0,255,51',
                '--lime': '#00ff33',
                '--lime-dim': 'rgba(0,255,51,.15)',
                '--lime-glow': 'rgba(0,255,51,.35)',
                '--lime-soft': 'rgba(0,255,51,.07)',
                '--bg': '#020502',
                '--sidebar': 'rgba(4,16,6,.95)',
                '--text': '#39ff14',
                '--text2': 'rgba(57,255,20,.65)',
                '--text3': 'rgba(57,255,20,.35)',
                '--border': 'rgba(57,255,20,.2)',
            },
            ocean: {
                '--accent-rgb': '0,210,255',
                '--lime': '#00d2ff',
                '--lime-dim': 'rgba(0,210,255,.15)',
                '--lime-glow': 'rgba(0,210,255,.3)',
                '--lime-soft': 'rgba(0,210,255,.07)',
                '--bg': '#050f1e',
                '--sidebar': 'rgba(6,22,38,.93)',
                '--text': '#e0f5ff',
                '--text2': 'rgba(224,245,255,.6)',
                '--text3': 'rgba(224,245,255,.3)',
                '--border': 'rgba(224,245,255,.1)',
            },
            mono: {
                '--accent-rgb': '255,255,255',
                '--lime': '#ffffff',
                '--lime-dim': 'rgba(255,255,255,.15)',
                '--lime-glow': 'rgba(255,255,255,.25)',
                '--lime-soft': 'rgba(255,255,255,.05)',
                '--bg': '#121212',
                '--sidebar': 'rgba(26,26,26,.9)',
                '--text': '#ffffff',
                '--text2': 'rgba(255,255,255,.6)',
                '--text3': 'rgba(255,255,255,.35)',
                '--border': 'rgba(255,255,255,.12)',
            }
        };

        // CSS variable defaults that can be modified by the styler
        this.currentVars = {};
        this.currentRadius = 18;
        this.saveTimer = null;
    }

    init(loader) {
        this.bus = loader.bus;

        // Register commands on the bus
        this.bus.registerCommand('zali_styler', 'set_theme',         (themeName) => this.setTheme(themeName));
        this.bus.registerCommand('zali_styler', 'set_border_radius', (radius)    => this.setBorderRadius(radius));
        this.bus.registerCommand('zali_styler', 'set_variable',      (name, val) => this.setVariable(name, val));
        this.bus.registerCommand('zali_styler', 'get_themes',        ()          => Object.keys(this.themes));
        this.bus.registerCommand('zali_styler', 'save_style',        ()          => this.saveStyleToNative());
        this.bus.registerCommand('zali_styler', 'set_key',           (key)       => this.setKey(key));

        // Load saved style from UserDefaults if available
        this._loadSavedStyle();

        const storedKey = this._loadStoredKey();
        if (storedKey) {
            this.setKey(storedKey);
        }

        // Initial setup with the lime theme as default
        this.setTheme('lime', { persist: false });
    }

    _loadStoredKey() {
        try {
            const stored = (localStorage.getItem('zali_crypto_key_v1') || '').trim();
            if (stored) return stored;
        } catch (e) {}
        return (window.__ZALI_SAVED_KEY || '').trim() || 'ZALI_SECRET_E2E_KEY_2026';
    }

    /**
     * Try to load persisted custom CSS from the app's saved state.
     * The native layer can inject `window.__ZALI_SAVED_CSS` at startup.
     */
    _loadSavedStyle() {
        if (window.__ZALI_SAVED_CSS) {
            // Inject the saved CSS blob as a <style> tag override
            let styleTag = document.getElementById('zali-custom-style');
            if (!styleTag) {
                styleTag = document.createElement('style');
                styleTag.id = 'zali-custom-style';
                document.head.appendChild(styleTag);
            }
            styleTag.textContent = window.__ZALI_SAVED_CSS;
            this._ingestSavedVars(window.__ZALI_SAVED_CSS);
            console.log('[zali_styler] Восстановлены сохраненные стили из UserDefaults');
        }
    }

    _ingestSavedVars(cssText) {
        const varRegex = /(--[A-Za-z0-9-_]+)\s*:\s*([^;]+);/g;
        let match;
        while ((match = varRegex.exec(cssText)) !== null) {
            const [, name, value] = match;
            this.currentVars[name] = value.trim();
        }

        const radiusValue = this.currentVars['--r-msg'];
        if (radiusValue) {
            const parsed = parseInt(radiusValue, 10);
            if (!Number.isNaN(parsed)) {
                this.currentRadius = parsed;
            }
        }
    }

    nativeBridge() {
        return window.__ZALI_NATIVE || null;
    }

    nativeSupports(capability) {
        return !!this.nativeBridge()?.supports?.[capability];
    }

    postNativeMessage(payload) {
        const bridge = this.nativeBridge();
        if (!bridge || typeof bridge.postMessage !== 'function') return false;
        return !!bridge.postMessage(payload);
    }

    setTheme(themeName, options = {}) {
        const theme = this.themes[themeName];
        if (!theme) {
            console.warn(`[zali_styler] Тема "${themeName}" не найдена`);
            return false;
        }

        for (const [key, val] of Object.entries(theme)) {
            this.setVariable(key, val, { persist: false });
            this.currentVars[key] = val;
        }

        console.log(`[zali_styler] Установлена цветовая схема "${themeName}"`);
        if (options.persist !== false) this.saveStyleToNative();
        return true;
    }

    setBorderRadius(radius) {
        const radStr = String(radius).endsWith('px') ? radius : `${radius}px`;
        this.currentRadius = parseInt(radius, 10);
        this.setVariable('--r-msg', radStr, { persist: false });
        this.currentVars['--r-msg'] = radStr;
        console.log(`[zali_styler] Закругление углов сообщений: ${radStr}`);
        this.saveStyleToNative();
    }

    setVariable(name, val, options = {}) {
        document.documentElement.style.setProperty(name, val);
        this.currentVars[name] = val;
        if (options.persist !== false) {
            this.queueSaveStyle();
        }
    }

    queueSaveStyle() {
        if (this.saveTimer) {
            clearTimeout(this.saveTimer);
        }
        this.saveTimer = setTimeout(() => {
            this.saveTimer = null;
            this.saveStyleToNative();
        }, 120);
    }

    setKey(key) {
        this.currentKey = (key || '').trim();
        try {
            if (this.currentKey) {
                localStorage.setItem('zali_crypto_key_v1', this.currentKey);
            } else {
                localStorage.removeItem('zali_crypto_key_v1');
            }
        } catch (e) {}

        try {
            window.__ZALI_SAVED_KEY = this.currentKey;
        } catch (e) {}

        const input = document.getElementById('inputCryptoKey');
        if (input && input.value !== this.currentKey) {
            input.value = this.currentKey;
        }
        this.updateKeyDisplay();

        // Notify native Swift layer to update the decryption key
        if (this.nativeSupports('setKey')) {
            this.postNativeMessage({
                type: 'SET_KEY',
                key: this.currentKey
            });
        }
        if (this.bus) {
            this.bus.send('zali_interface:refresh_after_key');
        }
        console.log('[zali_styler] Ключ E2E обновлён и передан в native backend');
    }

    updateKeyDisplay(meta = null) {
        const valueEl = document.getElementById('currentCryptoKeyValue');
        const metaEl = document.getElementById('currentCryptoKeyMeta');
        const key = (this.currentKey || '').trim() || (window.__ZALI_SAVED_KEY || '').trim() || 'не задан';
        if (valueEl) valueEl.textContent = key;
        if (metaEl) {
            metaEl.textContent = meta || 'Контекст: общий ключ';
        }
    }

    /**
     * Compiles all current CSS variable overrides into a :root {} block
     * and sends them to the native Swift layer for persistence in Web/style.css.
     */
    saveStyleToNative() {
        if (!this.nativeSupports('saveStyle')) {
            console.log('[zali_styler] Native bridge не обнаружен, сохранение пропущено');
            return;
        }

        // Build :root override block from all current vars
        const varLines = Object.entries(this.currentVars)
            .map(([k, v]) => `    ${k}: ${v};`)
            .join('\n');

        const cssBlock = `:root {\n${varLines}\n    --r-msg: ${this.currentRadius}px;\n}\n`;

        this.postNativeMessage({
            type: 'SAVE_STYLE',
            css: cssBlock
        });

        console.log('[zali_styler] Стили отправлены на сохранение в Web/style.css');
    }
}
window.ZaliStyler = ZaliStyler;


// --- MODULE: interface.js ---
class ZaliInterface {
    constructor() {
        this.name = 'zali_interface';
        
        // Private state strictly encapsulated inside the interface module
        this.S = {
            chats:   {},        // { username: [messages] }
            users:   [],
            contacts: [],
            current: null,
            unread:  {},
            wsOn:    false,
            loading: true,
            searchQ: '',
            navMode: 'dm',
            activeServer: null,
            activeChannel: null,
            servers: [],
            publicServers: [],
            serverChats: {},
            draftAttachments: [],
            serverModal: {
                mode: 'create',
                serverId: null,
                members: [],
                roles: [],
                draftRoles: [],
                joinLink: '',
                selectedChannelId: null,
                channelPermissions: [],
                loading: false,
                saving: false,
                error: '',
            },
            session: {
                username: 'Zalikus',
                token: null,
                guest: true,
            },
            auth: {
                visible: true,
                loading: false,
                error: '',
                mode: 'login',
                fieldsCleared: false,
            },
        };
        this.tenorCache = new Map();
        this.tenorPending = new Set();
        this.avatarCache = new Map();
        this.avatarRequests = new Map();
        this.avatarFetchSeq = new Map();
        this.serverAssetCache = new Map();
        this.serverAssetRequests = new Map();
        this.serverAssetFetchSeq = new Map();
        this.colorWheelBindings = new Set();
        this.messageAnimSeen = new Set();
        this.mediaSizeCache = new Map();
        this.reactionOptions = ['👍', '❤️', '😂', '😮', '😢', '🔥'];
        this.voice = {
            supported: !!(window.RTCPeerConnection && navigator.mediaDevices && navigator.mediaDevices.getUserMedia),
            roomId: '',
            roomType: '',
            serverId: '',
            channelId: '',
            targetUser: '',
            inviter: '',
            status: 'idle',
            muted: false,
            localStream: null,
            peerConnections: new Map(),
            remoteAudios: new Map(),
            participants: [],
            outgoingInvite: null,
            incomingInvite: null,
            socket: null,
            socketReady: false,
            callTrack: null,
            audioContext: null,
            playbackUnlocked: false,
            meterRaf: 0,
            meterLocal: null,
            meterRemote: new Map(),
            remotePlaybackNodes: new Map(),
            meterLevels: {
                local: 0,
                remote: 0,
            },
            traceLines: [],
        };
        this.voiceSocketGeneration = 0;
        this.voiceSocketReconnectTimer = null;
        this.voiceSocketReconnectDelayMs = 1000;
        this.pendingMessagesScroll = null;
        this.pendingOutboxFlushTimer = null;
        this.messageSyncTimer = null;
        this.sessionBootstrapInProgress = false;

        const cachedMessages = this.loadStoredMessageCache();
        this.S.chats = cachedMessages.chats || {};
        this.S.serverChats = cachedMessages.serverChats || {};
    }

    init(loader) {
        this.bus = loader.bus;
        this.S.navMode = this.loadStoredNavMode();

        // Register UI update commands on the bus
        this.bus.registerCommand('zali_interface', 'receive_message', (data) => this.receiveMessage(data));
        this.bus.registerCommand('zali_interface', 'set_users', (users) => this.setUsers(users));
        this.bus.registerCommand('zali_interface', 'set_contacts', (contacts) => this.setContacts(contacts));
        this.bus.registerCommand('zali_interface', 'set_session', (session) => this.setSession(session));
        this.bus.registerCommand('zali_interface', 'load_history', (messages) => this.loadHistory(messages));
        this.bus.registerCommand('zali_interface', 'load_server_history', (payload) => this.loadServerHistory(payload));
        this.bus.registerCommand('zali_interface', 'refresh_after_key', () => this.refreshAfterKey());
        this.bus.registerCommand('zali_interface', 'set_loading', (on) => this.setLoading(on));
        this.bus.registerCommand('zali_interface', 'set_connection_status', (connected) => this.setConnectionStatus(connected));
        this.bus.registerCommand('zali_interface', 'on_send_success', (clientId) => this.onSendSuccess(clientId));
        this.bus.registerCommand('zali_interface', 'on_send_error', (clientId) => this.onSendError(clientId));
        this.bus.registerCommand('zali_interface', 'reaction_updated', (data) => this.onReactionUpdated(data));
        this.bus.registerCommand('zali_interface', 'avatar_updated', (data) => this.handleAvatarUpdated(data));
        this.bus.registerCommand('zali_interface', 'tenor_resolved', (payload) => this.onTenorResolved(payload));
        this.bus.registerCommand('zali_interface', 'add_log_entry', (data) => this.addLogEntry(data));
        this.bus.registerCommand('zali_interface', 'voice_event', (payload) => this.handleVoiceEvent(payload));

        // Bind events after DOM is loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.bindEvents());
        } else {
            this.bindEvents();
        }

        this.bootstrapSession();
        if (!this.avatarRefreshTimer) {
            this.avatarRefreshTimer = setInterval(() => this.refreshVisibleAvatars(), 120000);
        }
        if (!this.messageSyncTimer) {
            this.messageSyncTimer = setInterval(() => this.syncActiveConversation(), 8000);
        }
        window.addEventListener('focus', () => this.syncActiveConversation({ force: true }));
    }

    // --- HTML Helper Utilities ---
    esc(s) {
        if (s == null) return '';
        return String(s)
            .replace(/&/g,'&amp;').replace(/</g,'&lt;')
            .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
    }

    fmtTime(iso) {
        if (!iso) return '';
        try { return new Date(iso).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'}); }
        catch(e) { return ''; }
    }

    fmtDate(iso) {
        if (!iso) return '';
        try {
            const d = new Date(iso), now = new Date();
            const yest = new Date(); yest.setDate(yest.getDate()-1);
            if (d.toDateString() === now.toDateString())  return 'Сегодня';
            if (d.toDateString() === yest.toDateString()) return 'Вчера';
            return d.toLocaleDateString('ru-RU',{day:'numeric',month:'long'});
        } catch(e) { return ''; }
    }

    nativeBridge() {
        return window.__ZALI_NATIVE || null;
    }

    hasNativeBridge() {
        return !!this.nativeBridge()?.available;
    }

    nativeSupports(capability) {
        return !!this.nativeBridge()?.supports?.[capability];
    }

    postNativeMessage(payload) {
        const bridge = this.nativeBridge();
        if (!bridge || typeof bridge.postMessage !== 'function') return false;
        return !!bridge.postMessage(payload);
    }

    trace(message) {
        try {
            console.log(`[ZALI][WEB] ${message}`);
        } catch (e) {}
    }

    myName() {
        return this.S.session?.username || 'Zalikus';
    }

    requestMessagesScroll(position = 'bottom') {
        this.pendingMessagesScroll = position === 'top' ? 'top' : 'bottom';
    }

    applyPendingMessagesScroll(box) {
        if (!box || !this.pendingMessagesScroll) return;
        const target = this.pendingMessagesScroll;
        this.pendingMessagesScroll = null;
        requestAnimationFrame(() => {
            if (!box.isConnected) return;
            box.scrollTop = target === 'bottom' ? box.scrollHeight : 0;
        });
    }

    isMessagesNearBottom(box, threshold = 56) {
        if (!box) return true;
        return (box.scrollHeight - (box.scrollTop + box.clientHeight)) <= threshold;
    }

    navModeStorageKey() {
        return 'zali_nav_mode_v1';
    }

    activeServerStorageKey() {
        return 'zali_active_server_v1';
    }

    activeChannelStorageKey() {
        return 'zali_active_channel_v1';
    }

    currentContactStorageKey() {
        return 'zali_current_contact_v1';
    }

    serverChatsStorageKey() {
        return 'zali_server_chats_v1';
    }

    messageCacheStorageKey() {
        return 'zali_message_cache_v1';
    }

    networkConfigStorageKey() {
        return 'zali_network_config_v1';
    }

    cryptoKeyStorageKey() {
        return 'zali_crypto_key_v1';
    }

    authStorageKey() {
        return 'zali_session_v1';
    }

    lastAuthStorageKey() {
        return 'zali_last_session_v1';
    }

    pendingOutboxStorageKey() {
        return 'zali_pending_outbox_v1';
    }

    loadStoredMessageCache() {
        try {
            const raw = localStorage.getItem(this.messageCacheStorageKey());
            if (!raw) return { chats: {}, serverChats: {} };
            const parsed = JSON.parse(raw);
            const chats = parsed && typeof parsed === 'object' && parsed.chats && typeof parsed.chats === 'object'
                ? parsed.chats
                : {};
            const serverChats = parsed && typeof parsed === 'object' && parsed.serverChats && typeof parsed.serverChats === 'object'
                ? parsed.serverChats
                : {};
            return {
                chats: Object.fromEntries(Object.entries(chats).filter(([, msgs]) => Array.isArray(msgs)).map(([peer, msgs]) => [peer, msgs.filter(msg => msg && typeof msg === 'object')])),
                serverChats: Object.fromEntries(Object.entries(serverChats).filter(([, msgs]) => Array.isArray(msgs)).map(([peer, msgs]) => [peer, msgs.filter(msg => msg && typeof msg === 'object')])),
            };
        } catch (e) {
            return { chats: {}, serverChats: {} };
        }
    }

    saveStoredMessageCache() {
        try {
            localStorage.setItem(this.messageCacheStorageKey(), JSON.stringify({
                chats: this.S.chats,
                serverChats: this.S.serverChats,
            }));
        } catch (e) {}
    }

    normalizeDmChatStore() {
        const me = String(this.myName() || '').trim();
        if (!me) return false;

        const normalized = {};
        let changed = false;

        const pushMessage = (peer, msg, originalKey) => {
            const nextPeer = String(peer || '').trim();
            if (!nextPeer) return;
            if (!normalized[nextPeer]) normalized[nextPeer] = [];
            normalized[nextPeer].push(msg);
            if (String(originalKey || '').trim() !== nextPeer) {
                changed = true;
            }
        };

        Object.entries(this.S.chats || {}).forEach(([key, msgs]) => {
            if (!Array.isArray(msgs)) return;
            msgs.forEach(msg => {
                if (!msg || typeof msg !== 'object') return;
                const sender = String(msg.sender || '').trim();
                const receiver = String(msg.receiver || '').trim();
                const canonicalPeer = sender === me
                    ? receiver
                    : (receiver === me ? sender : '');

                if (canonicalPeer) {
                    pushMessage(canonicalPeer, msg, key);
                } else {
                    pushMessage(String(key || '').trim(), msg, key);
                }
            });
        });

        Object.keys(normalized).forEach(peer => {
            normalized[peer].sort((a, b) => new Date(a.timestamp || 0) - new Date(b.timestamp || 0));
        });

        const before = JSON.stringify(this.S.chats || {});
        const after = JSON.stringify(normalized);
        if (before !== after) {
            this.S.chats = normalized;
            this.saveStoredMessageCache();
            this.trace(`normalizeDmChatStore changed peers=${Object.keys(normalized).length}`);
            return true;
        }

        this.S.chats = normalized;
        return changed;
    }

    loadStoredCurrentContact() {
        try {
            const raw = localStorage.getItem(this.currentContactStorageKey());
            const value = String(raw || '').trim();
            return value || null;
        } catch (e) {
            return null;
        }
    }

    saveStoredCurrentContact(name) {
        try {
            const value = String(name || '').trim();
            if (value) {
                localStorage.setItem(this.currentContactStorageKey(), value);
            } else {
                localStorage.removeItem(this.currentContactStorageKey());
            }
        } catch (e) {}
    }

    loadStoredCryptoKey() {
        try {
            const stored = (localStorage.getItem(this.cryptoKeyStorageKey()) || '').trim();
            const injected = (window.__ZALI_SAVED_KEY || '').trim();
            const fallback = 'ZALI_SECRET_E2E_KEY_2026';
            const key = stored || injected || fallback;
            this.trace(`loadStoredCryptoKey stored=${!!stored} injected=${!!injected} keySet=${!!key}`);
            if (stored) return stored;
            if (injected) return injected;
            return fallback;
        } catch (e) {
            this.trace('loadStoredCryptoKey error fallback injected');
            return (window.__ZALI_SAVED_KEY || '').trim() || 'ZALI_SECRET_E2E_KEY_2026';
        }
    }

    sharedCryptoKey() {
        return 'ZALI_SECRET_E2E_KEY_2026';
    }

    _sanitizeKeyPart(value) {
        return String(value || '').trim().replace(/\s+/g, '_');
    }

    conversationCryptoKey(peer = null, serverId = null, channelId = null) {
        const pepper = this.sharedCryptoKey();
        const isServers = !!(serverId && channelId);
        if (isServers) {
            return `zali-e2e:v1:server:${this._sanitizeKeyPart(serverId)}:${this._sanitizeKeyPart(channelId)}:${pepper}`;
        }
        const me = this._sanitizeKeyPart(this.myName());
        const other = this._sanitizeKeyPart(peer || this.S.current || '');
        const pair = [me, other].filter(Boolean).sort().join(':');
        return `zali-e2e:v1:dm:${pair}:${pepper}`;
    }

    ensureConversationCryptoKey({ peer = null, serverId = null, channelId = null, reason = 'auto' } = {}) {
        const derived = this.conversationCryptoKey(peer, serverId, channelId);
        const current = (this.loadStoredCryptoKey() || '').trim();
        if (!derived) return '';

        const currentInput = document.getElementById('inputCryptoKey');
        const mismatch = current !== derived;
        if (mismatch) {
            this.trace(`ensureConversationCryptoKey reason=${reason} mismatch=${current ? 'yes' : 'empty'} peer=${String(peer || '').trim()} server=${String(serverId || '').trim()} channel=${String(channelId || '').trim()} length=${derived.length}`);
            if (this.bus) {
                this.bus.send('zali_styler:set_key', derived);
            } else {
                try {
                    window.__ZALI_SAVED_KEY = derived;
                } catch (e) {}
                if (currentInput) currentInput.value = derived;
                if (this.nativeSupports('setKey')) {
                    this.postNativeMessage({ type: 'SET_KEY', key: derived });
                }
                try {
                    localStorage.setItem(this.cryptoKeyStorageKey(), derived);
                } catch (e) {}
            }
        }
        this.updateCryptoKeyDisplay({
            key: derived,
            peer,
            serverId,
            channelId,
        });
        return derived;
    }

    updateCryptoKeyDisplay({ key = null, peer = null, serverId = null, channelId = null } = {}) {
        const valueEl = document.getElementById('currentCryptoKeyValue');
        const metaEl = document.getElementById('currentCryptoKeyMeta');
        const currentKey = String(key || this.loadStoredCryptoKey() || '').trim() || 'не задан';
        if (valueEl) valueEl.textContent = currentKey;
        if (metaEl) {
            if (serverId && channelId) {
                metaEl.textContent = `Контекст: сервер ${serverId} / канал ${channelId}`;
            } else if (peer) {
                metaEl.textContent = `Контекст: диалог с ${peer}`;
            } else {
                metaEl.textContent = 'Контекст: общий ключ';
            }
        }
    }

    updateChatHeaderCryptoKey({ peer = null, serverId = null, channelId = null } = {}) {
        const chatHdrSub = document.getElementById('chatHdrSub');
        if (!chatHdrSub) return;
        const key = this.conversationCryptoKey(peer, serverId, channelId);
        const desc = serverId && channelId
            ? `${String(serverId).trim()} / ${String(channelId).trim()}`
            : peer
                ? `Диалог с ${String(peer).trim()}`
                : 'Личное сообщение';
        chatHdrSub.innerHTML = `
            <span class="chat-hdr-desc">${this.esc(desc)}</span>
            <span class="chat-hdr-key">${this.esc(`Ключ: ${key}`)}</span>
        `;
    }

    saveStoredCryptoKey(key) {
        try {
            const value = (key || '').trim();
            this.trace(`saveStoredCryptoKey keySet=${!!value} length=${value.length}`);
            if (value) {
                localStorage.setItem(this.cryptoKeyStorageKey(), value);
            } else {
                localStorage.removeItem(this.cryptoKeyStorageKey());
            }
            try {
                window.__ZALI_SAVED_KEY = value;
            } catch (e) {}
            if (this.nativeSupports('setKey')) {
                this.trace(`saveStoredCryptoKey native setKey keySet=${!!value}`);
                this.postNativeMessage({
                    type: 'SET_KEY',
                    key: value,
                });
            }
        } catch (e) {}
    }

    loadStoredSession(key = null) {
        try {
            const raw = localStorage.getItem(key || this.authStorageKey());
            if (!raw) {
                const injected = key ? null : this.loadInjectedSession();
                this.trace(`loadStoredSession key=${key || 'auth'} local=no injected=${!!injected}`);
                return injected;
            }
            const parsed = JSON.parse(raw);
            if (!parsed || typeof parsed !== 'object') return null;
            this.trace(`loadStoredSession key=${key || 'auth'} local=yes`);
            return parsed;
        } catch (e) {
            this.trace(`loadStoredSession key=${key || 'auth'} error`);
            if (!key) {
                return this.loadInjectedSession();
            }
            return null;
        }
    }

    loadInjectedSession() {
        try {
            const raw = window.__ZALI_SAVED_SESSION;
            if (!raw || typeof raw !== 'object') return null;
            return raw;
        } catch (e) {
            return null;
        }
    }

    formatDuration(ms) {
        const total = Math.max(0, Math.floor(Number(ms || 0) / 1000));
        const hours = Math.floor(total / 3600);
        const minutes = Math.floor((total % 3600) / 60);
        const seconds = total % 60;
        const pad = (v) => String(v).padStart(2, '0');
        return hours > 0 ? `${hours}:${pad(minutes)}:${pad(seconds)}` : `${pad(minutes)}:${pad(seconds)}`;
    }

    formatBytes(bytes) {
        const value = Math.max(0, Number(bytes || 0));
        if (!value) return '0 B';
        const units = ['B', 'KB', 'MB', 'GB'];
        let idx = 0;
        let current = value;
        while (current >= 1024 && idx < units.length - 1) {
            current /= 1024;
            idx += 1;
        }
        const digits = current >= 100 || idx === 0 ? 0 : current >= 10 ? 1 : 2;
        return `${current.toFixed(digits)} ${units[idx]}`;
    }

    describeIceCandidate(candidateLine) {
        const parts = String(candidateLine || '').trim().split(/\s+/);
        const typIndex = parts.indexOf('typ');
        return {
            protocol: String(parts[2] || '').toLowerCase(),
            address: parts[4] && parts[5] ? `${parts[4]}:${parts[5]}` : '',
            type: typIndex >= 0 ? String(parts[typIndex + 1] || '') : '',
        };
    }

    getVoicePrimaryPeerName() {
        const peers = Array.from(this.voice.peerConnections.keys()).map(name => String(name || '').trim()).filter(Boolean);
        const me = String(this.myName() || '').trim();
        const preferred = String(this.voice.targetUser || this.voice.inviter || '').trim();
        if (preferred && peers.includes(preferred)) return preferred;
        if (this.voice.roomType === 'dm') {
            const nonMe = peers.find(name => name !== me);
            if (nonMe) return nonMe;
        }
        return peers[0] || preferred || '';
    }

    getVoiceHealthSnapshot() {
        const peer = this.getVoicePrimaryPeerName();
        const entry = peer ? this.voice.peerConnections.get(peer) : null;
        const stats = entry?.lastStats || {};
        const audio = peer ? this.voice.remoteAudios.get(peer) : null;
        const playbackNode = peer ? this.voice.remotePlaybackNodes?.get(peer) : null;
        const remoteStream = audio?.srcObject instanceof MediaStream ? audio.srcObject : null;
        const localStream = this.voice.localStream;
        const connectionState = String(entry?.pc?.connectionState || 'idle').trim() || 'idle';
        const iceState = String(entry?.pc?.iceConnectionState || 'idle').trim() || 'idle';
        const signalingState = String(entry?.pc?.signalingState || 'idle').trim() || 'idle';
        const hasOut = Number(stats.outBytes || 0) > 0 || Number(stats.outPackets || 0) > 0;
        const hasIn = Number(stats.inBytes || 0) > 0 || Number(stats.inPackets || 0) > 0;
        const candidatePair = stats.candidatePair || null;
        const localCandidates = Number(stats.localCandidateCount || entry?.generatedIceCandidates || 0);
        const remoteCandidates = Number(stats.remoteCandidateCount || entry?.receivedIceCandidates || 0);
        const remoteTrackCount = remoteStream ? remoteStream.getAudioTracks().length : 0;
        const routeValue = playbackNode
            ? 'WebAudio'
            : audio
                ? (audio.paused ? 'audio paused' : 'audio ready')
                : remoteTrackCount
                    ? 'stream only'
                    : 'нет трека';
        const playbackValue = audio
            ? (audio.paused ? 'paused' : audio.readyState >= 2 ? 'playing' : 'waiting')
            : 'none';
        const micValue = localStream
            ? `${localStream.getAudioTracks().length} track${localStream.getAudioTracks().length === 1 ? '' : 's'}`
            : 'нет микрофона';

        const toneByState = (state, activeTone = 'good') => {
            const s = String(state || '').toLowerCase();
            if (['connected', 'completed', 'playing', 'ready', 'live'].includes(s)) return 'good';
            if (['connecting', 'checking', 'new', 'waiting', 'idle'].includes(s)) return 'warn';
            if (['disconnected', 'failed', 'closed', 'paused'].includes(s)) return 'bad';
            return activeTone;
        };

        return [
            {
                label: 'ICE',
                value: iceState,
                sub: connectionState === 'connected' ? 'канал поднят' : 'ожидаем согласование',
                tone: toneByState(iceState),
            },
            {
                label: 'RTP out',
                value: hasOut ? `${this.formatBytes(stats.outBytes || 0)} · ${stats.outPackets || 0} pkts` : '0 B',
                sub: hasOut ? 'уходит в сеть' : 'пока тишина',
                tone: hasOut ? 'good' : toneByState(connectionState, 'warn'),
            },
            {
                label: 'RTP in',
                value: hasIn ? `${this.formatBytes(stats.inBytes || 0)} · ${stats.inPackets || 0} pkts` : '0 B',
                sub: hasIn ? 'приходит с удалённой стороны' : 'не получаем RTP',
                tone: hasIn ? 'good' : 'bad',
            },
            {
                label: 'Candidate pair',
                value: candidatePair ? `${candidatePair.localLabel || candidatePair.local || 'local'} → ${candidatePair.remoteLabel || candidatePair.remote || 'remote'}` : 'не выбран',
                sub: candidatePair ? `rtt ${candidatePair.currentRoundTripTime ?? 'n/a'} · ${this.formatBytes(candidatePair.bytesSent || 0)} / ${this.formatBytes(candidatePair.bytesReceived || 0)}` : `local ${localCandidates} / remote ${remoteCandidates}`,
                tone: candidatePair ? 'good' : 'warn',
            },
            {
                label: 'Audio route',
                value: routeValue,
                sub: remoteTrackCount ? `tracks: ${remoteTrackCount}` : 'ждём remote-track',
                tone: remoteTrackCount ? 'good' : 'warn',
            },
            {
                label: 'Playback',
                value: playbackValue,
                sub: micValue,
                tone: audio ? (audio.paused ? 'warn' : 'good') : 'idle',
            },
        ];
    }

    saveStoredSession(session) {
        try {
            localStorage.setItem(this.authStorageKey(), JSON.stringify(session));
            localStorage.setItem(this.lastAuthStorageKey(), JSON.stringify(session));
            this.saveInjectedSession(session);
        } catch (e) {
            // ignore storage failures
        }
    }

    saveInjectedSession(session) {
        try {
            window.__ZALI_SAVED_SESSION = session && typeof session === 'object' ? session : null;
        } catch (e) {}
    }

    clearStoredSession() {
        try {
            localStorage.removeItem(this.authStorageKey());
            this.saveInjectedSession(null);
        } catch (e) {
            // ignore storage failures
        }
    }

    loadPendingOutbox() {
        try {
            const raw = localStorage.getItem(this.pendingOutboxStorageKey());
            if (!raw) {
                const injected = this.loadInjectedPendingOutbox();
                this.trace(`loadPendingOutbox local=no injected=${injected.length}`);
                return injected;
            }
            const parsed = JSON.parse(raw);
            this.trace(`loadPendingOutbox local=yes count=${Array.isArray(parsed) ? parsed.length : 0}`);
            return Array.isArray(parsed) ? parsed.filter(item => item && typeof item === 'object') : this.loadInjectedPendingOutbox();
        } catch (e) {
            this.trace('loadPendingOutbox error fallback injected');
            return this.loadInjectedPendingOutbox();
        }
    }

    savePendingOutbox(items) {
        const next = Array.isArray(items) ? items : [];
        try {
            localStorage.setItem(this.pendingOutboxStorageKey(), JSON.stringify(next));
        } catch (e) {}
        this.trace(`savePendingOutbox count=${next.length}`);
        this.saveInjectedPendingOutbox(next);
        if (this.nativeSupports('sessionSync')) {
            this.trace(`savePendingOutbox native sync count=${next.length}`);
            this.postNativeMessage({
                type: 'SAVE_PENDING_OUTBOX',
                items: next,
            });
        }
    }

    loadInjectedPendingOutbox() {
        try {
            const raw = window.__ZALI_PENDING_OUTBOX;
            if (!Array.isArray(raw)) return [];
            return raw.filter(item => item && typeof item === 'object');
        } catch (e) {
            return [];
        }
    }

    saveInjectedPendingOutbox(items) {
        try {
            window.__ZALI_PENDING_OUTBOX = Array.isArray(items) ? items : [];
        } catch (e) {}
    }

    pendingOutboxConversationKey(item) {
        const serverId = String(item?.serverId || '').trim();
        const channelId = String(item?.channelId || '').trim();
        const sender = String(item?.sender || '').trim();
        const receiver = String(item?.receiver || '').trim();
        return serverId && channelId
            ? `server:${serverId}:${channelId}:${sender}:${receiver}`
            : `dm:${sender}:${receiver}`;
    }

    messageConversationKey(msg) {
        const serverId = String(msg?.serverId || msg?.server_id || '').trim();
        const channelId = String(msg?.channelId || msg?.channel_id || '').trim();
        const sender = String(msg?.sender || '').trim();
        const receiver = String(msg?.receiver || '').trim();
        return serverId && channelId
            ? `server:${serverId}:${channelId}:${sender}:${receiver}`
            : `dm:${sender}:${receiver}`;
    }

    pendingOutboxContentKey(item) {
        const attachmentsKey = this.normalizeAttachments(item?.attachments).map(att => `${att.name}:${att.kind}:${att.size}:${att.mimeType}`).join('|');
        return [
            String(item?.text || ''),
            attachmentsKey,
        ].join('::');
    }

    messageContentKey(msg) {
        const attachmentsKey = this.normalizeAttachments(msg?.attachments).map(att => `${att.name}:${att.kind}:${att.size}:${att.mimeType}`).join('|');
        const call = msg?.kind === 'call' ? msg.call || {} : {};
        return [
            String(msg?.kind || ''),
            String(msg?.text || ''),
            String(call.roomId || ''),
            String(call.direction || ''),
            String(call.outcome || ''),
            String(call.peer || ''),
            String(call.durationMs || ''),
            attachmentsKey,
        ].join('::');
    }

    matchPendingOutboxItem(msg) {
        const contentKey = this.messageContentKey(msg);
        const conversationKey = this.messageConversationKey(msg);
        const sender = String(msg?.sender || '').trim();
        const receiver = String(msg?.receiver || '').trim();
        const serverId = String(msg?.serverId || msg?.server_id || '').trim();
        const channelId = String(msg?.channelId || msg?.channel_id || '').trim();
        const pending = this.loadPendingOutbox();
        return pending.find(item => {
            if (!item || typeof item !== 'object') return false;
            if (this.pendingOutboxConversationKey(item) !== conversationKey) return false;
            if (String(item.sender || '').trim() !== sender) return false;
            if (String(item.receiver || '').trim() !== receiver) return false;
            if (serverId && String(item.serverId || '').trim() !== serverId) return false;
            if (channelId && String(item.channelId || '').trim() !== channelId) return false;
            return this.pendingOutboxContentKey(item) === contentKey;
        }) || null;
    }

    enqueuePendingOutbox(message) {
        if (!message || typeof message !== 'object') return;
        const pending = this.loadPendingOutbox();
        const key = String(message.clientId || '').trim();
        if (!key) return;
        if (pending.some(item => String(item.clientId || '').trim() === key)) return;
        this.trace(`enqueuePendingOutbox clientId=${key} sender=${String(message.sender || '').trim()} receiver=${String(message.receiver || '').trim()} server=${String(message.serverId || '').trim()} channel=${String(message.channelId || '').trim()} textBytes=${String(message.text || '').length} attachments=${this.normalizeAttachments(message.attachments).length}`);
        pending.push({
            clientId: key,
            sender: String(message.sender || '').trim(),
            receiver: String(message.receiver || '').trim(),
            serverId: message.serverId ? String(message.serverId).trim() : '',
            channelId: message.channelId ? String(message.channelId).trim() : '',
            text: String(message.text || ''),
            key: String(message.key || ''),
            attachments: this.normalizeAttachments(message.attachments),
            timestamp: String(message.timestamp || new Date().toISOString()),
            attemptCount: 0,
            lastAttemptAt: 0,
            nextRetryAt: 0,
        });
        this.savePendingOutbox(pending);
    }

    dropPendingOutbox(clientId) {
        const pendingId = String(clientId || '').trim();
        if (!pendingId) return;
        this.trace(`dropPendingOutbox clientId=${pendingId}`);
        const pending = this.loadPendingOutbox().filter(item => String(item.clientId || '').trim() !== pendingId);
        this.savePendingOutbox(pending);
    }

    scheduleFlushPendingOutbox(delayMs = 150) {
        if (this.pendingOutboxFlushTimer) {
            clearTimeout(this.pendingOutboxFlushTimer);
        }
        this.pendingOutboxFlushTimer = setTimeout(() => {
            this.pendingOutboxFlushTimer = null;
            this.flushPendingOutbox();
        }, Math.max(0, Number(delayMs || 0)));
    }

    rehydratePendingOutbox() {
        const currentUser = String(this.myName() || '').trim();
        if (!currentUser) return;
        const pending = this.loadPendingOutbox().filter(item => String(item?.sender || '').trim() === currentUser);
        this.trace(`rehydratePendingOutbox currentUser=${currentUser} count=${pending.length} tokenSet=${!!this.S.session?.token} navMode=${this.S.navMode}`);
        let changed = false;

        for (const item of pending) {
            if (!item || typeof item !== 'object') continue;
            const clientId = String(item.clientId || '').trim();
            if (!clientId) continue;
            if (this.findMessageById(clientId)) continue;

            const serverId = String(item.serverId || '').trim();
            const channelId = String(item.channelId || '').trim();
            const isServers = !!(serverId && channelId);
            const conversationKey = isServers ? `${serverId}:${channelId}` : String(item.receiver || '').trim();
            const message = {
                id: clientId,
                sender: String(item.sender || currentUser).trim() || currentUser,
                receiver: String(item.receiver || '').trim(),
                text: String(item.text || ''),
                attachments: this.normalizeAttachments(item.attachments),
                timestamp: String(item.timestamp || new Date().toISOString()),
                status: 'sending',
                clientId,
                serverId: isServers ? serverId : null,
                channelId: isServers ? channelId : null,
            };

            if (isServers) {
                if (!this.S.serverChats[conversationKey]) this.S.serverChats[conversationKey] = [];
                this.S.serverChats[conversationKey].push(message);
            } else {
                this.ensureContact(message.receiver);
                this.initChat(message.receiver);
                this.S.chats[message.receiver].push(message);
            }
            changed = true;
        }

        if (changed) {
            if (this.S.navMode !== 'servers') {
                const currentKey = String(this.S.current || '').trim();
                const currentMsgs = currentKey ? (this.S.chats[currentKey] || []) : [];
                if (!currentKey || !currentMsgs.length) {
                    const preferredPeer = pending
                        .map(item => String(item?.receiver || '').trim())
                        .find(peer => peer && (this.S.chats[peer] || []).length > 0);
                    if (preferredPeer && preferredPeer !== this.S.current) {
                        this.switchChat(preferredPeer);
                    }
                }
            }
            this.renderMessages();
            this.renderContacts();
            this.renderServerInterface();
        }
    }

    isPendingMessageAlreadyLoaded(item) {
        const attachmentsKey = this.normalizeAttachments(item.attachments).map(att => `${att.name}:${att.kind}:${att.size}`).join('|');
        const text = String(item.text || '');
        const sender = String(item.sender || '');
        const receiver = String(item.receiver || '');
        const serverId = String(item.serverId || '').trim();
        const channelId = String(item.channelId || '').trim();

        if (serverId && channelId) {
            const key = `${serverId}:${channelId}`;
            const msgs = this.S.serverChats[key] || [];
            return msgs.some(msg => {
                const msgAttachments = this.normalizeAttachments(msg.attachments).map(att => `${att.name}:${att.kind}:${att.size}`).join('|');
                return String(msg.sender || '') === sender &&
                    String(msg.receiver || '') === receiver &&
                    String(msg.text || '') === text &&
                    msgAttachments === attachmentsKey;
            });
        }

        const peer = sender === this.myName() ? receiver : sender;
        const msgs = this.S.chats[peer] || [];
        return msgs.some(msg => {
            const msgAttachments = this.normalizeAttachments(msg.attachments).map(att => `${att.name}:${att.kind}:${att.size}`).join('|');
            return String(msg.sender || '') === sender &&
                String(msg.receiver || '') === receiver &&
                String(msg.text || '') === text &&
                msgAttachments === attachmentsKey;
        });
    }

    flushPendingOutbox() {
        if (!this.nativeSupports('sendMessage')) return;
        const key = this._getKey();
        if (!key) return;
        if (!this.S.session?.token) return;
        const currentUser = String(this.myName() || '').trim();
        const now = Date.now();
        const pending = this.loadPendingOutbox();
        if (!pending.length) return;
        this.trace(`flushPendingOutbox currentUser=${currentUser} count=${pending.length} tokenSet=${!!this.S.session?.token} keySet=${!!key}`);

        for (const item of pending) {
            if (!item || typeof item !== 'object') continue;
            if (currentUser && String(item.sender || '').trim() !== currentUser) continue;
            if (Number(item.nextRetryAt || 0) > now) continue;

            if (this.isPendingMessageAlreadyLoaded(item)) {
                this.dropPendingOutbox(item.clientId);
                continue;
            }

            item.attemptCount = Number(item.attemptCount || 0) + 1;
            item.lastAttemptAt = now;
            item.nextRetryAt = now + Math.min(30000, Math.max(1500, 1000 * Math.min(item.attemptCount, 6)));
            this.savePendingOutbox(pending);

            this.postNativeMessage({
                type: 'SEND_MESSAGE',
                text: item.text,
                recipient: item.serverId && item.channelId ? item.channelId : item.receiver,
                serverId: item.serverId || '',
                channelId: item.channelId || '',
                sender: item.sender || this.myName(),
                key,
                clientId: item.clientId,
                attachments: this.normalizeAttachments(item.attachments).map(att => ({
                    name: att.name,
                    mimeType: att.mimeType,
                    kind: att.kind,
                    size: att.size,
                    dataUrl: att.dataUrl,
                })),
            });
            this.trace(`flushPendingOutbox send clientId=${String(item.clientId || '').trim()} receiver=${String(item.receiver || '').trim()} server=${String(item.serverId || '').trim()} channel=${String(item.channelId || '').trim()} attempt=${item.attemptCount}`);
        }
    }

    clearLastStoredSession() {
        try {
            localStorage.removeItem(this.lastAuthStorageKey());
        } catch (e) {
            // ignore storage failures
        }
    }

    loadStoredNavMode() {
        try {
            const raw = localStorage.getItem(this.navModeStorageKey());
            return raw === 'servers' ? 'servers' : 'dm';
        } catch (e) {
            return 'dm';
        }
    }

    saveStoredNavMode(mode) {
        try {
            localStorage.setItem(this.navModeStorageKey(), mode);
        } catch (e) {
            // ignore storage failures
        }
    }

    loadStoredActiveServer() {
        try {
            const raw = localStorage.getItem(this.activeServerStorageKey());
            return raw ? String(raw) : null;
        } catch (e) {
            return null;
        }
    }

    saveStoredActiveServer(serverId) {
        try {
            if (serverId) {
                localStorage.setItem(this.activeServerStorageKey(), serverId);
            } else {
                localStorage.removeItem(this.activeServerStorageKey());
            }
        } catch (e) {
            // ignore storage failures
        }
    }

    loadStoredActiveChannel() {
        try {
            const raw = localStorage.getItem(this.activeChannelStorageKey());
            return raw ? String(raw) : null;
        } catch (e) {
            return null;
        }
    }

    saveStoredActiveChannel(channelId) {
        try {
            if (channelId) {
                localStorage.setItem(this.activeChannelStorageKey(), channelId);
            } else {
                localStorage.removeItem(this.activeChannelStorageKey());
            }
        } catch (e) {
            // ignore storage failures
        }
    }

    loadStoredServerChats() {
        return {};
    }

    saveStoredServerChats() {
        // Server history now comes from the backend; keep this as a no-op
        // so local optimistic state doesn't get duplicated after restart.
    }

    loadStoredNetworkConfig() {
        try {
            const raw = localStorage.getItem(this.networkConfigStorageKey());
            if (!raw) return {};
            const parsed = JSON.parse(raw);
            return parsed && typeof parsed === 'object' ? parsed : {};
        } catch (e) {
            return {};
        }
    }

    trimTrailingSlash(value) {
        return String(value || '').trim().replace(/\/+$/, '');
    }

    isPlaceholderNetworkUrl(value) {
        const raw = String(value || '').trim().toLowerCase();
        if (!raw) return false;
        return (
            raw.includes('chat.example.com') ||
            raw.includes('turn.example.com') ||
            raw.includes('example.com')
        );
    }

    normalizeLocalApiAddress(value) {
        const raw = this.trimTrailingSlash(value);
        if (!raw) return '';
        try {
            const parsed = new URL(raw);
            const host = parsed.hostname.toLowerCase();
            const isLocalHost = ['localhost', '127.0.0.1', '::1'].includes(host);
            if (isLocalHost && !parsed.port) {
                parsed.port = '3000';
            }
            if (host === 'localhost' || host === '::1') {
                parsed.hostname = '127.0.0.1';
            }
            return parsed.toString().replace(/\/$/, '');
        } catch (e) {
            if (/^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(?:[\/?#]|$)/i.test(raw) && !/:\d+(?:[\/?#]|$)/.test(raw)) {
                return raw
                    .replace(/^(https?:\/\/(?:localhost|127\.0\.0\.1|\[::1\]))(?=[:\/?#]|$)/i, '$1:3000')
                    .replace(/^https?:\/\/(?:localhost|\[::1\])(?=:3000(?:[\/?#]|$))/i, 'http://127.0.0.1');
            }
            if (/^https?:\/\/(?:localhost|\[::1\])(?=[:\/?#]|$)/i.test(raw)) {
                return raw.replace(
                    /^(https?:\/\/)(?:localhost|\[::1\])(?=[:\/?#]|$)/i,
                    '$1127.0.0.1'
                );
            }
            return raw;
        }
    }

    normalizeApiBaseUrl(value) {
        const normalized = this.normalizeLocalApiAddress(value);
        if (!normalized) return '';
        if (this.isPlaceholderNetworkUrl(normalized)) return '';
        return normalized;
    }

    normalizeWsBaseUrl(value) {
        const normalized = this.trimTrailingSlash(value);
        if (!normalized) return '';
        if (this.isPlaceholderNetworkUrl(normalized)) return '';
        return normalized;
    }

    saveStoredNetworkConfig(config) {
        try {
            localStorage.setItem(this.networkConfigStorageKey(), JSON.stringify(config || {}));
        } catch (e) {
            // ignore storage failures
        }
    }

    hasStoredNetworkConfig() {
        try {
            return !!localStorage.getItem(this.networkConfigStorageKey());
        } catch (e) {
            return false;
        }
    }

    defaultApiBaseUrl() {
        if (window.__ZALI_CONFIG?.apiBaseUrl) {
            return this.normalizeApiBaseUrl(window.__ZALI_CONFIG.apiBaseUrl);
        }
        return 'http://127.0.0.1:3000';
    }

    defaultWsBaseUrl() {
        if (window.__ZALI_CONFIG?.wsBaseUrl) {
            return this.normalizeWsBaseUrl(window.__ZALI_CONFIG.wsBaseUrl);
        }
        const api = this.defaultApiBaseUrl();
        if (api.startsWith('https://')) return api.replace(/^https:\/\//, 'wss://') + '/ws';
        if (api.startsWith('http://')) return api.replace(/^http:\/\//, 'ws://') + '/ws';
        return 'ws://127.0.0.1:3000/ws';
    }

    deriveWsBaseUrl(apiBaseUrl) {
        const api = this.normalizeApiBaseUrl(apiBaseUrl || '');
        if (api.startsWith('https://')) return api.replace(/^https:\/\//, 'wss://') + '/ws';
        if (api.startsWith('http://')) return api.replace(/^http:\/\//, 'ws://') + '/ws';
        return this.defaultWsBaseUrl();
    }

    defaultTurnUrls() {
        const fromConfig = window.__ZALI_CONFIG?.turn?.url;
        if (fromConfig) {
            const urls = Array.isArray(fromConfig) ? fromConfig : [fromConfig];
            return urls.map(item => String(item || '').trim()).filter(Boolean);
        }

        const stored = this.loadStoredNetworkConfig();
        const apiBase = this.normalizeApiBaseUrl(stored.apiBaseUrl || '') || this.defaultApiBaseUrl();
        let host = '127.0.0.1';
        try {
            host = new URL(apiBase).hostname || host;
        } catch (e) {}

        if (host === 'localhost' || host === '127.0.0.1' || host === '::1') {
            return [
                'turn:127.0.0.1:3478?transport=udp',
                'turn:127.0.0.1:3478?transport=tcp',
                'turn:localhost:3478?transport=udp',
                'turn:localhost:3478?transport=tcp',
            ];
        }

        const safeHost = host.includes(':') && !host.startsWith('[') ? `[${host}]` : host;
        return [
            `turn:${safeHost}:3478?transport=udp`,
            `turn:${safeHost}:3478?transport=tcp`,
        ];
    }

    defaultIceServers() {
        const injected = window.__ZALI_CONFIG?.iceServers;
        if (Array.isArray(injected) && injected.length) {
            return injected;
        }
        const turnConfig = window.__ZALI_CONFIG?.turn;
        if (turnConfig && turnConfig.url) {
            const urls = Array.isArray(turnConfig.url) ? turnConfig.url : [turnConfig.url];
            const turnServer = {
                urls: urls.map(item => String(item || '').trim()).filter(Boolean),
            };
            if (turnServer.urls.length) {
                if (turnConfig.username) turnServer.username = String(turnConfig.username).trim();
                if (turnConfig.credential) turnServer.credential = String(turnConfig.credential).trim();
                if (turnConfig.relayOnly !== undefined) turnServer.relayOnly = !!turnConfig.relayOnly;
                const servers = [turnServer];
                if (!turnServer.relayOnly) {
                    servers.push(
                        { urls: 'stun:stun.l.google.com:19302' },
                        { urls: 'stun:stun1.l.google.com:19302' },
                    );
                }
                return servers;
            }
        }
        return [
            {
                urls: this.defaultTurnUrls(),
                username: 'zali',
                credential: 'turnpass',
            },
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' },
        ];
    }

    defaultTurnPreset() {
        const turn = window.__ZALI_CONFIG?.turn || {};
        const defaultUrls = this.defaultTurnUrls().join(', ');
        return {
            url: String(turn.url || defaultUrls).trim(),
            username: String(turn.username || 'zali').trim(),
            credential: String(turn.credential || 'turnpass').trim(),
            relayOnly: turn.relayOnly !== undefined ? !!turn.relayOnly : false,
        };
    }

    normalizeIceServers(value) {
        const list = Array.isArray(value) ? value : [];
        return list.map(item => {
            if (typeof item === 'string') {
                return { urls: item.trim() };
            }
            if (item && typeof item === 'object') {
                const urls = Array.isArray(item.urls) ? item.urls : item.urls ? [item.urls] : [];
                const next = { ...item, urls: urls.map(url => String(url || '').trim()).filter(Boolean) };
                return next.urls.length ? next : null;
            }
            return null;
        }).filter(Boolean);
    }

    parseIceServersText(raw) {
        const text = String(raw || '').trim();
        if (!text) return [];
        const parsed = JSON.parse(text);
        if (!Array.isArray(parsed)) {
            throw new Error('ICE servers должен быть JSON-массивом');
        }
        return this.normalizeIceServers(parsed);
    }

    loadNetworkConfig() {
        const stored = this.loadStoredNetworkConfig();
        const apiBaseUrl = this.normalizeApiBaseUrl(stored.apiBaseUrl || '') || this.defaultApiBaseUrl();
        const wsBaseUrl = this.normalizeWsBaseUrl(stored.wsBaseUrl || '') || this.defaultWsBaseUrl();
        let iceServers = this.normalizeIceServers(stored.iceServers);
        if (!iceServers.length) {
            iceServers = this.normalizeIceServers(this.defaultIceServers());
        }
        return { apiBaseUrl, wsBaseUrl, iceServers };
    }

    getApiBaseUrl() {
        return this.loadNetworkConfig().apiBaseUrl;
    }

    getWsBaseUrl() {
        return this.loadNetworkConfig().wsBaseUrl;
    }

    getIceServers() {
        return this.loadNetworkConfig().iceServers;
    }

    getVoiceRtcConfig() {
        const config = this.loadNetworkConfig();
        const defaultTurn = {
            urls: this.defaultTurnUrls(),
            username: 'zali',
            credential: 'turnpass',
        };
        const iceServers = this.normalizeIceServers([defaultTurn, ...config.iceServers]);
        const seenUrls = new Set();
        const uniqueServers = iceServers.map(server => {
            const urls = Array.isArray(server?.urls) ? server.urls : [server?.urls];
            const nextUrls = urls
                .map(url => String(url || '').trim())
                .filter(Boolean)
                .filter(url => {
                    const key = url.toLowerCase();
                    if (seenUrls.has(key)) return false;
                    seenUrls.add(key);
                    return true;
                });
            return nextUrls.length ? { ...server, urls: nextUrls } : null;
        }).filter(Boolean);
        return {
            iceServers: uniqueServers.map(server => {
                const { relayOnly, ...iceServer } = server || {};
                return iceServer;
            }),
            iceCandidatePoolSize: 4,
            iceTransportPolicy: 'all',
        };
    }

    setNetworkConfig(config = {}) {
        const next = {
            apiBaseUrl: this.normalizeApiBaseUrl(config.apiBaseUrl || ''),
            wsBaseUrl: this.normalizeWsBaseUrl(config.wsBaseUrl || ''),
            iceServers: this.normalizeIceServers(config.iceServers),
        };
        this.saveStoredNetworkConfig(next);
        this.applyNetworkConfigToInputs();
        this.syncNativeNetworkConfig({ force: true });
        this.connectBrowserVoiceSocket();
        this.addLogEntry({ type: 'SUCCESS', msg: 'Network configuration updated', ts: new Date().toLocaleTimeString() });
    }

    resetNetworkConfig() {
        try {
            localStorage.removeItem(this.networkConfigStorageKey());
        } catch (e) {}
        this.applyNetworkConfigToInputs();
        this.syncNativeNetworkConfig({ force: true });
        this.connectBrowserVoiceSocket();
        this.addLogEntry({ type: 'WARN', msg: 'Network configuration reset to defaults', ts: new Date().toLocaleTimeString() });
    }

    applyNetworkConfigToInputs() {
        const config = this.loadNetworkConfig();
        const apiInput = document.getElementById('inputApiBaseUrl');
        const wsInput = document.getElementById('inputWsBaseUrl');
        const iceInput = document.getElementById('inputIceServers');
        const turnUrlInput = document.getElementById('inputTurnUrl');
        const turnUsernameInput = document.getElementById('inputTurnUsername');
        const turnCredentialInput = document.getElementById('inputTurnCredential');
        const turnRelayOnlyInput = document.getElementById('inputTurnRelayOnly');
        if (apiInput) apiInput.value = config.apiBaseUrl;
        if (wsInput) wsInput.value = config.wsBaseUrl;
        if (iceInput) iceInput.value = JSON.stringify(config.iceServers, null, 2);
        const turn = this.defaultTurnPreset();
        if (turnUrlInput) turnUrlInput.value = turn.url;
        if (turnUsernameInput) turnUsernameInput.value = turn.username;
        if (turnCredentialInput) turnCredentialInput.value = turn.credential;
        if (turnRelayOnlyInput) turnRelayOnlyInput.checked = turn.relayOnly;
        const authApiInput = document.getElementById('authApiBaseUrl');
        const authNote = document.getElementById('authNetworkNote');
        if (authApiInput && document.activeElement !== authApiInput && authApiInput.dataset.dirty !== '1') {
            authApiInput.value = config.apiBaseUrl;
        }
        if (authNote) {
            authNote.textContent = `Текущий API: ${config.apiBaseUrl || 'не задан'}`;
        }
    }

    syncAuthNetworkInput({ force = false } = {}) {
        const authApiInput = document.getElementById('authApiBaseUrl');
        const authNote = document.getElementById('authNetworkNote');
        if (!authApiInput) return;
        const config = this.loadNetworkConfig();
        const isTyping = document.activeElement === authApiInput;
        const isDirty = authApiInput.dataset.dirty === '1';
        if (force || (!isTyping && !isDirty)) {
            authApiInput.value = config.apiBaseUrl;
        }
        if (authNote) {
            authNote.textContent = `Текущий API: ${config.apiBaseUrl || 'не задан'}`;
        }
    }

    buildTurnIceServerFromInputs() {
        const turnUrlInput = document.getElementById('inputTurnUrl');
        const turnUsernameInput = document.getElementById('inputTurnUsername');
        const turnCredentialInput = document.getElementById('inputTurnCredential');
        const turnRelayOnlyInput = document.getElementById('inputTurnRelayOnly');
        const urls = String(turnUrlInput?.value || '').trim();
        if (!urls) {
            throw new Error('Укажите TURN URL');
        }
        const urlList = urls.split(',').map(item => item.trim()).filter(Boolean);
        if (!urlList.length) {
            throw new Error('TURN URL не должен быть пустым');
        }
        const entry = {
            urls: urlList.length === 1 ? urlList[0] : urlList,
        };
        const username = String(turnUsernameInput?.value || '').trim();
        const credential = String(turnCredentialInput?.value || '').trim();
        if (username) entry.username = username;
        if (credential) entry.credential = credential;
        if (turnRelayOnlyInput) entry.relayOnly = !!turnRelayOnlyInput.checked;
        return entry;
    }

    appendTurnPresetToIceServers(baseIceServers = null) {
        const iceInput = document.getElementById('inputIceServers');
        const current = Array.isArray(baseIceServers)
            ? this.normalizeIceServers(baseIceServers)
            : this.normalizeIceServers(this.loadNetworkConfig().iceServers);
        const turnEntry = this.buildTurnIceServerFromInputs();
        const next = [...current.filter(server => {
            const urls = Array.isArray(server.urls) ? server.urls : [server.urls];
            const turnUrls = Array.isArray(turnEntry.urls) ? turnEntry.urls : [turnEntry.urls];
            return !urls.some(url => turnUrls.includes(url));
        }), turnEntry];
        if (iceInput) {
            iceInput.value = JSON.stringify(next, null, 2);
        }
        return next;
    }

    syncNativeNetworkConfig({ force = false } = {}) {
        if (!this.nativeSupports('networkConfig')) return;
        const injected = window.__ZALI_CONFIG || {};
        const hasInjectedNetworkConfig = !!(injected.apiBaseUrl || injected.wsBaseUrl || (Array.isArray(injected.iceServers) && injected.iceServers.length));
        if (!force && !this.hasStoredNetworkConfig() && !hasInjectedNetworkConfig) return;
        const config = this.loadNetworkConfig();
        try {
            this.postNativeMessage({
                type: 'NETWORK_CONFIG',
                apiBaseUrl: config.apiBaseUrl,
                wsBaseUrl: config.wsBaseUrl,
                iceServers: config.iceServers,
            });
        } catch (error) {
            this.addLogEntry({
                type: 'WARN',
                msg: `Не удалось синхронизировать сеть с native app: ${error?.message || error}`,
                ts: new Date().toLocaleTimeString(),
            });
        }
    }

    getDefaultServers() {
        return [
            this.ensureServerChannels({ id: 'zali-hub', name: 'Zali Hub', icon: 'Z', color: 'linear-gradient(180deg, #cbff00, #96b800)', unread: 4, hint: 'Общий хаб' }),
            this.ensureServerChannels({ id: 'dev-team', name: 'Dev Team', icon: '⚙', color: 'linear-gradient(180deg, #8c7bff, #5c4de8)', unread: 12, hint: 'Разработка' }),
            this.ensureServerChannels({ id: 'friends', name: 'Friends', icon: '🙂', color: 'linear-gradient(180deg, #ff7a59, #ff4d6d)', unread: 0, hint: 'Круг общения' }),
            this.ensureServerChannels({ id: 'music', name: 'Music', icon: '🎵', color: 'linear-gradient(180deg, #00d2ff, #0077ff)', unread: 2, hint: 'Плейлисты' }),
            this.ensureServerChannels({ id: 'games', name: 'Games', icon: '🎮', color: 'linear-gradient(180deg, #1ee28a, #0a9d5b)', unread: 0, hint: 'Игровой чат' }),
            this.ensureServerChannels({ id: 'study', name: 'Study', icon: '📚', color: 'linear-gradient(180deg, #ffcf5a, #ff8f3a)', unread: 1, hint: 'Учеба' }),
        ];
    }

    defaultServerChannels(serverId) {
        const sid = String(serverId || '').trim();
        return [
            { id: `${sid}-general`, name: 'general', topic: 'Общий чат', kind: 'text', position: 0 },
            { id: `${sid}-voice`, name: 'voice', topic: 'Голосовой канал', kind: 'voice', position: 1 },
        ];
    }

    ensureServerChannels(server = {}) {
        const next = { ...server };
        const channels = Array.isArray(next.channels) ? next.channels.filter(Boolean).map(channel => ({ ...channel })) : [];
        if (!channels.length && next.id) {
            next.channels = this.defaultServerChannels(next.id);
            return next;
        }
        next.channels = channels.map((channel, index) => ({
            ...channel,
            kind: String(channel.kind || 'text').trim().toLowerCase() || 'text',
            position: Number.isFinite(Number(channel.position)) ? Number(channel.position) : index,
        })).sort((a, b) => Number(a.position || 0) - Number(b.position || 0));
        return next;
    }

    ensureServersState() {
        if (!Array.isArray(this.S.servers) || this.S.servers.length === 0) {
            this.S.servers = this.getDefaultServers();
        } else {
            this.S.servers = this.S.servers.map(server => this.ensureServerChannels(server));
        }
        const stored = this.loadStoredActiveServer();
        if (stored && this.S.servers.some(s => s.id === stored)) {
            this.S.activeServer = stored;
        } else if (!this.S.activeServer || !this.S.servers.some(s => s.id === this.S.activeServer)) {
            this.S.activeServer = this.S.servers[0]?.id || null;
        }
    }

    updateSidebarModeLabel() {
        const label = document.querySelector('.nav-label');
        if (label) {
            label.textContent = this.S.navMode === 'servers' ? 'Сервера' : 'Диалоги';
        }
    }

    updateNavModeButtons() {
        const dmBtn = document.getElementById('modeDmBtn');
        const serversBtn = document.getElementById('modeServersBtn');
        const isServers = this.S.navMode === 'servers';
        if (dmBtn) {
            dmBtn.classList.toggle('active', !isServers);
            dmBtn.setAttribute('aria-pressed', String(!isServers));
        }
        if (serversBtn) {
            serversBtn.classList.toggle('active', isServers);
            serversBtn.setAttribute('aria-pressed', String(isServers));
        }
        document.body?.setAttribute('data-nav-mode', this.S.navMode);
        const viewChat = document.getElementById('viewChat');
        if (viewChat) viewChat.classList.toggle('server-mode', isServers);
        this.updateSidebarModeLabel();
    }

    normalizeServers(servers) {
        return Array.isArray(servers) ? servers.map(server => ({
            ...server,
            channels: Array.isArray(server.channels) && server.channels.length ? server.channels.map(channel => ({ ...channel })) : [],
            myRole: server.myRole || server.my_role || null,
            memberCount: Number(server.memberCount || server.member_count || 0) || 0,
            joinLink: server.joinLink || server.join_link || '',
        })).map(server => this.ensureServerChannels(server)).filter(Boolean) : [];
    }

    normalizeMemberRole(role) {
        const value = String(role || '').trim().toLowerCase();
        if (value === 'owner') return 'owner';
        if (value === 'admin') return 'admin';
        return 'member';
    }

    roleLabel(role) {
        switch (this.normalizeMemberRole(role)) {
            case 'owner': return 'Владелец';
            case 'admin': return 'Админ';
            default: return 'Участник';
        }
    }

    serverRoleLabel(roleId) {
        const role = String(roleId || '').trim();
        if (!role) return 'Участник';
        if (role === 'owner') return 'Владелец';
        if (role === 'admin') return 'Админ';
        if (role === 'member') return 'Участник';
        const found = (this.S.serverModal.roles || []).find(item => String(item.roleId || '') === role);
        return found?.name || role;
    }

    serverRoleList() {
        return Array.isArray(this.S.serverModal.roles) ? this.S.serverModal.roles : [];
    }

    draftServerRoleList() {
        return Array.isArray(this.S.serverModal.draftRoles) ? this.S.serverModal.draftRoles : [];
    }

    syncDraftServerRolesFromDom() {
        if (this.S.serverModal.mode !== 'create') return this.draftServerRoleList();
        const cards = Array.from(document.querySelectorAll('[data-draft-role-card]'));
        const roles = cards.map(card => {
            const draftId = String(card.getAttribute('data-draft-role-card') || '').trim();
            return {
                draftId,
                collapsed: String(card.getAttribute('data-draft-role-collapsed') || '1') !== '0',
                name: String(card.querySelector('[data-draft-role-name]')?.value || '').trim(),
                color: this.normalizeColorValue(card.querySelector('[data-draft-role-color]')?.value || '#cbff00'),
                can_view: !!card.querySelector('[data-draft-role-view]')?.checked,
                can_send: !!card.querySelector('[data-draft-role-send]')?.checked,
                can_manage: !!card.querySelector('[data-draft-role-manage]')?.checked,
            };
        }).filter(role => role.draftId);
        this.setServerModalState({ draftRoles: roles });
        return roles;
    }

    serverRoleOptionsHtml(selected = 'member') {
        const roles = [...this.serverRoleList(), ...this.draftServerRoleList()];
        const options = [
            { roleId: 'member', name: 'Участник' },
            { roleId: 'admin', name: 'Админ' },
            ...roles.filter(role => role.roleId && role.roleId !== 'member' && role.roleId !== 'admin' && role.roleId !== 'owner'),
        ];
        return options.map(role => {
            const roleId = String(role.roleId || '').trim();
            const label = this.esc(role.name || this.serverRoleLabel(roleId));
            const isSelected = roleId === String(selected || '').trim() ? 'selected' : '';
            return `<option value="${this.esc(roleId)}" ${isSelected}>${label}</option>`;
        }).join('');
    }

    normalizeColorValue(value) {
        const raw = String(value || '').trim();
        if (/^#[0-9a-fA-F]{6}$/.test(raw)) return raw.toLowerCase();
        return '#cbff00';
    }

    hexToRgb(hex) {
        const value = this.normalizeColorValue(hex).slice(1);
        const num = Number.parseInt(value, 16);
        return {
            r: (num >> 16) & 255,
            g: (num >> 8) & 255,
            b: num & 255,
        };
    }

    rgbToHex(r, g, b) {
        const toHex = (n) => Number(n || 0).toString(16).padStart(2, '0');
        return `#${toHex(Math.max(0, Math.min(255, Math.round(r))))}${toHex(Math.max(0, Math.min(255, Math.round(g))))}${toHex(Math.max(0, Math.min(255, Math.round(b))))}`;
    }

    rgbToHsl(r, g, b) {
        const rn = (r || 0) / 255;
        const gn = (g || 0) / 255;
        const bn = (b || 0) / 255;
        const max = Math.max(rn, gn, bn);
        const min = Math.min(rn, gn, bn);
        const delta = max - min;
        let h = 0;
        let s = 0;
        const l = (max + min) / 2;
        if (delta !== 0) {
            s = delta / (1 - Math.abs(2 * l - 1));
            switch (max) {
                case rn:
                    h = 60 * (((gn - bn) / delta) % 6);
                    break;
                case gn:
                    h = 60 * (((bn - rn) / delta) + 2);
                    break;
                default:
                    h = 60 * (((rn - gn) / delta) + 4);
                    break;
            }
        }
        return {
            h: (h + 360) % 360,
            s: s * 100,
            l: l * 100,
        };
    }

    hslToRgb(h, s, l) {
        const hue = ((h % 360) + 360) % 360;
        const sat = Math.max(0, Math.min(100, Number(s) || 0)) / 100;
        const lig = Math.max(0, Math.min(100, Number(l) || 0)) / 100;
        const c = (1 - Math.abs(2 * lig - 1)) * sat;
        const hp = hue / 60;
        const x = c * (1 - Math.abs((hp % 2) - 1));
        let r1 = 0, g1 = 0, b1 = 0;
        if (hp >= 0 && hp < 1) [r1, g1, b1] = [c, x, 0];
        else if (hp < 2) [r1, g1, b1] = [x, c, 0];
        else if (hp < 3) [r1, g1, b1] = [0, c, x];
        else if (hp < 4) [r1, g1, b1] = [0, x, c];
        else if (hp < 5) [r1, g1, b1] = [x, 0, c];
        else [r1, g1, b1] = [c, 0, x];
        const m = lig - c / 2;
        return {
            r: Math.round((r1 + m) * 255),
            g: Math.round((g1 + m) * 255),
            b: Math.round((b1 + m) * 255),
        };
    }

    hueToHex(hue) {
        const rgb = this.hslToRgb(hue, 100, 50);
        return this.rgbToHex(rgb.r, rgb.g, rgb.b);
    }

    bindColorWheel({ wheelId, hiddenId, hexId, initialValue = '#cbff00' }) {
        const wheel = document.getElementById(wheelId);
        const hidden = document.getElementById(hiddenId);
        const hexInput = document.getElementById(hexId);
        if (!wheel || this.colorWheelBindings.has(wheelId)) return;
        this.colorWheelBindings.add(wheelId);

        const setFromPoint = (clientX, clientY) => {
            const rect = wheel.getBoundingClientRect();
            if (!rect.width || !rect.height) return;
            const dx = clientX - rect.left - rect.width / 2;
            const dy = clientY - rect.top - rect.height / 2;
            const angle = Math.atan2(dy, dx) * 180 / Math.PI + 90;
            this.applyColorWheelValue({ wheel, hidden, hexInput, value: this.hueToHex(angle) });
        };

        const onPointerDown = (e) => {
            e.preventDefault();
            try { wheel.setPointerCapture(e.pointerId); } catch (_) {}
            setFromPoint(e.clientX, e.clientY);
        };
        const onPointerMove = (e) => {
            if ((e.buttons || 0) === 0) return;
            setFromPoint(e.clientX, e.clientY);
        };
        const onClick = (e) => {
            if (typeof e.clientX !== 'number' || typeof e.clientY !== 'number') return;
            setFromPoint(e.clientX, e.clientY);
        };
        const onHexInput = () => this.applyColorWheelValue({ wheel, hidden, hexInput, value: hexInput?.value || hidden?.value || initialValue });

        wheel.addEventListener('pointerdown', onPointerDown);
        wheel.addEventListener('pointermove', onPointerMove);
        wheel.addEventListener('mousedown', onPointerDown);
        wheel.addEventListener('click', onClick);
        hexInput?.addEventListener('input', onHexInput);
        hidden?.addEventListener('input', () => this.applyColorWheelValue({ wheel, hidden, hexInput, value: hidden.value }));
    }

    applyColorWheelValue({ wheel, hidden, hexInput, value }) {
        if (!wheel) return;
        const normalized = this.normalizeColorValue(value);
        const { h } = this.rgbToHsl(...Object.values(this.hexToRgb(normalized)));
        const rect = wheel.getBoundingClientRect();
        const radius = Math.max(20, Math.min(rect.width, rect.height) * 0.36);
        const angle = ((h - 90) * Math.PI) / 180;
        const x = (rect.width / 2) + Math.cos(angle) * radius;
        const y = (rect.height / 2) + Math.sin(angle) * radius;
        wheel.style.setProperty('--thumb-x', `${x}px`);
        wheel.style.setProperty('--thumb-y', `${y}px`);
        wheel.style.setProperty('--wheel-color', normalized);
        if (hidden && hidden.value !== normalized) hidden.value = normalized;
        if (hexInput && hexInput.value.toLowerCase() !== normalized) hexInput.value = normalized;
    }

    canManageServer(server = null) {
        const current = server || this.currentServer();
        const role = this.normalizeMemberRole(current?.myRole || current?.my_role || '');
        return role === 'owner' || role === 'admin';
    }

    openServerOverlay() {
        const overlay = document.getElementById('serverOverlay');
        if (overlay) {
            overlay.hidden = false;
            requestAnimationFrame(() => overlay.classList.add('visible'));
        }
    }

    closeServerOverlay() {
        const overlay = document.getElementById('serverOverlay');
        if (overlay) {
            overlay.classList.remove('visible');
            setTimeout(() => {
                overlay.hidden = true;
            }, 180);
        }
    }

    setServerModalState(partial = {}) {
        this.S.serverModal = {
            ...this.S.serverModal,
            ...partial,
        };
    }

    renderServerModalMembers() {
        const list = document.getElementById('serverMembersList');
        const count = document.getElementById('serverMembersCount');
        const server = this.currentServer();
        const members = Array.isArray(this.S.serverModal.members) ? this.S.serverModal.members : [];
        const canManage = this.canManageServer(server);
        if (count) count.textContent = String(members.length || 0);
        if (!list) return;
        if (this.S.serverModal.loading && members.length === 0) {
            list.innerHTML = `<div class="empty-state">
                <div class="empty-ttl">Загрузка участников</div>
                <div class="empty-sub">Подождите секунду</div>
            </div>`;
            return;
        }
        if (this.S.serverModal.mode !== 'edit') {
            list.innerHTML = `<div class="empty-state">
                <div class="empty-ttl">После создания</div>
                <div class="empty-sub">Здесь появятся участники и роли</div>
            </div>`;
            return;
        }

        if (members.length === 0) {
            list.innerHTML = `<div class="empty-state">
                <div class="empty-ttl">Нет участников</div>
                <div class="empty-sub">Добавьте первых участников сервера</div>
            </div>`;
            return;
        }

        list.innerHTML = members.map(member => {
            const role = this.normalizeMemberRole(member.role);
            const isOwner = role === 'owner';
            const joined = member.joinedAt ? this.fmtDate(member.joinedAt) || this.fmtTime(member.joinedAt) : '';
            const select = `
                <select class="settings-input server-member-role" data-member-role="${this.esc(member.username)}" ${isOwner ? 'disabled' : ''}>
                    ${isOwner ? '<option value="owner" selected>Владелец</option>' : this.serverRoleOptionsHtml(role)}
                </select>
            `;
            return `<div class="server-member-row ${isOwner ? 'owner' : ''}">
                <div class="server-member-info">
                    <div class="server-member-name">${this.esc(member.username)}</div>
                    <div class="server-member-meta">${this.esc(this.serverRoleLabel(role))}${joined ? ` · ${this.esc(joined)}` : ''}</div>
                </div>
                ${select}
                <button class="server-member-remove" type="button" data-member-remove="${this.esc(member.username)}" ${isOwner || !canManage ? 'disabled' : ''} title="Удалить">×</button>
            </div>`;
        }).join('');
    }

    renderPublicServersModal() {
        const list = document.getElementById('serverDiscoverList');
        const count = document.getElementById('serverDiscoverCount');
        const refreshBtn = document.getElementById('serverDiscoverRefreshBtn');
        const servers = this.renderFilteredPublicServers();
        if (count) count.textContent = String(servers.length || 0);
        if (refreshBtn) refreshBtn.disabled = !!this.S.serverModal.loading;
        if (!list) return;
        if (this.S.serverModal.loading && servers.length === 0) {
            list.innerHTML = `<div class="empty-state">
                <div class="empty-ttl">Поиск серверов</div>
                <div class="empty-sub">Секунду, подбираем публичные сообщества</div>
            </div>`;
            return;
        }
        if (servers.length === 0) {
            list.innerHTML = `<div class="empty-state">
                <div class="empty-ttl">Публичных серверов нет</div>
                <div class="empty-sub">Пока что нечего открывать из меню</div>
            </div>`;
            return;
        }

        list.innerHTML = servers.map(server => {
            const memberCount = Number(server.memberCount || server.member_count || 0) || 0;
            const channelCount = Array.isArray(server.channels) ? server.channels.length : 0;
            const role = this.normalizeMemberRole(server.myRole || server.my_role || '');
            const alreadyJoined = role === 'owner' || role === 'admin' || role === 'member';
            const joinTarget = server.joinLink || server.join_link || server.id;
            const actionLabel = alreadyJoined ? 'Открыть' : 'Войти';
            return `<div class="server-discover-row">
                <button class="server-item server-discover-item" type="button" data-public-server-id="${this.esc(server.id)}" title="${this.esc(server.name)}">
                    <span class="server-avatar" style="background:${this.esc(server.color || 'linear-gradient(180deg, #cbff00, #8c8c8c)')}">${this.esc(server.icon || server.name?.[0] || 'S')}</span>
                    <div class="server-meta">
                        <div class="server-name">${this.esc(server.name)}</div>
                        <div class="server-prev">${this.esc(server.description || 'Публичный сервер')}${channelCount ? ` · ${channelCount} каналов` : ''}${memberCount ? ` · ${memberCount} участников` : ''}</div>
                    </div>
                </button>
                <div class="server-discover-actions">
                    <button class="btn-flat" type="button" data-public-server-open="${this.esc(server.id)}">${actionLabel}</button>
                    <button class="btn-flat" type="button" data-public-server-join="${this.esc(joinTarget)}">${alreadyJoined ? 'Перейти' : 'Вступить'}</button>
                </div>
            </div>`;
        }).join('');
    }

    renderServerModal() {
        const server = this.currentServer();
        const mode = this.S.serverModal.mode;
        const isEdit = mode === 'edit';
        const isDiscover = mode === 'discover';
        const grid = document.querySelector('.server-modal-grid');
        const basicsCard = document.getElementById('serverBasicsCard');
        const membersCard = document.getElementById('serverMembersCard');
        const discoverCard = document.getElementById('serverDiscoverCard');
        const title = document.getElementById('serverModalTitle');
        const hint = document.getElementById('serverModalHint');
        const kicker = document.getElementById('serverModalKicker');
        const modeNote = document.getElementById('serverModalModeNote');
        const saveBtn = document.getElementById('serverSaveBtn');
        const deleteBtn = document.getElementById('serverDeleteBtn');
        const serverModalCancel = document.getElementById('serverModalCancel');
        const nameInput = document.getElementById('serverNameInput');
        const descInput = document.getElementById('serverDescriptionInput');
        const iconInput = document.getElementById('serverIconInput');
        const colorInput = document.getElementById('serverColorInput');
        const publicInput = document.getElementById('serverPublicInput');
        const serverMembersList = document.getElementById('serverMembersList');
        const serverRolesCard = document.getElementById('serverRolesCard');
        const serverJoinLinkInput = document.getElementById('serverJoinLinkInput');
        const serverJoinLinkGenerateBtn = document.getElementById('serverJoinLinkGenerateBtn');
        const serverJoinLinkCopyBtn = document.getElementById('serverJoinLinkCopyBtn');
        const serverAvatarUploadBtn = document.getElementById('serverAvatarUploadBtn');
        const serverAvatarRemoveBtn = document.getElementById('serverAvatarRemoveBtn');
        const serverBannerUploadBtn = document.getElementById('serverBannerUploadBtn');
        const serverBannerRemoveBtn = document.getElementById('serverBannerRemoveBtn');
        const serverRoleNameInput = document.getElementById('serverRoleNameInput');
        const serverRoleColorInput = document.getElementById('serverRoleColorInput');
        const serverRolePermView = document.getElementById('serverRolePermView');
        const serverRolePermSend = document.getElementById('serverRolePermSend');
        const serverRolePermManage = document.getElementById('serverRolePermManage');
        const discoverQuery = document.getElementById('serverDiscoverQuery');
        const errorBox = document.getElementById('serverModalError');
        const canManage = this.canManageServer(server);
        const current = isEdit && this.S.serverModal.serverId
            ? (this.S.servers || []).find(s => s.id === this.S.serverModal.serverId)
            : null;

        if (grid) grid.classList.toggle('is-discover', isDiscover);
        if (basicsCard) basicsCard.hidden = isDiscover;
        if (membersCard) membersCard.hidden = !isEdit;
        if (serverRolesCard) serverRolesCard.hidden = !isEdit;
        if (discoverCard) discoverCard.hidden = !isDiscover;
        if (title) title.textContent = isEdit ? 'Настройки сервера' : isDiscover ? 'Публичные серверы' : 'Создать сервер';
        if (hint) hint.textContent = isEdit
            ? 'Переименуйте сервер, измените оформление и управляйте ролями.'
            : isDiscover
                ? 'Выберите публичный сервер и войдите в него через меню без автодобавления в список.'
            : 'Настройте имя, оформление и доступ перед созданием.';
        if (kicker) kicker.textContent = isEdit ? 'Settings' : isDiscover ? 'Discover' : 'Creation';
        if (modeNote) modeNote.textContent = isEdit ? 'edit' : isDiscover ? 'browse' : 'create';
        if (saveBtn) {
            saveBtn.hidden = isDiscover;
            saveBtn.textContent = this.S.serverModal.saving ? 'Сохранение...' : (isEdit ? 'Сохранить' : 'Создать');
            saveBtn.disabled = !!this.S.serverModal.saving || !!this.S.serverModal.loading;
        }
        if (deleteBtn) deleteBtn.hidden = !isEdit || !canManage || this.normalizeMemberRole(current?.myRole || current?.my_role || '') !== 'owner';
        if (serverModalCancel) serverModalCancel.textContent = isDiscover ? 'Закрыть' : 'Отмена';
        if (nameInput) nameInput.value = current?.name || '';
        if (descInput) descInput.value = current?.description || '';
        if (iconInput) iconInput.value = current?.icon || '';
        const normalizedColor = this.normalizeColorValue(current?.color || '#cbff00');
        if (colorInput) colorInput.value = normalizedColor;
        const colorHexInput = document.getElementById('serverColorHexInput');
        if (colorHexInput) colorHexInput.value = normalizedColor;
        this.applyColorWheelValue({
            wheel: document.getElementById('serverColorWheel'),
            hidden: colorInput,
            hexInput: colorHexInput,
            value: normalizedColor,
        });
        if (publicInput) publicInput.checked = current ? !!current.is_public : true;
        if (discoverQuery && !discoverQuery.value) {
            discoverQuery.value = '';
        }
        const editLocked = !isEdit;
        const linkLocked = !!this.S.serverModal.saving || !!this.S.serverModal.loading;
        if (serverAvatarUploadBtn) serverAvatarUploadBtn.disabled = editLocked;
        if (serverAvatarRemoveBtn) serverAvatarRemoveBtn.disabled = editLocked;
        if (serverBannerUploadBtn) serverBannerUploadBtn.disabled = editLocked;
        if (serverBannerRemoveBtn) serverBannerRemoveBtn.disabled = editLocked;
        if (serverJoinLinkInput) serverJoinLinkInput.disabled = linkLocked;
        if (serverJoinLinkGenerateBtn) serverJoinLinkGenerateBtn.disabled = linkLocked;
        if (serverJoinLinkCopyBtn) serverJoinLinkCopyBtn.disabled = linkLocked;
        if (serverRoleNameInput) serverRoleNameInput.disabled = false;
        if (serverRoleColorInput) serverRoleColorInput.disabled = false;
        const serverRoleColorHexInput = document.getElementById('serverRoleColorHexInput');
        if (serverRoleColorHexInput) serverRoleColorHexInput.disabled = false;
        if (serverRolePermView) serverRolePermView.disabled = false;
        if (serverRolePermSend) serverRolePermSend.disabled = false;
        if (serverRolePermManage) serverRolePermManage.disabled = false;
        if (serverAvatarUploadBtn) serverAvatarUploadBtn.title = isEdit ? 'Загрузить аватар' : 'Создать сервер сначала';
        if (serverAvatarRemoveBtn) serverAvatarRemoveBtn.title = isEdit ? 'Удалить аватар' : 'Создать сервер сначала';
        if (serverBannerUploadBtn) serverBannerUploadBtn.title = isEdit ? 'Загрузить баннер' : 'Создать сервер сначала';
        if (serverBannerRemoveBtn) serverBannerRemoveBtn.title = isEdit ? 'Удалить баннер' : 'Создать сервер сначала';
        if (errorBox) errorBox.textContent = this.S.serverModal.error || '';
        if (serverMembersList) {
            serverMembersList.classList.toggle('is-loading', !!this.S.serverModal.loading);
        }
        const roleSelect = document.getElementById('serverMemberRole');
        if (roleSelect) {
            roleSelect.innerHTML = this.serverRoleOptionsHtml(roleSelect.value || 'member');
        }
        if (serverRoleColorInput) {
            const roleColor = this.normalizeColorValue(serverRoleColorInput.value || '#cbff00');
            serverRoleColorInput.value = roleColor;
            if (serverRoleColorHexInput) serverRoleColorHexInput.value = roleColor;
            this.applyColorWheelValue({
                wheel: document.getElementById('serverRoleColorWheel'),
                hidden: serverRoleColorInput,
                hexInput: serverRoleColorHexInput,
                value: roleColor,
            });
        }
        this.renderServerModalMembers();
        this.renderServerRoles();
        this.renderServerJoinLink();
        this.renderPublicServersModal();
        if (isEdit && (this.S.serverModal.serverId || server?.id)) {
            this.syncServerAssetPreview(this.S.serverModal.serverId || server?.id || '');
        } else {
            this.resetServerAssetPreview();
        }
    }

    async loadServerMembers(serverId) {
        const sid = String(serverId || '').trim();
        if (!sid) return [];
        const res = await this.apiFetch(`/api/servers/${encodeURIComponent(sid)}/members`);
        if (!res.ok) {
            throw new Error(await res.text() || 'Не удалось загрузить участников сервера');
        }
        const data = await res.json();
        const members = Array.isArray(data) ? data : (Array.isArray(data?.members) ? data.members : []);
        return members.map(member => ({
            ...member,
            role: this.normalizeMemberRole(member.role),
        }));
    }

    async loadServerRoles(serverId) {
        const sid = String(serverId || '').trim();
        if (!sid) return [];
        const res = await this.apiFetch(`/api/servers/${encodeURIComponent(sid)}/roles`);
        if (!res.ok) {
            throw new Error(await res.text() || 'Не удалось загрузить роли сервера');
        }
        const data = await res.json();
        const roles = Array.isArray(data?.roles) ? data.roles : [];
        return roles.map(role => ({
            ...role,
            roleId: String(role.roleId || role.role_id || '').trim(),
            name: String(role.name || '').trim(),
            color: String(role.color || '#cbff00').trim(),
            canView: !!(role.canView ?? role.can_view),
            canSend: !!(role.canSend ?? role.can_send),
            canManage: !!(role.canManage ?? role.can_manage),
            position: Number(role.position || 0) || 0,
        }));
    }

    renderServerJoinLink() {
        const input = document.getElementById('serverJoinLinkInput');
        if (!input) return;
        input.value = this.S.serverModal.joinLink || '';
    }

    renderServerRoles() {
        const list = document.getElementById('serverRolesList');
        const count = document.getElementById('serverRolesCount');
        const isEdit = this.S.serverModal.mode === 'edit';
        const roles = isEdit ? this.serverRoleList() : this.draftServerRoleList();
        if (count) count.textContent = String(roles.length || 0);
        if (!list) return;
        if (roles.length === 0) {
            list.innerHTML = `<div class="empty-state">
                <div class="empty-ttl">${isEdit ? 'Ролей нет' : 'Черновики ролей'}</div>
                <div class="empty-sub">${isEdit ? 'Создайте первую роль' : 'Добавьте роли перед созданием сервера'}</div>
            </div>`;
            return;
        }
        list.innerHTML = roles.map(role => {
            if (!isEdit) {
                const draftId = String(role.draftId || '').trim();
                const safeDraftId = draftId.replace(/[^a-z0-9_-]/gi, '_');
                const wheelId = `draftRoleColorWheel-${safeDraftId}`;
                const colorId = `draftRoleColorInput-${safeDraftId}`;
                const currentColor = this.normalizeColorValue(role.color || '#cbff00');
                const collapsed = role.collapsed !== false;
                const draftPermCount = Number(!!role.can_view) + Number(!!role.can_send) + Number(!!role.can_manage);
                return `<div class="server-role-card draft-role ${collapsed ? 'collapsed' : ''}" data-draft-role-card="${this.esc(draftId)}" data-draft-role-collapsed="${collapsed ? '1' : '0'}">
                    <div class="server-role-head server-role-head--draft">
                        <span class="server-role-chip" style="background:${this.esc(currentColor)}"></span>
                        <div>
                            <div class="server-role-name">${this.esc(role.name || 'Новая роль')}</div>
                            <div class="server-role-meta">черновик</div>
                        </div>
                        <button class="btn-flat server-role-toggle" type="button" data-draft-role-toggle="${this.esc(draftId)}">${collapsed ? 'Развернуть' : 'Свернуть'}</button>
                    </div>
                    <div class="server-role-body">
                        <div class="server-role-meta server-role-summary">Права: ${draftPermCount}/3</div>
                        <div class="server-role-controls">
                        <input class="settings-input" data-draft-role-name="${this.esc(draftId)}" value="${this.esc(role.name || '')}" placeholder="Название роли">
                        <div class="role-color-editor">
                            <div class="color-wheel color-wheel--tiny" id="${this.esc(wheelId)}" tabindex="0" aria-label="Цвет роли">
                                <div class="color-wheel-thumb"></div>
                                <div class="color-wheel-center"></div>
                            </div>
                            <input type="hidden" data-draft-role-color="${this.esc(draftId)}" id="${this.esc(colorId)}" value="${this.esc(currentColor)}">
                        </div>
                        <div class="server-perm-grid">
                            <label class="server-perm-row">
                                <span>Чтение</span>
                                <input type="checkbox" data-draft-role-view="${this.esc(draftId)}" ${role.can_view ? 'checked' : ''}>
                            </label>
                            <label class="server-perm-row">
                                <span>Отправка</span>
                                <input type="checkbox" data-draft-role-send="${this.esc(draftId)}" ${role.can_send ? 'checked' : ''}>
                            </label>
                            <label class="server-perm-row">
                                <span>Управление</span>
                                <input type="checkbox" data-draft-role-manage="${this.esc(draftId)}" ${role.can_manage ? 'checked' : ''}>
                            </label>
                        </div>
                        <div class="server-role-actions">
                            <button class="btn-flat" type="button" data-draft-role-delete="${this.esc(draftId)}">Удалить</button>
                        </div>
                        </div>
                    </div>
                </div>`;
            }
            const locked = role.roleId === 'member' || role.roleId === 'admin';
            const safeRoleId = String(role.roleId || '').replace(/[^a-z0-9_-]/gi, '_');
            const wheelId = `roleColorWheel-${safeRoleId}`;
            const colorId = `roleColorInput-${safeRoleId}`;
            const currentColor = this.normalizeColorValue(role.color || '#cbff00');
            const options = `
                <div class="server-role-controls">
                    <input class="settings-input" data-role-name="${this.esc(role.roleId)}" value="${this.esc(role.name || '')}">
                    <div class="role-color-editor">
                        <div class="color-wheel color-wheel--tiny" id="${this.esc(wheelId)}" tabindex="0" aria-label="Цвет роли">
                            <div class="color-wheel-thumb"></div>
                            <div class="color-wheel-center"></div>
                        </div>
                        <input type="hidden" data-role-color="${this.esc(role.roleId)}" id="${this.esc(colorId)}" value="${this.esc(currentColor)}">
                    </div>
                    <div class="server-role-actions">
                        <button class="btn-flat" type="button" data-role-save="${this.esc(role.roleId)}">Сохранить</button>
                        <button class="btn-flat" type="button" data-role-delete="${this.esc(role.roleId)}" ${locked ? 'disabled' : ''}>Удалить</button>
                    </div>
                </div>
            `;
            return `<div class="server-role-card ${locked ? 'owner-role' : ''}" data-role-card="${this.esc(role.roleId)}">
                <div class="server-role-head">
                    <span class="server-role-chip" style="background:${this.esc(role.color || '#cbff00')}"></span>
                    <div>
                        <div class="server-role-name">${this.esc(role.name || role.roleId)}</div>
                        <div class="server-role-meta">${this.esc(role.roleId)}</div>
                    </div>
                    <span class="server-role-meta">${locked ? 'системная' : 'роль'}</span>
                </div>
                <div class="server-perm-grid">
                    <label class="server-perm-row">
                        <span>Чтение</span>
                        <input type="checkbox" data-role-view="${this.esc(role.roleId)}" ${role.canView ? 'checked' : ''} ${locked ? '' : ''}>
                    </label>
                    <label class="server-perm-row">
                        <span>Отправка</span>
                        <input type="checkbox" data-role-send="${this.esc(role.roleId)}" ${role.canSend ? 'checked' : ''} ${locked ? '' : ''}>
                    </label>
                    <label class="server-perm-row">
                        <span>Управление</span>
                        <input type="checkbox" data-role-manage="${this.esc(role.roleId)}" ${role.canManage ? 'checked' : ''}>
                    </label>
                </div>
                ${options}
            </div>`;
        }).join('');
        requestAnimationFrame(() => {
            roles.forEach(role => {
                if (!isEdit) {
                    const draftId = String(role.draftId || '').trim();
                    const safeDraftId = draftId.replace(/[^a-z0-9_-]/gi, '_');
                    this.colorWheelBindings.delete(`draftRoleColorWheel-${safeDraftId}`);
                    this.bindColorWheel({
                        wheelId: `draftRoleColorWheel-${safeDraftId}`,
                        hiddenId: `draftRoleColorInput-${safeDraftId}`,
                        hexId: null,
                        initialValue: this.normalizeColorValue(role.color || '#cbff00'),
                    });
                    return;
                }
                const safeRoleId = String(role.roleId || '').replace(/[^a-z0-9_-]/gi, '_');
                const wheelId = `roleColorWheel-${safeRoleId}`;
                const colorId = `roleColorInput-${safeRoleId}`;
                this.colorWheelBindings.delete(wheelId);
                this.bindColorWheel({
                    wheelId,
                    hiddenId: colorId,
                    hexId: null,
                    initialValue: this.normalizeColorValue(role.color || '#cbff00'),
                });
            });
        });
    }

    async openServerModal(mode = 'create', serverId = null) {
        const nextMode = mode === 'edit' ? 'edit' : 'create';
        const sid = nextMode === 'edit' ? String(serverId || this.S.activeServer || '').trim() : null;
        const server = sid ? (this.S.servers || []).find(item => item.id === sid) : null;
        if (nextMode === 'edit' && (!server || !this.canManageServer(server))) {
            return;
        }
        const selectedChannelId = nextMode === 'edit'
            ? ((this.S.activeServer === sid ? this.S.activeChannel : null) || server?.channels?.[0]?.id || null)
            : null;

        this.setServerModalState({
            mode: nextMode,
            serverId: sid,
            members: nextMode === 'edit' ? (server?.members || []) : [],
            roles: [],
            draftRoles: [],
            joinLink: nextMode === 'edit' ? (server?.joinLink || server?.join_link || '') : '',
            selectedChannelId,
            channelPermissions: [],
            loading: nextMode === 'edit',
            saving: false,
            error: '',
        });
        this.openServerOverlay();
        this.renderServerModal();

        if (nextMode === 'edit' && sid) {
            try {
                const [members, roles] = await Promise.all([
                    this.loadServerMembers(sid),
                    this.loadServerRoles(sid),
                ]);
                this.setServerModalState({
                    members,
                    roles,
                    loading: false,
                });
                this.renderServerModal();
            } catch (e) {
                this.setServerModalState({ loading: false, error: e?.message || 'Не удалось загрузить участников' });
                this.renderServerModal();
            }
        }
    }

    async openPublicServersModal() {
        const discoverQuery = document.getElementById('serverDiscoverQuery');
        if (discoverQuery) discoverQuery.value = '';
        this.setServerModalState({
            mode: 'discover',
            serverId: null,
            members: [],
            roles: [],
            draftRoles: [],
            joinLink: '',
            selectedChannelId: null,
            channelPermissions: [],
            loading: true,
            saving: false,
            error: '',
        });
        this.openServerOverlay();
        this.renderServerModal();
        await this.loadPublicServers({ silent: true });
    }

    publicServerFilterValue() {
        const input = document.getElementById('serverDiscoverQuery');
        return String(input?.value || '').trim().toLowerCase();
    }

    renderFilteredPublicServers() {
        const q = this.publicServerFilterValue();
        const servers = Array.isArray(this.S.publicServers) ? this.S.publicServers : [];
        if (!q) return servers;
        return servers.filter(server => {
            const haystack = `${server.name || ''} ${server.description || server.hint || ''} ${server.joinLink || server.join_link || ''}`.toLowerCase();
            return haystack.includes(q);
        });
    }

    async loadPublicServers({ silent = false } = {}) {
        try {
            this.setServerModalState({ loading: true, error: '' });
            this.renderServerModal();
            const res = await this.apiFetch('/api/discover/servers');
            if (!res.ok) {
                throw new Error(await res.text() || 'Не удалось загрузить публичные серверы');
            }
            const data = await res.json();
            this.S.publicServers = this.normalizeServers(Array.isArray(data?.servers) ? data.servers : []);
            this.setServerModalState({ loading: false, error: '' });
            this.renderServerModal();
        } catch (e) {
            this.S.publicServers = [];
            this.setServerModalState({
                loading: false,
                error: e?.message || 'Не удалось загрузить публичные серверы',
            });
            this.renderServerModal();
            if (!silent) {
                this.addLogEntry({ type: 'ERROR', msg: e?.message || 'Не удалось загрузить публичные серверы', ts: new Date().toLocaleTimeString() });
            }
        }
    }

    async enterPublicServer(serverIdOrLink) {
        const raw = String(serverIdOrLink || '').trim();
        if (!raw) return;
        await this.joinServerByLink(raw);
        if (this.S.serverModal.mode === 'discover') {
            await this.loadPublicServers({ silent: true });
        }
    }

    async submitServerModal() {
        if (this.S.serverModal.saving) return;
        const mode = this.S.serverModal.mode;
        const serverId = this.S.serverModal.serverId;
        const nameInput = document.getElementById('serverNameInput');
        const descInput = document.getElementById('serverDescriptionInput');
        const iconInput = document.getElementById('serverIconInput');
        const colorInput = document.getElementById('serverColorInput');
        const joinLinkInput = document.getElementById('serverJoinLinkInput');
        const publicInput = document.getElementById('serverPublicInput');
        const payload = {
            name: (nameInput?.value || '').trim(),
            description: (descInput?.value || '').trim(),
            icon: (iconInput?.value || '').trim(),
            color: this.normalizeColorValue(colorInput?.value || '#cbff00'),
            join_link: (joinLinkInput?.value || '').trim(),
            is_public: !!publicInput?.checked,
        };
        if (mode !== 'edit') {
            payload.roles = this.syncDraftServerRolesFromDom().map(role => ({
                name: role.name,
                color: role.color,
                can_view: !!role.can_view,
                can_send: !!role.can_send,
                can_manage: !!role.can_manage,
            }));
        }

        if (!payload.name) {
            this.setServerModalState({ error: 'Введите название сервера' });
            this.renderServerModal();
            return;
        }

        this.setServerModalState({ saving: true, error: '' });
        this.renderServerModal();

        try {
            const endpoint = mode === 'edit' && serverId
                ? `/api/servers/${encodeURIComponent(serverId)}`
                : '/api/servers';
            const res = await this.apiFetch(endpoint, {
                method: mode === 'edit' ? 'PUT' : 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });
            if (!res.ok) {
                throw new Error(await res.text() || 'Не удалось сохранить сервер');
            }
            const data = await res.json();
            this.closeServerOverlay();
            await this.loadServers({ silent: true });
            if (data?.id) {
                this.setActiveServer(data.id, { persist: true });
            }
        } catch (e) {
            this.setServerModalState({ error: e?.message || 'Не удалось сохранить сервер' });
            this.renderServerModal();
        } finally {
            this.setServerModalState({ saving: false });
        }
    }

    async uploadServerAsset(kind, file) {
        const serverId = this.S.serverModal.serverId || this.S.activeServer;
        if (!serverId || !file || this.S.serverModal.mode !== 'edit') return;
        const dataUrl = await this.readFileAsDataURL(file);
        const res = await this.apiFetch(`/api/servers/${encodeURIComponent(serverId)}/assets/${kind}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ data_url: dataUrl }),
        });
        if (!res.ok && res.status !== 204) {
            throw new Error(await res.text() || `Не удалось обновить ${kind}`);
        }
        this.clearServerAssetCache(serverId, kind);
        await this.syncServerAssetPreview(serverId);
    }

    async removeServerAsset(kind) {
        const serverId = this.S.serverModal.serverId || this.S.activeServer;
        if (!serverId || this.S.serverModal.mode !== 'edit') return;
        const res = await this.apiFetch(`/api/servers/${encodeURIComponent(serverId)}/assets/${kind}`, {
            method: 'DELETE',
        });
        if (!res.ok && res.status !== 204) {
            throw new Error(await res.text() || `Не удалось удалить ${kind}`);
        }
        this.clearServerAssetCache(serverId, kind);
        await this.syncServerAssetPreview(serverId);
    }

    async generateServerJoinLink() {
        if (this.S.serverModal.saving) return '';
        const mode = this.S.serverModal.mode;
        const server = mode === 'edit'
            ? this.currentServer()
            : null;
        const fallback = mode === 'edit' && server?.id
            ? `zali://server/${server.id}`
            : `zali://server/${(document.getElementById('serverNameInput')?.value || 'server').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
        this.setServerModalState({ joinLink: fallback, error: '' });
        this.renderServerModal();
        return fallback;
    }

    async joinServerByLink(link) {
        const raw = String(link || '').trim();
        if (!raw) return;
        const inviteMatch = raw.match(/(?:zali:\/\/invite\/|invite\/)?([a-z0-9]{4,64})/i);
        if (inviteMatch && /invite/i.test(raw)) {
            const inviteCode = inviteMatch[1].toLowerCase();
            try {
                const res = await this.apiFetch(`/api/invites/${encodeURIComponent(inviteCode)}/join`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ code: inviteCode }),
                });
                if (!res.ok) {
                    throw new Error(await res.text() || 'Не удалось войти по ссылке');
                }
                const data = await res.json();
                await this.loadServers({ silent: true });
                this.closeServerOverlay();
                if (data?.serverId) {
                    this.setActiveServer(data.serverId, { persist: true });
                }
                this.addLogEntry({ type: 'SUCCESS', msg: `Вход по ссылке успешен: ${inviteCode}`, ts: new Date().toLocaleTimeString() });
            } catch (e) {
                this.addLogEntry({ type: 'ERROR', msg: e?.message || 'Не удалось войти по ссылке', ts: new Date().toLocaleTimeString() });
            }
            return;
        }

        try {
            const res = await this.apiFetch('/api/servers/join', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ link: raw }),
            });
            if (!res.ok) {
                throw new Error(await res.text() || 'Не удалось войти по ссылке');
            }
            const data = await res.json();
            await this.loadServers({ silent: true });
            this.closeServerOverlay();
            if (data?.serverId) {
                this.setActiveServer(data.serverId, { persist: true });
            }
            this.addLogEntry({ type: 'SUCCESS', msg: `Вход по ссылке успешен`, ts: new Date().toLocaleTimeString() });
        } catch (e) {
            this.addLogEntry({ type: 'ERROR', msg: e?.message || 'Не удалось войти по ссылке', ts: new Date().toLocaleTimeString() });
        }
    }

    extractInviteCode(value) {
        const raw = String(value || '').trim();
        if (!raw) return '';
        const match = raw.match(/(?:zali:\/\/invite\/|invite\/|zali:\/\/server\/|server\/)?([a-z0-9._-]{2,128})/i);
        return (match && match[1]) ? match[1].toLowerCase() : raw.toLowerCase();
    }

    rolePayloadFromCreateForm() {
        const nameInput = document.getElementById('serverRoleNameInput');
        const colorInput = document.getElementById('serverRoleColorInput');
        const colorHexInput = document.getElementById('serverRoleColorHexInput');
        return {
            name: (nameInput?.value || '').trim(),
            color: this.normalizeColorValue(colorInput?.value || colorHexInput?.value || '#cbff00'),
            can_view: !!document.getElementById('serverRolePermView')?.checked,
            can_send: !!document.getElementById('serverRolePermSend')?.checked,
            can_manage: !!document.getElementById('serverRolePermManage')?.checked,
        };
    }

    rolePayloadFromCard(roleId) {
        const card = document.querySelector(`[data-role-card="${CSS.escape(String(roleId || ''))}"]`);
        if (!card) return null;
        const name = String(card.querySelector(`[data-role-name="${CSS.escape(String(roleId || ''))}"]`)?.value || '').trim();
        const color = this.normalizeColorValue(card.querySelector(`[data-role-color="${CSS.escape(String(roleId || ''))}"]`)?.value || '#cbff00');
        return {
            name,
            color,
            can_view: !!card.querySelector(`[data-role-view="${CSS.escape(String(roleId || ''))}"]`)?.checked,
            can_send: !!card.querySelector(`[data-role-send="${CSS.escape(String(roleId || ''))}"]`)?.checked,
            can_manage: !!card.querySelector(`[data-role-manage="${CSS.escape(String(roleId || ''))}"]`)?.checked,
        };
    }

    async createServerRole() {
        const payload = this.rolePayloadFromCreateForm();
        if (!payload.name) {
            this.setServerModalState({ error: 'Введите название роли' });
            this.renderServerModal();
            return;
        }
        if (this.S.serverModal.mode === 'create') {
            const draftRoles = this.syncDraftServerRolesFromDom();
            draftRoles.push({
                draftId: `draft-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
                collapsed: true,
                name: payload.name,
                color: payload.color,
                can_view: payload.can_view,
                can_send: payload.can_send,
                can_manage: payload.can_manage,
            });
            this.setServerModalState({ draftRoles, error: '' });
            const nameInput = document.getElementById('serverRoleNameInput');
            if (nameInput) nameInput.value = '';
            const view = document.getElementById('serverRolePermView');
            const send = document.getElementById('serverRolePermSend');
            const manage = document.getElementById('serverRolePermManage');
            if (view) view.checked = true;
            if (send) send.checked = true;
            if (manage) manage.checked = false;
            this.renderServerModal();
            return;
        }
        const serverId = this.S.serverModal.serverId;
        if (!serverId || this.S.serverModal.mode !== 'edit') return;
        const res = await this.apiFetch(`/api/servers/${encodeURIComponent(serverId)}/roles`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });
        if (!res.ok) {
            throw new Error(await res.text() || 'Не удалось создать роль');
        }
        const role = await res.json();
        const roles = [role, ...(this.S.serverModal.roles || [])].sort((a, b) => Number(a.position || 0) - Number(b.position || 0));
        this.setServerModalState({ roles, error: '' });
        const nameInput = document.getElementById('serverRoleNameInput');
        if (nameInput) nameInput.value = '';
        const view = document.getElementById('serverRolePermView');
        const send = document.getElementById('serverRolePermSend');
        const manage = document.getElementById('serverRolePermManage');
        if (view) view.checked = true;
        if (send) send.checked = true;
        if (manage) manage.checked = false;
        this.renderServerModal();
        await this.loadServers({ silent: true });
    }

    async saveServerRole(roleId) {
        const serverId = this.S.serverModal.serverId;
        if (!serverId || this.S.serverModal.mode !== 'edit') return;
        const payload = this.rolePayloadFromCard(roleId);
        if (!payload) return;
        const res = await this.apiFetch(`/api/servers/${encodeURIComponent(serverId)}/roles/${encodeURIComponent(roleId)}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });
        if (!res.ok) {
            throw new Error(await res.text() || 'Не удалось сохранить роль');
        }
        const updated = await res.json();
        const roles = (this.S.serverModal.roles || []).map(role => String(role.roleId || '') === roleId ? updated : role);
        this.setServerModalState({ roles, error: '' });
        this.renderServerModal();
        await this.loadServers({ silent: true });
    }

    async deleteServerRole(roleId) {
        const serverId = this.S.serverModal.serverId;
        if (!serverId || this.S.serverModal.mode !== 'edit') return;
        const res = await this.apiFetch(`/api/servers/${encodeURIComponent(serverId)}/roles/${encodeURIComponent(roleId)}`, {
            method: 'DELETE',
        });
        if (!res.ok && res.status !== 204) {
            throw new Error(await res.text() || 'Не удалось удалить роль');
        }
        const roles = (this.S.serverModal.roles || []).filter(role => String(role.roleId || '') !== roleId);
        this.setServerModalState({ roles, error: '' });
        this.renderServerModal();
        await this.loadServers({ silent: true });
    }

    async saveServerMembersFromModal() {
        const serverId = this.S.serverModal.serverId;
        if (!serverId || this.S.serverModal.mode !== 'edit') return;
        try {
            const members = await this.loadServerMembers(serverId);
            this.setServerModalState({ members });
            this.renderServerModal();
            await this.loadServers({ silent: true });
        } catch (e) {
            this.setServerModalState({ error: e?.message || 'Не удалось обновить участников' });
            this.renderServerModal();
        }
    }

    currentServer() {
        return (this.S.servers || []).find(server => server.id === this.S.activeServer) || null;
    }

    currentChannel() {
        const server = this.currentServer();
        if (!server) return null;
        return (server.channels || []).find(channel => channel.id === this.S.activeChannel) || null;
    }

    currentServerChatKey() {
        if (!this.S.activeServer || !this.S.activeChannel) return '';
        return `${this.S.activeServer}:${this.S.activeChannel}`;
    }

    voiceRoomKeyForDm(peer) {
        const me = String(this.myName() || '').trim();
        const other = String(peer || '').trim();
        const pair = [me, other].filter(Boolean).sort();
        return pair.length === 2 ? `voice:dm:${pair.join(':')}` : '';
    }

    makeDmCallRoomId(peer) {
        const base = this.voiceRoomKeyForDm(peer);
        if (!base) return '';
        const stamp = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
        return `${base}:${stamp}`;
    }

    voiceRoomKeyForChannel(serverId, channelId) {
        const sid = String(serverId || '').trim();
        const cid = String(channelId || '').trim();
        return sid && cid ? `voice:channel:${sid}:${cid}` : '';
    }

    isVoiceChannel(channel = null) {
        return String(channel?.kind || '').trim().toLowerCase() === 'voice';
    }

    currentVoicePeer() {
        if (this.S.navMode === 'dm') {
            return String(this.S.current || '').trim();
        }
        return '';
    }

    shouldInitiateVoiceOffer(peer) {
        const me = String(this.myName() || '').trim();
        const other = String(peer || '').trim();
        if (!me || !other) return false;
        if (this.voice.roomType === 'dm') {
            const direction = String(this.voice.callTrack?.direction || '').trim();
            return direction === 'outgoing' && this.voice.status === 'connected';
        }
        return me.localeCompare(other) < 0;
    }

    voiceEventPayload(payload = {}) {
        return {
            ...payload,
            type: payload.type || 'voice_signal',
        };
    }

    sendVoiceEvent(payload = {}) {
        const event = this.voiceEventPayload(payload);
        this.voiceTrace('send-event', {
            type: event.type || '',
            roomId: event.roomId || '',
            roomType: event.roomType || '',
            to: event.to || '',
            signalType: event.signal?.type || '',
            participants: Array.isArray(this.voice.participants) ? this.voice.participants : [],
        });
        if (!this.nativeSupports('voice')) {
            if (this.voice.socket && this.voice.socket.readyState === WebSocket.OPEN) {
                try {
                    this.voice.socket.send(JSON.stringify(event));
                } catch (error) {
                    this.voiceTrace('send-event-failed', { type: event.type || '', error: error?.message || String(error) }, 'ERROR');
                    return false;
                }
                return true;
            }
            this.addLogEntry({
                type: 'WARN',
                msg: `Voice signal skipped in browser mode: ${event.type}`,
                ts: new Date().toLocaleTimeString(),
            });
            return false;
        }
        this.postNativeMessage({
            type: 'VOICE_EVENT',
            payload: event,
        });
        return true;
    }

    disconnectBrowserVoiceSocket() {
        this.voiceTrace('socket-disconnect', { generation: this.voiceSocketGeneration, hadSocket: !!this.voice.socket });
        this.voiceSocketGeneration += 1;
        this.voiceSocketReconnectDelayMs = 1000;
        if (this.voiceSocketReconnectTimer) {
            clearTimeout(this.voiceSocketReconnectTimer);
            this.voiceSocketReconnectTimer = null;
        }
        if (this.voice.socket) {
            try {
                this.voice.socket.onopen = null;
                this.voice.socket.onmessage = null;
                this.voice.socket.onclose = null;
                this.voice.socket.onerror = null;
                this.voice.socket.close();
            } catch (e) {}
        }
        this.voice.socket = null;
        this.voice.socketReady = false;
    }

    connectBrowserVoiceSocket() {
        if (this.nativeSupports('voice')) return;
        if (typeof WebSocket === 'undefined') return;
        if (this.voice.socket && (this.voice.socket.readyState === WebSocket.OPEN || this.voice.socket.readyState === WebSocket.CONNECTING)) {
            return;
        }

        this.disconnectBrowserVoiceSocket();
        const generation = ++this.voiceSocketGeneration;
        let url;
        try {
            url = new URL(this.getWsBaseUrl());
        } catch (error) {
            this.addLogEntry({ type: 'ERROR', msg: `Неверный WS URL: ${error?.message || error}`, ts: new Date().toLocaleTimeString() });
            return;
        }

        const sessionToken = String(this.S.session?.token || '').trim();
        if (sessionToken) {
            url.searchParams.set('token', sessionToken);
        }

        try {
            this.voiceTrace('socket-connect', { url: url.toString(), generation, auth: 'cookie-or-header' });
            const socket = new WebSocket(url.toString());
            this.voice.socket = socket;
            this.voice.socketReady = false;

            socket.onopen = () => {
                if (generation !== this.voiceSocketGeneration) return;
                this.voice.socketReady = true;
                this.voiceSocketReconnectDelayMs = 1000;
                this.voiceTrace('socket-open', { generation, url: url.toString() }, 'SUCCESS');
                this.addLogEntry({ type: 'SUCCESS', msg: 'Browser voice socket connected', ts: new Date().toLocaleTimeString() });
            };

            socket.onmessage = (event) => {
                if (generation !== this.voiceSocketGeneration) return;
                let payload = null;
                try {
                    payload = JSON.parse(event.data);
                } catch (e) {
                    return;
                }
                if (payload && typeof payload === 'object' && String(payload.type || '').startsWith('voice_')) {
                    this.handleVoiceEvent(payload);
                }
            };

            socket.onclose = () => {
                if (generation !== this.voiceSocketGeneration) return;
                this.voice.socketReady = false;
                this.voice.socket = null;
                this.voiceTrace('socket-close', { generation, url: url.toString() }, 'WARN');
                if (!this.nativeSupports('voice')) {
                    const baseDelay = this.voiceSocketReconnectDelayMs || 1000;
                    const jitter = Math.floor(Math.random() * 500);
                    const delay = Math.min(baseDelay + jitter, 30000);
                    this.voiceSocketReconnectDelayMs = Math.min(baseDelay * 2, 30000);
                    this.voiceSocketReconnectTimer = setTimeout(() => {
                        if (generation === this.voiceSocketGeneration) {
                            this.connectBrowserVoiceSocket();
                        }
                    }, delay);
                }
            };

            socket.onerror = () => {
                if (generation !== this.voiceSocketGeneration) return;
                this.voice.socketReady = false;
                this.voiceTrace('socket-error', { generation, url: url.toString() }, 'WARN');
            };
        } catch (error) {
            this.addLogEntry({ type: 'ERROR', msg: `Не удалось подключить browser voice socket: ${error?.message || error}`, ts: new Date().toLocaleTimeString() });
        }
    }

    voiceRoomSummary() {
        const roomLabel = this.voice.roomType === 'channel'
            ? (this.currentChannel() ? `#${this.currentChannel().name}` : 'Голосовой канал')
            : this.voice.roomType === 'dm'
                ? `Звонок с ${this.voice.targetUser || this.voice.inviter || ''}`.trim()
                : 'Голос';
        return roomLabel;
    }

    resetVoiceState({ preserveInvite = false } = {}) {
        this.voiceTrace('reset-state', { preserveInvite, roomId: this.voice.roomId || '', roomType: this.voice.roomType || '', status: this.voice.status || '' });
        for (const entry of this.voice.peerConnections.values()) {
            if (entry.reconnectTimer) {
                clearTimeout(entry.reconnectTimer);
                entry.reconnectTimer = null;
            }
            if (entry.healthTimer) {
                clearTimeout(entry.healthTimer);
                entry.healthTimer = null;
            }
            if (entry.statsTimer) {
                clearInterval(entry.statsTimer);
                entry.statsTimer = null;
            }
            try { entry.pc?.close(); } catch (e) {}
        }
        this.voice.peerConnections.clear();
        for (const audio of this.voice.remoteAudios.values()) {
            try {
                audio.pause?.();
                if (audio.srcObject) {
                    audio.srcObject = null;
                }
                audio.remove?.();
            } catch (e) {}
        }
        this.voice.remoteAudios.clear();
        if (this.voice.localStream) {
            for (const track of this.voice.localStream.getTracks()) {
                try { track.stop(); } catch (e) {}
            }
        }
        this.voice.localStream = null;
        if (this.voice.audioContext) {
            try { this.voice.audioContext.close?.(); } catch (e) {}
        }
        this.voice.audioContext = null;
        this.voice.playbackUnlocked = false;
        this.voice.meterUiRenderedOnce = false;
        this.voice.meterLevels = { local: 0, remote: 0 };
        this.voice.meterLocal = null;
        this.voice.meterRemote.clear();
        if (this.voice.remotePlaybackNodes) {
            for (const node of this.voice.remotePlaybackNodes.values()) {
                try { node?.source?.disconnect?.(); } catch (e) {}
                try { node?.splitter?.disconnect?.(); } catch (e) {}
                try { node?.gain?.disconnect?.(); } catch (e) {}
            }
            this.voice.remotePlaybackNodes.clear();
        }
        this.stopVoiceMeterLoop();
        this.voice.traceLines = [];
        this.voice.roomId = '';
        this.voice.roomType = '';
        this.voice.serverId = '';
        this.voice.channelId = '';
        this.voice.targetUser = '';
        this.voice.inviter = '';
        this.voice.participants = [];
        this.voice.status = 'idle';
        this.voice.muted = false;
        this.voice.callTrack = null;
        if (!preserveInvite) {
            this.voice.incomingInvite = null;
            this.voice.outgoingInvite = null;
        }
        this.renderVoicePanel();
        this.renderMessages();
    }

    async ensureVoiceLocalStream() {
        if (this.voice.localStream) return this.voice.localStream;
        if (!this.voice.supported) {
            throw new Error('Голосовые звонки не поддерживаются в этом окружении');
        }
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        this.voice.localStream = stream;
        this.voice.muted = false;
        this.voiceTrace('local-stream-ready', {
            tracks: stream.getTracks().map(track => `${track.kind}:${track.readyState}:${track.enabled ? 'on' : 'off'}`),
        });
        this.ensureVoiceMeterLoop();
        return stream;
    }

    async unlockVoicePlayback() {
        if (this.voice.playbackUnlocked) return true;
        try {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (AudioCtx) {
                if (!this.voice.audioContext) {
                    this.voice.audioContext = new AudioCtx();
                }
            if (this.voice.audioContext.state === 'suspended') {
                await this.voice.audioContext.resume();
            }
            }
            this.voice.playbackUnlocked = true;
            this.ensureVoiceMeterLoop();
            this.voiceTrace('audio-unlock', {
                contextState: this.voice.audioContext?.state || 'none',
            }, 'SUCCESS');
            return true;
        } catch (error) {
            this.voiceTrace('audio-unlock-failed', { error: error?.message || String(error) }, 'WARN');
            return false;
        }
    }

    getVoicePeerEntry(peer) {
        const name = String(peer || '').trim();
        if (!name) return null;
        let entry = this.voice.peerConnections.get(name);
        if (!entry) {
            this.voiceTrace('peer-create', {
                peer: name,
                roomId: this.voice.roomId || '',
                roomType: this.voice.roomType || '',
                supported: this.voice.supported,
            });
            entry = {
                pc: new RTCPeerConnection(this.getVoiceRtcConfig()),
                localTracksAttached: false,
                offerSent: false,
                pendingIceCandidates: [],
                statsTimer: null,
                healthTimer: null,
                audioSender: null,
                generatedIceCandidates: 0,
                receivedIceCandidates: 0,
            };
            const rtcConfig = entry.pc.getConfiguration?.() || this.getVoiceRtcConfig();
            this.voiceTrace('rtc-config', {
                peer: name,
                policy: rtcConfig.iceTransportPolicy || 'all',
                servers: (rtcConfig.iceServers || []).map(server => ({
                    urls: server.urls,
                    username: server.username ? 'set' : '',
                })),
            });
            entry.statsTimer = setInterval(() => this.sampleVoicePeerStats(name), 1500);
            entry.pc.onicecandidate = (event) => {
                if (event.candidate) {
                    entry.generatedIceCandidates = (entry.generatedIceCandidates || 0) + 1;
                    this.voiceTrace('ice-candidate', {
                        peer: name,
                        index: entry.generatedIceCandidates,
                        mid: event.candidate.sdpMid,
                        line: event.candidate.sdpMLineIndex,
                        protocol: this.describeIceCandidate(event.candidate.candidate).protocol,
                        candidateType: this.describeIceCandidate(event.candidate.candidate).type,
                        address: this.describeIceCandidate(event.candidate.candidate).address,
                    });
                    this.renderVoicePanel();
                } else {
                    this.voiceTrace('ice-candidate-end', {
                        peer: name,
                        count: entry.generatedIceCandidates || 0,
                        state: entry.pc.iceGatheringState,
                    });
                }
                if (!event.candidate || !this.voice.roomId) return;
                this.sendVoiceEvent({
                    type: 'voice_signal',
                    roomId: this.voice.roomId,
                    roomType: this.voice.roomType,
                    serverId: this.voice.serverId,
                    channelId: this.voice.channelId,
                    to: name,
                    signal: {
                        type: 'ice',
                        candidate: {
                            candidate: event.candidate.candidate,
                            sdpMid: event.candidate.sdpMid,
                            sdpMLineIndex: event.candidate.sdpMLineIndex,
                            usernameFragment: event.candidate.usernameFragment || null,
                        },
                    },
                });
            };
            entry.pc.onicecandidateerror = (event) => {
                this.voiceTrace('ice-candidate-error', {
                    peer: name,
                    errorCode: event?.errorCode || '',
                    errorText: event?.errorText || '',
                    url: event?.url || '',
                    roomId: this.voice.roomId || '',
                }, 'WARN');
            };
            entry.pc.onicegatheringstatechange = () => {
                this.voiceTrace('ice-gathering', { peer: name, state: entry.pc.iceGatheringState, roomId: this.voice.roomId || '' });
            };
            entry.pc.oniceconnectionstatechange = () => {
                this.voiceTrace('ice-connection', { peer: name, state: entry.pc.iceConnectionState, roomId: this.voice.roomId || '' });
            };
            entry.pc.onsignalingstatechange = () => {
                this.voiceTrace('signaling-state', { peer: name, state: entry.pc.signalingState, roomId: this.voice.roomId || '' });
            };
            entry.pc.ontrack = (event) => {
                const stream = event.streams?.[0] || new MediaStream([event.track]);
                const track = event.track;
                if (track) {
                    track.onunmute = () => this.voiceTrace('remote-track-unmute', { peer: name, kind: track.kind, readyState: track.readyState }, 'INFO');
                    track.onmute = () => this.voiceTrace('remote-track-mute', { peer: name, kind: track.kind, readyState: track.readyState }, 'WARN');
                    track.onended = () => this.voiceTrace('remote-track-ended', { peer: name, kind: track.kind, readyState: track.readyState }, 'WARN');
                }
                this.voiceTrace('remote-track', {
                    peer: name,
                    kind: event.track?.kind || 'unknown',
                    readyState: event.track?.readyState || '',
                    streamId: stream.id || '',
                    transceiverDirection: event.transceiver?.direction || '',
                    transceiverCurrentDirection: event.transceiver?.currentDirection || '',
                    receiverTrack: event.receiver?.track ? `${event.receiver.track.kind}:${event.receiver.track.readyState}:${event.receiver.track.enabled ? 'on' : 'off'}` : '',
                    tracks: stream.getTracks().map(t => `${t.kind}:${t.readyState}:${t.enabled ? 'on' : 'off'}`),
                });
                this.attachRemoteVoiceStream(name, stream);
            };
            entry.pc.onconnectionstatechange = () => {
                const state = entry.pc.connectionState;
                if (entry.lastConnectionState !== state) {
                    this.voiceTrace('pc-state', { peer: name, from: entry.lastConnectionState || '', to: state, roomId: this.voice.roomId || '' });
                    entry.lastConnectionState = state;
                }
                if (state === 'connected' || state === 'completed') {
                    if (entry.reconnectTimer) {
                        clearTimeout(entry.reconnectTimer);
                        entry.reconnectTimer = null;
                    }
                    if (entry.healthTimer) {
                        clearTimeout(entry.healthTimer);
                        entry.healthTimer = null;
                    }
                    if (!entry.statsTimer) {
                        entry.statsTimer = setInterval(() => this.sampleVoicePeerStats(name), 3000);
                    }
                    this.voice.status = 'connected';
                    if (this.voice.callTrack && !this.voice.callTrack.connectedAt) {
                        this.voice.callTrack.connectedAt = Date.now();
                        this.voice.callTrack.outcome = 'connected';
                    }
                    this.renderVoicePanel();
                    return;
                }
                if (state === 'connecting' || state === 'checking') {
                    if (entry.reconnectTimer) {
                        clearTimeout(entry.reconnectTimer);
                        entry.reconnectTimer = null;
                    }
                    if (entry.healthTimer) {
                        clearTimeout(entry.healthTimer);
                        entry.healthTimer = null;
                    }
                    if (this.voice.status !== 'connected') {
                        this.voice.status = 'connecting';
                        this.renderVoicePanel();
                    }
                    const isDmCall = this.voice.roomType === 'dm';
                    const shouldWatchHealth = isDmCall && String(this.voice.callTrack?.direction || '').trim() === 'outgoing';
                    if (shouldWatchHealth && !entry.healthTimer) {
                        entry.healthTimer = setTimeout(async () => {
                            entry.healthTimer = null;
                            const currentState = entry.pc?.connectionState || '';
                            const currentIce = entry.pc?.iceConnectionState || '';
                            const stats = entry.lastStats || {};
                            const hasTraffic = Number(stats.inBytes || 0) > 0 || Number(stats.outBytes || 0) > 0;
                            if (!this.voice.roomId) return;
                            if (['connected', 'completed'].includes(currentState)) return;
                            if (hasTraffic) return;
                            if (!['new', 'checking', 'connecting'].includes(currentState) && !['new', 'checking'].includes(currentIce)) return;
                            this.voiceTrace('health-restart', {
                                peer: name,
                                roomId: this.voice.roomId || '',
                                state: currentState,
                                ice: currentIce,
                                hasTraffic,
                            }, 'WARN');
                            try {
                                await this.restartVoicePeer(name);
                            } catch (error) {
                                this.addLogEntry({
                                    type: 'WARN',
                                    msg: error?.message || `Не удалось выполнить ICE restart для ${name}`,
                                    ts: new Date().toLocaleTimeString(),
                                });
                            }
                        }, 8000);
                    }
                    return;
                }
                if (state === 'disconnected' || state === 'failed') {
                    this.addLogEntry({ type: 'WARN', msg: `Voice peer ${name} connection ${state}`, ts: new Date().toLocaleTimeString() });
                    if (entry.reconnectTimer) {
                        clearTimeout(entry.reconnectTimer);
                    }
                    if (entry.healthTimer) {
                        clearTimeout(entry.healthTimer);
                        entry.healthTimer = null;
                    }
                    if (entry.statsTimer) {
                        clearInterval(entry.statsTimer);
                        entry.statsTimer = null;
                    }
                    const isDmCall = this.voice.roomType === 'dm';
                    const allowAutoRestart = !isDmCall || String(this.voice.callTrack?.direction || '').trim() === 'outgoing';
                    if (allowAutoRestart) {
                        const delay = state === 'failed' ? 8000 : 10000;
                        entry.reconnectTimer = setTimeout(async () => {
                            entry.reconnectTimer = null;
                            if (!this.voice.roomId) return;
                            if (!['disconnected', 'failed'].includes(entry.pc.connectionState)) return;
                            try {
                                await this.restartVoicePeer(name);
                            } catch (error) {
                                this.addLogEntry({ type: 'WARN', msg: error?.message || `Не удалось восстановить голосовую связь с ${name}`, ts: new Date().toLocaleTimeString() });
                            }
                        }, delay);
                    }
                    if (!isDmCall && this.voice.status !== 'connected') {
                        this.voice.status = 'connecting';
                        this.renderVoicePanel();
                    }
                }
            };
            this.voice.peerConnections.set(name, entry);
        }
        return entry;
    }

    async flushPendingVoiceIceCandidates(entry, peer) {
        if (!entry || !entry.pendingIceCandidates?.length) return;
        const pending = entry.pendingIceCandidates.splice(0, entry.pendingIceCandidates.length);
        this.voiceTrace('ice-flush', { peer, count: pending.length, roomId: this.voice.roomId || '' });
        for (const candidate of pending) {
            try {
                await entry.pc.addIceCandidate(candidate);
            } catch (e) {
                console.warn(`Failed to flush ICE candidate for ${peer}`, e);
            }
        }
    }

    async sampleVoicePeerStats(peer) {
        const name = String(peer || '').trim();
        if (!name) return;
        const entry = this.voice.peerConnections.get(name);
        if (!entry?.pc) return;
        try {
            const stats = await entry.pc.getStats();
            const summary = {
                peer: name,
                connection: entry.pc.connectionState,
                ice: entry.pc.iceConnectionState,
                signaling: entry.pc.signalingState,
                localCandidateCount: entry.generatedIceCandidates || 0,
                remoteCandidateCount: entry.receivedIceCandidates || 0,
            };
            const candidatesById = {};
            stats.forEach(report => {
                if (report.type === 'outbound-rtp' && report.kind === 'audio') {
                    summary.outBytes = report.bytesSent;
                    summary.outPackets = report.packetsSent;
                    summary.outAudioLevel = report.audioLevel;
                    summary.outHeaderBytes = report.headerBytesSent;
                }
                if (report.type === 'inbound-rtp' && report.kind === 'audio') {
                    summary.inBytes = report.bytesReceived;
                    summary.inPackets = report.packetsReceived;
                    summary.inAudioLevel = report.audioLevel;
                    summary.inJitter = report.jitter;
                    summary.inHeaderBytes = report.headerBytesReceived;
                }
                if (report.type === 'track' && report.kind === 'audio') {
                    summary.trackAudioLevel = report.audioLevel;
                    summary.trackMuted = report.muted;
                    summary.trackEnded = report.ended;
                }
                if (report.type === 'candidate-pair' && report.state === 'succeeded' && report.nominated) {
                    summary.candidatePair = {
                        local: report.localCandidateId || '',
                        remote: report.remoteCandidateId || '',
                        currentRoundTripTime: report.currentRoundTripTime,
                        availableOutgoingBitrate: report.availableOutgoingBitrate,
                        bytesSent: report.bytesSent,
                        bytesReceived: report.bytesReceived,
                    };
                }
                if (report.type === 'local-candidate' || report.type === 'remote-candidate') {
                    const candidate = {
                        candidateType: report.candidateType,
                        ip: report.ip || report.address,
                        port: report.port,
                        protocol: report.protocol,
                        priority: report.priority,
                    };
                    candidatesById[report.id] = candidate;
                    summary[`${report.type.replace('-', '')}_${report.id || 'unknown'}`] = candidate;
                }
            });
            if (summary.candidatePair) {
                const local = candidatesById[summary.candidatePair.local];
                const remote = candidatesById[summary.candidatePair.remote];
                summary.candidatePair.localLabel = local ? `${local.candidateType}/${local.protocol}/${local.ip || ''}:${local.port || ''}` : summary.candidatePair.local;
                summary.candidatePair.remoteLabel = remote ? `${remote.candidateType}/${remote.protocol}/${remote.ip || ''}:${remote.port || ''}` : summary.candidatePair.remote;
            }
            entry.lastStats = summary;
            entry.lastStatsAt = Date.now();
            this.voiceTrace('rtc-stats', summary);
        } catch (error) {
            this.voiceTrace('rtc-stats-error', { peer: name, error: error?.message || String(error) }, 'WARN');
        }
    }

    ensureVoiceAudioContext() {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return null;
        if (!this.voice.audioContext) {
            this.voice.audioContext = new AudioCtx();
        }
        return this.voice.audioContext;
    }

    ensureVoiceMeterLoop() {
        if (this.voice.meterRaf) return;
        const tick = async () => {
            if (!this.voice.roomId && !this.voice.localStream && this.voice.peerConnections.size === 0) {
                this.voice.meterRaf = 0;
                return;
            }
            try {
                await this.updateVoiceMeters();
            } catch (error) {
                this.voiceTrace('meter-update-error', { error: error?.message || String(error) }, 'WARN');
            }
            this.voice.meterRaf = requestAnimationFrame(tick);
        };
        this.voice.meterRaf = requestAnimationFrame(tick);
    }

    stopVoiceMeterLoop() {
        if (this.voice.meterRaf) {
            cancelAnimationFrame(this.voice.meterRaf);
            this.voice.meterRaf = 0;
        }
    }

    computeAnalyserLevel(analyser) {
        if (!analyser) return 0;
        const bufferLength = analyser.fftSize;
        const data = new Uint8Array(bufferLength);
        analyser.getByteTimeDomainData(data);
        let sum = 0;
        for (const value of data) {
            const normalized = (value - 128) / 128;
            sum += normalized * normalized;
        }
        const rms = Math.sqrt(sum / data.length);
        return Math.max(0, Math.min(1, rms * 2.8));
    }

    ensureMeterEntry(key, stream) {
        const ctx = this.ensureVoiceAudioContext();
        if (!ctx || !stream) return null;
        if (key === 'local') {
            const currentId = stream.id || '';
            if (!this.voice.meterLocal || this.voice.meterLocal.streamId !== currentId) {
                try {
                    if (this.voice.meterLocal?.source) this.voice.meterLocal.source.disconnect?.();
                    if (this.voice.meterLocal?.analyser) this.voice.meterLocal.analyser.disconnect?.();
                } catch (e) {}
                const source = ctx.createMediaStreamSource(stream);
                const analyser = ctx.createAnalyser();
                analyser.fftSize = 512;
                analyser.smoothingTimeConstant = 0.8;
                source.connect(analyser);
                this.voice.meterLocal = {
                    streamId: currentId,
                    source,
                    analyser,
                    data: new Uint8Array(analyser.fftSize),
                };
                this.voiceTrace('meter-local-ready', { streamId: currentId, tracks: stream.getTracks().length });
            }
            return this.voice.meterLocal;
        }

        const peer = String(key || '').trim();
        if (!peer) return null;
        const currentId = stream.id || '';
        const existing = this.voice.meterRemote.get(peer);
        if (!existing || existing.streamId !== currentId) {
            try {
                if (existing?.source) existing.source.disconnect?.();
                if (existing?.analyser) existing.analyser.disconnect?.();
            } catch (e) {}
            const source = ctx.createMediaStreamSource(stream);
            const analyser = ctx.createAnalyser();
            analyser.fftSize = 512;
            analyser.smoothingTimeConstant = 0.8;
            source.connect(analyser);
            const next = {
                streamId: currentId,
                source,
                analyser,
                data: new Uint8Array(analyser.fftSize),
            };
            this.voice.meterRemote.set(peer, next);
            this.voiceTrace('meter-remote-ready', { peer, streamId: currentId, tracks: stream.getTracks().length });
            return next;
        }
        return existing;
    }

    ensureRemotePlaybackNode(peer, stream) {
        const ctx = this.ensureVoiceAudioContext();
        const name = String(peer || '').trim();
        if (!ctx || !name || !stream) return null;
        const currentId = stream.id || '';
        const existing = this.voice.remotePlaybackNodes?.get(name);
        if (existing && existing.streamId === currentId) return existing;
        try {
            if (existing?.source) existing.source.disconnect?.();
            if (existing?.splitter) existing.splitter.disconnect?.();
            if (existing?.gain) existing.gain.disconnect?.();
        } catch (e) {}
        try {
            const source = ctx.createMediaStreamSource(stream);
            const splitter = ctx.createGain();
            const gain = ctx.createGain();
            splitter.gain.value = 1;
            gain.gain.value = 1;
            source.connect(splitter);
            source.connect(gain);
            splitter.connect(ctx.destination);
            const next = {
                streamId: currentId,
                source,
                splitter,
                gain,
            };
            this.voice.remotePlaybackNodes.set(name, next);
            this.voiceTrace('remote-webaudio-ready', {
                peer: name,
                streamId: currentId,
                contextState: ctx.state || '',
                tracks: stream.getTracks().map(t => `${t.kind}:${t.readyState}:${t.enabled ? 'on' : 'off'}`),
            }, 'SUCCESS');
            return next;
        } catch (error) {
            this.voiceTrace('remote-webaudio-error', { peer: name, error: error?.message || String(error) }, 'ERROR');
            return null;
        }
    }

    updateVoiceMeterDom(kind, percent) {
        const fill = document.getElementById(kind === 'local' ? 'voiceMicLevelFill' : 'voiceServerLevelFill');
        const text = document.getElementById(kind === 'local' ? 'voiceMicLevelText' : 'voiceServerLevelText');
        const row = document.getElementById(kind === 'local' ? 'voiceMicMeter' : 'voiceServerMeter');
        const next = Math.max(0, Math.min(100, Math.round(percent || 0)));
        if (fill) {
            fill.style.width = `${next}%`;
        }
        if (text) {
            text.textContent = `${next}%`;
        }
        if (row) {
            row.dataset.level = String(next);
        }
    }

    async updateVoiceMeters() {
        const localMeter = this.voice.localStream ? this.ensureMeterEntry('local', this.voice.localStream) : null;
        const remoteStreams = [];
        for (const [peer, audio] of this.voice.remoteAudios.entries()) {
            const stream = audio?.srcObject;
            if (stream instanceof MediaStream) {
                remoteStreams.push({ peer, stream });
            }
        }
        const remoteMeters = remoteStreams
            .map(({ peer, stream }) => ({ peer, meter: this.ensureMeterEntry(peer, stream) }))
            .filter(item => item.meter);

        let localLevel = 0;
        if (localMeter?.analyser) {
            localLevel = this.computeAnalyserLevel(localMeter.analyser);
        }

        let remoteLevel = 0;
        for (const item of remoteMeters) {
            const level = this.computeAnalyserLevel(item.meter.analyser);
            remoteLevel = Math.max(remoteLevel, level);
        }

        const nextLocal = Math.round(localLevel * 100);
        const nextRemote = Math.round(remoteLevel * 100);
        const changed = nextLocal !== this.voice.meterLevels.local || nextRemote !== this.voice.meterLevels.remote;
        this.voice.meterLevels = { local: nextLocal, remote: nextRemote };
        if (changed || !this.voice.meterUiRenderedOnce) {
            this.updateVoiceMeterDom('local', nextLocal);
            this.updateVoiceMeterDom('remote', nextRemote);
            this.voice.meterUiRenderedOnce = true;
        }
    }

    async attachLocalVoiceTracks(peer) {
        const entry = this.getVoicePeerEntry(peer);
        if (!entry || !this.voice.localStream || entry.localTracksAttached) return;
        const tracks = this.voice.localStream.getTracks();
        this.voiceTrace('attach-local-tracks', { peer, tracks: tracks.length, roomId: this.voice.roomId || '' });
        const audioTracks = this.voice.localStream.getAudioTracks();
        if (entry.audioSender && audioTracks.length) {
            const track = audioTracks[0];
            try {
                if (entry.audioSender.track !== track) {
                    await entry.audioSender.replaceTrack(track);
                }
                if (typeof entry.audioSender.setStreams === 'function') {
                    try {
                        entry.audioSender.setStreams(this.voice.localStream);
                    } catch (setStreamsError) {
                        this.voiceTrace('set-streams-error', { peer, error: setStreamsError?.message || String(setStreamsError) }, 'WARN');
                    }
                }
                this.voiceTrace('attach-local-sender', {
                    peer,
                    track: `${track.kind}:${track.readyState}:${track.enabled ? 'on' : 'off'}`,
                    senderTrack: entry.audioSender.track ? `${entry.audioSender.track.kind}:${entry.audioSender.track.readyState}:${entry.audioSender.track.enabled ? 'on' : 'off'}` : 'none',
                });
            } catch (error) {
                this.voiceTrace('attach-local-sender-error', { peer, error: error?.message || String(error) }, 'WARN');
            }
        } else {
            for (const track of tracks) {
                const sender = entry.pc.addTrack(track, this.voice.localStream);
                entry.audioSender = sender;
                this.voiceTrace('attach-local-track-added', {
                    peer,
                    track: `${track.kind}:${track.readyState}:${track.enabled ? 'on' : 'off'}`,
                    senderTrack: sender?.track ? `${sender.track.kind}:${sender.track.readyState}:${sender.track.enabled ? 'on' : 'off'}` : 'none',
                });
            }
        }
        entry.localTracksAttached = true;
        this.ensureMeterEntry('local', this.voice.localStream);
        this.ensureVoiceMeterLoop();
    }

    attachRemoteVoiceStream(peer, stream) {
        const name = String(peer || '').trim();
        if (!name || !stream) return;
        let audio = this.voice.remoteAudios.get(name);
        if (!audio) {
            audio = document.createElement('audio');
            audio.autoplay = true;
            audio.playsInline = true;
            audio.hidden = true;
            audio.preload = 'auto';
            audio.muted = true;
            audio.defaultMuted = true;
            audio.volume = 0;
            audio.dataset.peer = name;
            audio.addEventListener('play', () => this.voiceTrace('remote-audio-play', { peer: name, muted: audio.muted, volume: audio.volume }, 'INFO'));
            audio.addEventListener('playing', () => this.voiceTrace('remote-audio-playing', { peer: name, muted: audio.muted, volume: audio.volume }, 'SUCCESS'));
            audio.addEventListener('pause', () => this.voiceTrace('remote-audio-pause', { peer: name }, 'WARN'));
            audio.addEventListener('ended', () => this.voiceTrace('remote-audio-ended', { peer: name }, 'WARN'));
            audio.addEventListener('error', () => this.voiceTrace('remote-audio-error', { peer: name, error: audio.error?.message || audio.error?.code || 'unknown' }, 'ERROR'));
            document.body.appendChild(audio);
            this.voice.remoteAudios.set(name, audio);
        }
        audio.srcObject = stream;
        this.ensureMeterEntry(name, stream);
        this.ensureRemotePlaybackNode(name, stream);
        this.ensureVoiceMeterLoop();
        this.voiceTrace('remote-audio-attach', {
            peer: name,
            streamId: stream.id || '',
            tracks: stream.getTracks().map(t => `${t.kind}:${t.readyState}:${t.enabled ? 'on' : 'off'}`),
            readyState: audio.readyState,
            paused: audio.paused,
            muted: audio.muted,
        });
        const attemptPlay = () => audio.play?.().catch(error => this.voiceTrace('remote-audio-play-failed', { peer: name, error: error?.message || String(error) }, 'WARN'));
        attemptPlay();
        requestAnimationFrame(() => attemptPlay());
        setTimeout(attemptPlay, 250);
    }

    closeVoicePeer(peer) {
        const name = String(peer || '').trim();
        if (!name) return;
        const entry = this.voice.peerConnections.get(name);
        if (entry) {
            this.voiceTrace('peer-close', { peer: name, roomId: this.voice.roomId || '' });
            if (entry.reconnectTimer) {
                clearTimeout(entry.reconnectTimer);
                entry.reconnectTimer = null;
            }
            if (entry.healthTimer) {
                clearTimeout(entry.healthTimer);
                entry.healthTimer = null;
            }
            if (entry.statsTimer) {
                clearInterval(entry.statsTimer);
                entry.statsTimer = null;
            }
            entry.audioSender = null;
            try { entry.pc.close(); } catch (e) {}
            this.voice.peerConnections.delete(name);
        }
        const audio = this.voice.remoteAudios.get(name);
        if (audio) {
            try {
                audio.pause?.();
                audio.srcObject = null;
                audio.remove?.();
            } catch (e) {}
            this.voice.remoteAudios.delete(name);
        }
        const playbackNode = this.voice.remotePlaybackNodes?.get(name);
        if (playbackNode) {
            try { playbackNode.source?.disconnect?.(); } catch (e) {}
            try { playbackNode.splitter?.disconnect?.(); } catch (e) {}
            try { playbackNode.gain?.disconnect?.(); } catch (e) {}
            this.voice.remotePlaybackNodes.delete(name);
        }
        if (this.voice.meterRemote.has(name)) {
            const meter = this.voice.meterRemote.get(name);
            try {
                meter?.source?.disconnect?.();
                meter?.analyser?.disconnect?.();
            } catch (e) {}
            this.voice.meterRemote.delete(name);
        }
        this.voice.meterLevels.remote = 0;
    }

    async sendVoiceOffer(peer) {
        const entry = this.getVoicePeerEntry(peer);
        if (!entry || !this.voice.localStream) return;
        if (entry.offerSent) return;
        this.voiceTrace('send-offer', { peer, roomId: this.voice.roomId || '', roomType: this.voice.roomType || '' });
        await this.attachLocalVoiceTracks(peer);
        const offer = await entry.pc.createOffer();
        await entry.pc.setLocalDescription(offer);
        entry.offerSent = true;
        this.voiceTrace('offer-created', {
            peer,
            roomId: this.voice.roomId || '',
            sdpType: entry.pc.localDescription?.type || 'offer',
            sdpLength: entry.pc.localDescription?.sdp?.length || 0,
        });
        this.sendVoiceEvent({
            type: 'voice_signal',
            roomId: this.voice.roomId,
            roomType: this.voice.roomType,
            serverId: this.voice.serverId,
            channelId: this.voice.channelId,
            to: peer,
            signal: {
                type: 'offer',
                sdp: {
                    type: entry.pc.localDescription?.type || 'offer',
                    sdp: entry.pc.localDescription?.sdp || '',
                },
            },
        });
    }

    async restartVoicePeer(peer) {
        const name = String(peer || '').trim();
        if (!name || !this.voice.roomId) return;
        const entry = this.getVoicePeerEntry(name);
        if (!entry || !this.voice.localStream) return;
        if (entry.healthTimer) {
            clearTimeout(entry.healthTimer);
            entry.healthTimer = null;
        }
        this.voiceTrace('restart-offer', { peer: name, roomId: this.voice.roomId || '' });
        await this.attachLocalVoiceTracks(name);
        const offer = await entry.pc.createOffer({ iceRestart: true });
        await entry.pc.setLocalDescription(offer);
        entry.offerSent = true;
        this.voiceTrace('offer-restart-created', {
            peer: name,
            roomId: this.voice.roomId || '',
            sdpType: entry.pc.localDescription?.type || 'offer',
            sdpLength: entry.pc.localDescription?.sdp?.length || 0,
        });
        this.sendVoiceEvent({
            type: 'voice_signal',
            roomId: this.voice.roomId,
            roomType: this.voice.roomType,
            serverId: this.voice.serverId,
            channelId: this.voice.channelId,
            to: name,
            signal: {
                type: 'offer',
                sdp: {
                    type: entry.pc.localDescription?.type || 'offer',
                    sdp: entry.pc.localDescription?.sdp || '',
                },
            },
        });
    }

    async syncVoicePeers() {
        const participants = Array.isArray(this.voice.participants) ? this.voice.participants : [];
        const peers = participants
            .map(name => String(name || '').trim())
            .filter(Boolean)
            .filter(name => name !== this.myName());
        const nextPeers = new Set(peers);
        this.voiceTrace('sync-peers', {
            roomId: this.voice.roomId || '',
            roomType: this.voice.roomType || '',
            status: this.voice.status || '',
            me: this.myName(),
            peers,
            localStream: !!this.voice.localStream,
        });

        for (const peer of this.voice.peerConnections.keys()) {
            if (!nextPeers.has(peer)) {
                this.closeVoicePeer(peer);
            }
        }

        for (const peer of peers) {
            const entry = this.getVoicePeerEntry(peer);
            await this.attachLocalVoiceTracks(peer);
            if (this.shouldInitiateVoiceOffer(peer) && this.voice.localStream && !entry.offerSent) {
                try {
                    await this.sendVoiceOffer(peer);
                } catch (e) {
                    this.addLogEntry({ type: 'ERROR', msg: `Не удалось начать голосовой обмен с ${peer}`, ts: new Date().toLocaleTimeString() });
                }
            }
        }
        this.renderVoicePanel();
    }

    async joinVoiceChannel({ serverId = null, channelId = null } = {}) {
        const server = this.currentServer();
        const channel = server && channelId ? (server.channels || []).find(ch => ch.id === channelId) : this.currentChannel();
        const sid = String(serverId || server?.id || '').trim();
        const cid = String(channelId || channel?.id || '').trim();
        if (!sid || !cid) return;
        if (!this.isVoiceChannel(channel)) {
            return;
        }
        const roomId = this.voiceRoomKeyForChannel(sid, cid);
        this.voice.roomId = roomId;
        this.voice.roomType = 'channel';
        this.voice.serverId = sid;
        this.voice.channelId = cid;
        this.voice.status = 'connecting';
        this.voice.participants = [];
        this.sendVoiceEvent({
            type: 'voice_join',
            roomId,
            roomType: 'channel',
            serverId: sid,
            channelId: cid,
        });
        this.renderVoicePanel();
    }

    async leaveVoiceRoom({ announce = true, outcome = 'completed' } = {}) {
        const roomId = String(this.voice.roomId || '').trim();
        this.voiceTrace('leave-room', {
            roomId,
            roomType: this.voice.roomType || '',
            announce,
            outcome,
            participants: Array.isArray(this.voice.participants) ? this.voice.participants : [],
        });
        if (this.voice.roomType === 'dm' && roomId && this.voice.callTrack && !this.voice.callTrack.recorded) {
            this.recordVoiceCallHistory({ outcome, endedAt: Date.now() });
        }
        if (announce && roomId) {
            this.sendVoiceEvent({
                type: 'voice_leave',
                roomId,
                roomType: this.voice.roomType,
                serverId: this.voice.serverId,
                channelId: this.voice.channelId,
            });
        }
        this.resetVoiceState();
    }

    async startDirectCall(peer) {
        const target = String(peer || '').trim();
        if (!target) return;
        const me = String(this.myName() || '').trim();
        const roomId = this.makeDmCallRoomId(target);
        if (!roomId) return;
        this.voiceTrace('start-dm-call', { target, me, roomId });
        await this.unlockVoicePlayback();
        this.voice.callTrack = {
            roomId,
            peer: target,
            roomType: 'dm',
            direction: 'outgoing',
            startedAt: Date.now(),
            connectedAt: 0,
            endedAt: 0,
            outcome: 'calling',
            recorded: false,
        };
        this.voice.outgoingInvite = {
            roomId,
            target,
        };
        this.voice.roomId = roomId;
        this.voice.roomType = 'dm';
        this.voice.targetUser = target;
        this.voice.inviter = me;
        this.voice.participants = [me, target].filter(Boolean);
        this.voice.status = 'calling';
        this.sendVoiceEvent({
            type: 'voice_call_invite',
            roomId,
            roomType: 'dm',
            target,
        });
        this.renderVoicePanel();
        try {
            await this.ensureVoiceLocalStream();
            await this.syncVoicePeers();
        } catch (error) {
            this.addLogEntry({
                type: 'WARN',
                msg: error?.message || 'Не удалось подготовить микрофон для звонка',
                ts: new Date().toLocaleTimeString(),
            });
        }
    }

    async acceptIncomingCall() {
        const invite = this.voice.incomingInvite;
        if (!invite?.roomId || !invite?.from) return;
        const me = String(this.myName() || '').trim();
        this.voiceTrace('accept-incoming', { roomId: invite.roomId, from: invite.from, me });
        await this.unlockVoicePlayback();
        this.voice.roomId = String(invite.roomId || '').trim();
        this.voice.roomType = 'dm';
        this.voice.targetUser = String(invite.from || '').trim();
        this.voice.inviter = String(invite.from || '').trim();
        this.voice.participants = [me, String(invite.from || '').trim()].filter(Boolean);
        this.voice.status = 'connecting';
        this.voice.callTrack = {
            roomId: invite.roomId,
            peer: invite.from,
            roomType: 'dm',
            direction: 'incoming',
            startedAt: Date.now(),
            connectedAt: 0,
            endedAt: 0,
            outcome: 'connecting',
            recorded: false,
        };
        this.addLogEntry({
            type: 'INFO',
            msg: `Принимаем звонок ${this.voice.roomId} от ${invite.from}`,
            ts: new Date().toLocaleTimeString(),
        });
        this.renderVoicePanel();
        this.sendVoiceEvent({
            type: 'voice_call_accept',
            roomId: invite.roomId,
            inviter: invite.from,
        });
        this.renderVoicePanel();
        try {
            await this.ensureVoiceLocalStream();
            await this.syncVoicePeers();
        } catch (error) {
            this.addLogEntry({
                type: 'WARN',
                msg: error?.message || 'Не удалось подготовить микрофон для ответа на звонок',
                ts: new Date().toLocaleTimeString(),
            });
        }
    }

    async rejectIncomingCall() {
        const invite = this.voice.incomingInvite;
        if (!invite?.roomId || !invite?.from) return;
        this.voiceTrace('reject-incoming', { roomId: invite.roomId, from: invite.from });
        this.sendVoiceEvent({
            type: 'voice_call_reject',
            roomId: invite.roomId,
            inviter: invite.from,
        });
        this.recordVoiceCallHistory({ outcome: 'rejected', endedAt: Date.now() });
        this.resetVoiceState({ preserveInvite: false });
    }

    toggleVoiceMute() {
        const stream = this.voice.localStream;
        if (!stream) return;
        const nextMuted = !this.voice.muted;
        for (const track of stream.getAudioTracks()) {
            track.enabled = !nextMuted;
        }
        this.voice.muted = nextMuted;
        this.renderVoicePanel();
    }

    recordVoiceCallHistory({ outcome = 'completed', endedAt = Date.now() } = {}) {
        const call = this.voice.callTrack;
        if (!call || call.recorded || call.roomType === 'channel') return;
        const peer = String(call.peer || this.voice.targetUser || this.voice.inviter || '').trim();
        if (!peer) return;
        const direction = String(call.direction || '').trim() || 'outgoing';
        const startMs = Number(call.connectedAt || call.startedAt || endedAt) || endedAt;
        const endMs = Number(endedAt || Date.now()) || Date.now();
        const durationMs = Math.max(0, endMs - startMs);
        const message = {
            id: `call-${call.roomId || peer}-${endMs}`,
            kind: 'call',
            sender: direction === 'outgoing' ? this.myName() : peer,
            receiver: direction === 'outgoing' ? peer : this.myName(),
            text: '',
            attachments: [],
            timestamp: new Date(endMs).toISOString(),
            call: {
                roomId: call.roomId || '',
                peer,
                direction,
                outcome,
                startedAt: new Date(startMs).toISOString(),
                connectedAt: call.connectedAt ? new Date(call.connectedAt).toISOString() : '',
                endedAt: new Date(endMs).toISOString(),
                durationMs,
            },
        };
        const convo = peer;
        this.initChat(convo);
        const arr = this.S.chats[convo];
        const key = this.messageRenderKey(message);
        const exists = arr.some(m => this.messageRenderKey(m) === key);
        if (!exists) {
            arr.push(message);
            arr.sort((a, b) => new Date(a.timestamp || 0) - new Date(b.timestamp || 0));
        }
        call.recorded = true;
        this.voice.callTrack = null;
        this.renderContacts();
        if (this.S.navMode === 'dm' && this.S.current === convo) {
            this.renderMessages();
        }
    }

    async handleVoiceSignal(signal = {}) {
        const roomId = String(signal.roomId || '').trim();
        const from = String(signal.from || signal.sender || '').trim();
        const signalPayload = signal.signal || signal.payload || signal;
        if (!roomId || !from || !signalPayload) return;
        this.voiceTrace('signal-recv', {
            roomId,
            from,
            to: signal.to || '',
            signalType: signalPayload.type || '',
            roomType: signal.roomType || this.voice.roomType || '',
        });

        if (signalPayload.type === 'offer') {
            this.voice.roomId = roomId;
            this.voice.roomType = signal.roomType || this.voice.roomType || 'dm';
            this.voice.serverId = signal.serverId || this.voice.serverId || '';
            this.voice.channelId = signal.channelId || this.voice.channelId || '';
            this.voice.targetUser = signal.target || this.voice.targetUser || '';
            this.voice.inviter = signal.from || this.voice.inviter || '';
            this.voice.status = 'connecting';
            const entry = this.getVoicePeerEntry(from);
            try {
                await this.ensureVoiceLocalStream();
            } catch (error) {
                this.addLogEntry({ type: 'WARN', msg: error?.message || 'Не удалось получить доступ к микрофону', ts: new Date().toLocaleTimeString() });
            }
            await this.attachLocalVoiceTracks(from);
            this.voiceTrace('signal-offer-apply', { roomId, from, localStream: !!this.voice.localStream, peer: from });
            await entry.pc.setRemoteDescription(signalPayload.sdp);
            await this.flushPendingVoiceIceCandidates(entry, from);
            const answer = await entry.pc.createAnswer();
            await entry.pc.setLocalDescription(answer);
            this.voiceTrace('signal-answer-send', {
                roomId,
                from,
                peer: from,
                localDesc: entry.pc.localDescription?.type || 'answer',
                sdpLength: entry.pc.localDescription?.sdp?.length || 0,
            });
            this.sendVoiceEvent({
                type: 'voice_signal',
                roomId,
                roomType: this.voice.roomType,
                serverId: this.voice.serverId,
                channelId: this.voice.channelId,
                to: from,
                signal: {
                    type: 'answer',
                    sdp: {
                        type: entry.pc.localDescription?.type || 'answer',
                        sdp: entry.pc.localDescription?.sdp || '',
                    },
                },
            });
            this.voice.participants = Array.from(new Set([this.myName(), from].concat(this.voice.participants || [])));
            this.renderVoicePanel();
            return;
        }

        const entry = this.getVoicePeerEntry(from);
        if (signalPayload.type === 'answer') {
            this.voiceTrace('signal-answer-apply', {
                roomId,
                from,
                peer: from,
                remoteDesc: !!signalPayload.sdp,
                sdpType: signalPayload.sdp?.type || '',
                sdpLength: signalPayload.sdp?.sdp?.length || 0,
            });
            await entry.pc.setRemoteDescription(signalPayload.sdp);
            await this.flushPendingVoiceIceCandidates(entry, from);
            this.voice.status = 'connected';
            this.renderVoicePanel();
            return;
        }

        if (signalPayload.type === 'ice' && signalPayload.candidate) {
            try {
                entry.receivedIceCandidates = (entry.receivedIceCandidates || 0) + 1;
                const candidateInfo = this.describeIceCandidate(signalPayload.candidate.candidate || '');
                this.voiceTrace('signal-ice-recv', {
                    roomId,
                    from,
                    peer: from,
                    count: entry.receivedIceCandidates,
                    candidateType: candidateInfo.type,
                    protocol: candidateInfo.protocol,
                    address: candidateInfo.address,
                });
                if (entry.pc.remoteDescription) {
                    this.voiceTrace('signal-ice-apply', { roomId, from, peer: from, queued: false });
                    await entry.pc.addIceCandidate(signalPayload.candidate);
                } else {
                    entry.pendingIceCandidates = entry.pendingIceCandidates || [];
                    entry.pendingIceCandidates.push(signalPayload.candidate);
                    this.voiceTrace('signal-ice-queue', { roomId, from, peer: from, queued: true, queueSize: entry.pendingIceCandidates.length });
                }
            } catch (e) {
                console.warn('Failed to add ICE candidate', e);
                this.voiceTrace('signal-ice-error', { roomId, from, peer: from, error: e?.message || String(e) }, 'WARN');
            }
        }
    }

    async handleVoiceEvent(payload = {}) {
        const eventType = String(payload?.type || '').trim();
        if (!eventType) return;
        this.voiceTrace('event-recv', {
            eventType,
            roomId: payload.roomId || '',
            roomType: payload.roomType || '',
            from: payload.from || '',
            target: payload.target || '',
        });

        if (eventType === 'voice_call_invite') {
            const from = String(payload.from || '').trim();
            const roomId = String(payload.roomId || '').trim();
            this.voice.incomingInvite = {
                roomId,
                from,
                roomType: 'dm',
            };
            this.voice.inviter = from;
            this.voice.callTrack = {
                roomId,
                peer: from,
                roomType: 'dm',
                direction: 'incoming',
                startedAt: Date.now(),
                connectedAt: 0,
                endedAt: 0,
                outcome: 'incoming',
                recorded: false,
            };
            this.voice.outgoingInvite = null;
            this.voice.status = 'incoming';
            this.voiceTrace('incoming-invite', { roomId, from });
            this.renderVoicePanel();
            return;
        }

        if (eventType === 'voice_call_outgoing') {
            this.voice.outgoingInvite = {
                roomId: String(payload.roomId || '').trim(),
                target: String(payload.target || '').trim(),
            };
            this.voice.targetUser = String(payload.target || '').trim();
            this.voice.status = 'calling';
            this.voiceTrace('outgoing-ring', { roomId: this.voice.outgoingInvite.roomId, target: this.voice.targetUser });
            this.renderVoicePanel();
            return;
        }

        if (eventType === 'voice_signal') {
            this.voiceTrace('signal-event', {
                roomId: payload.roomId || '',
                from: payload.from || payload.sender || '',
                to: payload.to || '',
                signalType: payload.signal?.type || payload.payload?.type || '',
            });
            await this.handleVoiceSignal(payload);
            return;
        }

        if (eventType === 'voice_call_rejected') {
            if (this.voice.outgoingInvite?.roomId === String(payload.roomId || '').trim()) {
                this.voiceTrace('outgoing-rejected', { roomId: payload.roomId || '', from: payload.from || '' }, 'WARN');
                this.recordVoiceCallHistory({ outcome: 'rejected', endedAt: Date.now() });
                this.resetVoiceState({ preserveInvite: false });
            }
            return;
        }

        if (eventType === 'voice_call_cancelled') {
            if (this.voice.incomingInvite?.roomId === String(payload.roomId || '').trim()) {
                this.voiceTrace('incoming-cancelled', { roomId: payload.roomId || '', from: payload.from || '' }, 'WARN');
                this.recordVoiceCallHistory({ outcome: 'cancelled', endedAt: Date.now() });
                this.resetVoiceState({ preserveInvite: false });
            }
            return;
        }

        if (eventType === 'voice_call_accepted') {
            const roomId = String(payload.roomId || '').trim();
            const me = String(this.myName() || '').trim();
            const from = String(payload.from || '').trim();
            const target = String(payload.target || '').trim();
            const remotePeer = from && from !== me ? from : target;
            const callOwner = target || this.voice.inviter || '';
            const participants = Array.isArray(payload.participants)
                ? payload.participants.map(name => String(name || '').trim()).filter(Boolean)
                : [payload.from, payload.target].map(name => String(name || '').trim()).filter(Boolean);
            this.voice.roomId = roomId || this.voice.roomId;
            this.voice.roomType = 'dm';
            this.voice.targetUser = remotePeer || this.voice.targetUser || '';
            this.voice.inviter = callOwner || this.voice.inviter || '';
            this.voice.participants = participants.length ? participants : this.voice.participants;
            this.voice.status = 'connected';
            if (roomId && String(this.voice.outgoingInvite?.roomId || '').trim() === roomId) {
                this.voice.outgoingInvite = null;
            }
            if (roomId && String(this.voice.incomingInvite?.roomId || '').trim() === roomId) {
                this.voice.incomingInvite = null;
            }
            this.voiceTrace('call-accepted', { roomId, from, target, participants });
            if (this.voice.callTrack) {
                this.voice.callTrack.connectedAt = this.voice.callTrack.connectedAt || Date.now();
                this.voice.callTrack.outcome = 'connected';
            }
            this.renderVoicePanel();
            try {
                await this.ensureVoiceLocalStream();
            } catch (error) {
                this.addLogEntry({ type: 'WARN', msg: error?.message || 'Не удалось получить доступ к микрофону', ts: new Date().toLocaleTimeString() });
            }
            await this.syncVoicePeers();
            return;
        }

        if (eventType === 'voice_call_connected') {
            const roomId = String(payload.roomId || '').trim();
            const me = String(this.myName() || '').trim();
            const from = String(payload.from || '').trim();
            const target = String(payload.target || '').trim();
            const remotePeer = from && from !== me ? from : target;
            const callOwner = target || this.voice.inviter || '';
            const participants = Array.isArray(payload.participants)
                ? payload.participants.map(name => String(name || '').trim()).filter(Boolean)
                : [payload.from, payload.target].map(name => String(name || '').trim()).filter(Boolean);
            this.voice.roomId = roomId || this.voice.roomId;
            this.voice.roomType = 'dm';
            this.voice.targetUser = remotePeer || this.voice.targetUser || '';
            this.voice.inviter = callOwner || this.voice.inviter || '';
            this.voice.participants = participants.length ? participants : this.voice.participants;
            this.voice.status = 'connected';
            if (roomId && String(this.voice.outgoingInvite?.roomId || '').trim() === roomId) {
                this.voice.outgoingInvite = null;
            }
            if (roomId && String(this.voice.incomingInvite?.roomId || '').trim() === roomId) {
                this.voice.incomingInvite = null;
            }
            this.voiceTrace('call-connected', { roomId, from, target, participants }, 'SUCCESS');
            if (this.voice.callTrack) {
                this.voice.callTrack.connectedAt = this.voice.callTrack.connectedAt || Date.now();
                this.voice.callTrack.outcome = 'connected';
            }
            this.renderVoicePanel();
            try {
                await this.ensureVoiceLocalStream();
            } catch (error) {
                this.addLogEntry({ type: 'WARN', msg: error?.message || 'Не удалось получить доступ к микрофону', ts: new Date().toLocaleTimeString() });
            }
            await this.syncVoicePeers();
            return;
        }

        if (eventType === 'voice_error') {
            this.addLogEntry({
                type: 'ERROR',
                msg: String(payload.message || 'Ошибка voice'),
                ts: new Date().toLocaleTimeString(),
            });
            return;
        }

        if (eventType === 'voice_room_state') {
            const roomId = String(payload.roomId || '').trim();
            const participants = Array.isArray(payload.participants) ? payload.participants.map(name => String(name || '').trim()).filter(Boolean) : [];
            const currentRoomId = String(this.voice.roomId || '').trim();
            if (this.voice.roomType === 'dm' && currentRoomId && roomId && roomId !== currentRoomId) {
                this.voiceTrace('room-state-stale', { roomId, currentRoomId }, 'INFO');
                return;
            }
            this.voice.roomId = roomId;
            this.voice.roomType = String(payload.roomType || this.voice.roomType || '').trim();
            this.voice.serverId = String(payload.serverId || this.voice.serverId || '').trim();
            this.voice.channelId = String(payload.channelId || this.voice.channelId || '').trim();
            this.voice.participants = participants;
            this.voice.status = participants.includes(this.myName()) ? 'connected' : 'idle';
            this.voiceTrace('room-state', { roomId, roomType: this.voice.roomType || '', participants });
            if (participants.includes(this.myName()) && this.voice.callTrack && !this.voice.callTrack.connectedAt) {
                this.voice.callTrack.connectedAt = Date.now();
                this.voice.callTrack.outcome = 'connected';
            }
            if (String(this.voice.outgoingInvite?.roomId || '').trim() === roomId) {
                this.voice.outgoingInvite = null;
            }
            if (String(this.voice.incomingInvite?.roomId || '').trim() === roomId) {
                this.voice.incomingInvite = null;
            }
            if (participants.includes(this.myName())) {
                try {
                    await this.ensureVoiceLocalStream();
                } catch (error) {
                    this.addLogEntry({ type: 'WARN', msg: error?.message || 'Не удалось получить доступ к микрофону', ts: new Date().toLocaleTimeString() });
                }
                await this.syncVoicePeers();
            } else if (this.voice.roomType === 'dm' && this.voice.roomId === roomId && this.voice.callTrack) {
                this.voice.status = this.voice.status === 'idle' ? 'connecting' : this.voice.status;
            } else {
                this.voiceTrace('room-state-reset', { roomId, participants }, 'WARN');
                this.resetVoiceState({ preserveInvite: true });
            }
            this.renderVoicePanel();
            return;
        }

        if (eventType === 'voice_call_ended') {
            const roomId = String(payload.roomId || '').trim();
            const currentRoomId = String(this.voice.roomId || '').trim();
            if (roomId && currentRoomId && roomId !== currentRoomId) {
                this.voiceTrace('call-ended-stale', { roomId, currentRoomId }, 'INFO');
                return;
            }
            this.voiceTrace('call-ended', { roomId, from: payload.from || '', currentRoomId });
            this.leaveVoiceRoom({ announce: false, outcome: 'completed' });
            return;
        }
    }

    renderVoiceParticipants() {
        const participants = Array.isArray(this.voice.participants) ? this.voice.participants : [];
        if (!participants.length) {
            return '<div class="voice-empty">Пока никого нет</div>';
        }
        return `<div class="voice-participants">` + participants.map(name => {
            const cls = name === this.myName() ? 'mine' : '';
            return `<span class="voice-participant ${cls}">${this.esc(name)}</span>`;
        }).join('') + `</div>`;
    }

    renderVoiceRoomView() {
        const isVoice = this.isVoiceChannel(this.currentChannel());
        const me = String(this.myName() || '').trim().toLowerCase();
        const participants = Array.isArray(this.voice.participants)
            ? this.voice.participants.map(name => String(name || '').trim().toLowerCase()).filter(Boolean)
            : [];
        const participantMatch = me && participants.includes(me);
        const connectedDmRoom = this.voice.roomType === 'dm' && !!String(this.voice.roomId || '').trim() && (this.voice.status === 'connected' || participantMatch);
        const activeRoom = isVoice ? !!this.voice.roomId && participantMatch : connectedDmRoom;
        const outgoingTarget = this.voice.outgoingInvite?.target || this.voice.targetUser || '';
        const incomingFrom = this.voice.incomingInvite?.from || this.voice.inviter || '';
        const voiceHealth = this.getVoiceHealthSnapshot();
        const title = isVoice
            ? `Голосовой канал: ${this.currentChannel()?.name || 'room'}`
            : activeRoom
                ? `Активный звонок${outgoingTarget || incomingFrom ? ` с ${outgoingTarget || incomingFrom}` : ''}`
                : this.voice.status === 'incoming'
                    ? `Входящий звонок от ${incomingFrom}`
                    : this.voice.status === 'calling'
                        ? `Звонок ${outgoingTarget ? `к ${outgoingTarget}` : ''}`
                        : this.voice.status === 'connecting'
                            ? `Соединяемся${outgoingTarget || incomingFrom ? ` с ${outgoingTarget || incomingFrom}` : ''}`
                            : 'Голосовые вызовы';

        const actionButtons = [];
        if (isVoice) {
            if (activeRoom) {
                actionButtons.push(`<button class="voice-btn danger" type="button" id="voiceLeaveBtn">Покинуть</button>`);
                actionButtons.push(`<button class="voice-btn" type="button" id="voiceMuteBtn">${this.voice.muted ? 'Включить микрофон' : 'Выключить микрофон'}</button>`);
            } else {
                actionButtons.push(`<button class="voice-btn" type="button" id="voiceJoinBtn">Присоединиться</button>`);
            }
        } else if (this.S.navMode === 'dm' && this.S.current) {
            if (activeRoom) {
                actionButtons.push(`<button class="voice-btn danger" type="button" id="voiceLeaveBtn">Завершить</button>`);
                actionButtons.push(`<button class="voice-btn" type="button" id="voiceMuteBtn">${this.voice.muted ? 'Включить микрофон' : 'Выключить микрофон'}</button>`);
            } else if (this.voice.status === 'incoming' && this.voice.incomingInvite?.from) {
                actionButtons.push(`<button class="voice-btn" type="button" id="voiceAcceptBtn">Принять</button>`);
                actionButtons.push(`<button class="voice-btn danger" type="button" id="voiceRejectBtn">Отклонить</button>`);
            } else if (this.voice.status === 'calling') {
                actionButtons.push(`<button class="voice-btn danger" type="button" id="voiceCancelBtn">Отменить</button>`);
            } else {
                actionButtons.push(`<button class="voice-btn" type="button" id="voiceCallBtn">Позвонить</button>`);
            }
        }

        return `
            <div class="voice-room-card ${activeRoom ? 'active' : ''} ${isVoice ? 'voice-channel' : ''}">
                <div class="voice-room-top">
                    <div>
                        <div class="voice-room-title">${this.esc(title)}</div>
                        <div class="voice-room-sub">${this.esc(this.voice.status === 'connected' ? 'Собеседник поднял трубку' : this.voice.status === 'incoming' ? 'Входящий звонок' : this.voice.status === 'calling' ? 'Ожидание ответа' : this.voice.status === 'connecting' ? 'Соединяемся' : 'Голос готов')}</div>
                    </div>
                    <div class="voice-room-state">${this.esc(activeRoom ? 'В эфире' : isVoice ? 'Выбрано' : 'Ожидание')}</div>
                </div>
                <div class="voice-room-actions">${actionButtons.join('')}</div>
                <div class="voice-meter-grid">
                    <div class="voice-meter" id="voiceMicMeter">
                        <div class="voice-meter-head">
                            <span class="voice-meter-name">Микрофон</span>
                            <span class="voice-meter-value" id="voiceMicLevelText">0%</span>
                        </div>
                        <div class="voice-meter-track">
                            <div class="voice-meter-fill" id="voiceMicLevelFill"></div>
                        </div>
                    </div>
                    <div class="voice-meter" id="voiceServerMeter">
                        <div class="voice-meter-head">
                            <span class="voice-meter-name">С сервера</span>
                            <span class="voice-meter-value" id="voiceServerLevelText">0%</span>
                        </div>
                        <div class="voice-meter-track">
                            <div class="voice-meter-fill remote" id="voiceServerLevelFill"></div>
                        </div>
                    </div>
                </div>
                ${voiceHealth.length ? `
                    <div class="voice-health">
                        <div class="voice-room-label">Voice health</div>
                        <div class="voice-health-grid">
                            ${voiceHealth.map(item => `
                                <div class="voice-health-card" data-tone="${this.esc(item.tone)}">
                                    <span class="voice-health-name">${this.esc(item.label)}</span>
                                    <strong class="voice-health-value">${this.esc(item.value)}</strong>
                                    <span class="voice-health-sub">${this.esc(item.sub || '')}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
                <div class="voice-room-participants">
                    <div class="voice-room-label">Участники</div>
                    ${this.renderVoiceParticipants()}
                </div>
                ${Array.isArray(this.voice.traceLines) && this.voice.traceLines.length ? `
                    <div class="voice-trace">
                        <div class="voice-room-label">Трассировка</div>
                        <div class="voice-trace-list">
                            ${this.voice.traceLines.slice(-8).map(line => `
                                <div class="voice-trace-line voice-trace-${this.esc(line.level.toLowerCase())}">
                                    <span class="voice-trace-ts">[${this.esc(line.ts)}]</span>
                                    <span class="voice-trace-stage">${this.esc(line.stage)}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
            </div>
        `;
    }

    renderVoicePanel() {
        const panel = document.getElementById('voicePanel');
        if (!panel) return;
        const isServers = this.S.navMode === 'servers';
        const isVoiceChannel = isServers && this.isVoiceChannel(this.currentChannel());
        const hasDmCall = this.voice.roomType === 'dm' || this.voice.status === 'incoming' || this.voice.status === 'calling';
        const hasIncoming = this.voice.status === 'incoming';
        const showPanel = isVoiceChannel || hasDmCall || hasIncoming;
        panel.hidden = !showPanel;
        if (!showPanel) {
            panel.innerHTML = '';
            return;
        }
        if (isVoiceChannel || hasDmCall || hasIncoming || this.voice.roomType === 'dm') {
            panel.innerHTML = this.renderVoiceRoomView();
            return;
        }
        panel.innerHTML = '';
    }

    isOutgoingMessage(msg) {
        return String(msg?.sender || '').trim() === this.myName();
    }

    mergeServerChatMessages(key, incomingMessages) {
        const existing = Array.isArray(this.S.serverChats[key]) ? this.S.serverChats[key] : [];
        const merged = [];
        const mergedByKey = new Map();

        const makeIdentity = (msg) => {
            const normalized = {
                ...msg,
                id: String(msg?.id || '').trim(),
                clientId: String(msg?.clientId || '').trim(),
                serverId: msg?.serverId || msg?.server_id || null,
                channelId: msg?.channelId || msg?.channel_id || null,
            };
            const attachmentKey = this.normalizeAttachments(normalized.attachments)
                .map(att => `${att.name}:${att.kind}:${att.size}:${att.mimeType}`)
                .join('|');
            const identity = normalized.id || normalized.clientId || [
                normalized.sender || '',
                normalized.receiver || '',
                normalized.timestamp || '',
                normalized.text || '',
                attachmentKey,
            ].join('::');
            return { normalized, identity };
        };

        const upsert = (msg) => {
            const { normalized, identity } = makeIdentity(msg);
            const prev = mergedByKey.get(identity);
            const next = prev
                ? {
                    ...prev,
                    ...normalized,
                    attachments: this.normalizeAttachments(normalized.attachments ?? prev.attachments),
                    reactions: this.normalizeReactions(normalized.reactions ?? prev.reactions),
                    myReaction: String(normalized.myReaction ?? prev.myReaction ?? '').trim(),
                }
                : {
                    ...normalized,
                    attachments: this.normalizeAttachments(normalized.attachments),
                    reactions: this.normalizeReactions(normalized.reactions),
                    myReaction: String(normalized.myReaction || '').trim(),
                };
            mergedByKey.set(identity, next);
            if (!prev) merged.push(identity);
        };

        existing.forEach(upsert);
        (Array.isArray(incomingMessages) ? incomingMessages : []).forEach(upsert);

        const next = merged
            .map(identity => mergedByKey.get(identity))
            .sort((a, b) => new Date(a.timestamp || 0) - new Date(b.timestamp || 0));
        this.S.serverChats[key] = next;
        this.saveStoredServerChats();
        return next;
    }

    ensureServerSelection() {
        this.ensureServersState();
        const servers = Array.isArray(this.S.servers) ? this.S.servers : [];
        if (servers.length === 0) {
            this.S.activeServer = null;
            this.S.activeChannel = null;
            return;
        }

        const storedServer = this.loadStoredActiveServer();
        if (storedServer && servers.some(s => s.id === storedServer)) {
            this.S.activeServer = storedServer;
        } else if (!this.S.activeServer || !servers.some(s => s.id === this.S.activeServer)) {
            this.S.activeServer = servers[0].id;
        }

        const server = this.currentServer();
        const storedChannel = this.loadStoredActiveChannel();
        if (server) {
            if (storedChannel && (server.channels || []).some(ch => ch.id === storedChannel)) {
                this.S.activeChannel = storedChannel;
            } else if (!this.S.activeChannel || !(server.channels || []).some(ch => ch.id === this.S.activeChannel)) {
                this.S.activeChannel = server.channels?.[0]?.id || null;
            }
        }
    }

    async loadServers({ silent = false } = {}) {
        try {
            const res = await this.apiFetch('/api/servers');
            if (!res.ok) {
                this.S.servers = this.getDefaultServers().map(server => ({ ...server, channels: [
                    { id: `${server.id}-general`, name: 'general', topic: 'Общий чат', kind: 'text', position: 0 },
                    { id: `${server.id}-voice`, name: 'voice', topic: 'Голосовой канал', kind: 'voice', position: 1 },
                ] }));
                this.ensureServerSelection();
                this.renderContacts();
                this.renderServerInterface();
                this.renderMessages();
                return;
            }
            const data = await res.json();
            this.S.servers = this.normalizeServers(Array.isArray(data?.servers) ? data.servers : []);
            this.ensureServerSelection();
            this.renderContacts();
            this.renderServerInterface();
            this.renderMessages();
            if (this.S.activeServer && this.S.activeChannel) {
                this.loadServerMessages(this.S.activeServer, this.S.activeChannel, { silent: true });
            }
        } catch (e) {
            if (!silent) {
                this.addLogEntry({ type: 'WARN', msg: 'Не удалось загрузить серверы', ts: new Date().toLocaleTimeString() });
            }
            this.S.servers = this.getDefaultServers().map(server => ({ ...server, channels: [
                { id: `${server.id}-general`, name: 'general', topic: 'Общий чат', kind: 'text', position: 0 },
                { id: `${server.id}-voice`, name: 'voice', topic: 'Голосовой канал', kind: 'voice', position: 1 },
            ] }));
            this.ensureServerSelection();
            this.renderContacts();
            this.renderServerInterface();
            this.renderMessages();
            if (this.S.activeServer && this.S.activeChannel) {
                this.loadServerMessages(this.S.activeServer, this.S.activeChannel, { silent: true });
            }
        }
    }

    async loadServerMessages(serverId, channelId, { silent = false } = {}) {
        const sid = String(serverId || '').trim();
        const cid = String(channelId || '').trim();
        if (!sid || !cid) return;
        this.trace(`loadServerMessages start server=${sid} channel=${cid} nativeHistory=${this.nativeSupports('serverHistory')}`);
        const key = `${sid}:${cid}`;
        if (!Array.isArray(this.S.serverChats[key])) {
            this.S.serverChats[key] = [];
        }
        const channel = (this.currentServer()?.channels || []).find(item => item.id === cid) || null;
        if (this.isVoiceChannel(channel)) {
            this.renderMessages();
            return;
        }
        this.renderMessages();

        if (this.nativeSupports('serverHistory')) {
            this.postNativeMessage({
                type: 'LOAD_SERVER_HISTORY',
                serverId: sid,
                channelId: cid,
            });
            return;
        }

        try {
            const res = await this.apiFetch(`/api/servers/${encodeURIComponent(sid)}/channels/${encodeURIComponent(cid)}/messages`);
            if (!res.ok) {
                const text = await res.text().catch(() => '');
                this.trace(`loadServerMessages failed server=${sid} channel=${cid} status=${res.status} body=${text.slice(0, 300)}`);
                if (!silent) {
                    this.addLogEntry({ type: 'WARN', msg: `Не удалось загрузить сообщения канала ${cid}`, ts: new Date().toLocaleTimeString() });
                }
                return;
            }
            const messages = await res.json();
            this.trace(`loadServerMessages success server=${sid} channel=${cid} count=${Array.isArray(messages) ? messages.length : 0}`);
            const normalized = Array.isArray(messages) ? messages.map(msg => ({
                id: msg.id,
                sender: msg.sender,
                receiver: msg.receiver || cid,
                text: msg.filename || '',
                attachments: [],
                timestamp: msg.timestamp,
                serverId: msg.serverId || msg.server_id || sid,
                channelId: msg.channelId || msg.channel_id || cid,
                reactions: msg.reactions || [],
                myReaction: msg.myReaction || msg.my_reaction || '',
            })) : [];
            if (normalized.length > 0) {
                this.mergeServerChatMessages(key, normalized);
            }
            this.renderMessages();
        } catch (e) {
            if (!silent) {
                this.addLogEntry({ type: 'ERROR', msg: `Ошибка загрузки канала ${cid}: ${e?.message || e}`, ts: new Date().toLocaleTimeString() });
            }
        }
    }

    loadServerHistory(payload) {
        if (!payload || typeof payload !== 'object') return;
        const serverId = String(payload.serverId || payload.server_id || '').trim();
        const channelId = String(payload.channelId || payload.channel_id || '').trim();
        const messages = Array.isArray(payload.messages) ? payload.messages : [];
        if (!serverId || !channelId) return;
        this.trace(`loadServerHistory start server=${serverId} channel=${channelId} count=${messages.length}`);

        const key = `${serverId}:${channelId}`;
        const normalized = messages.map(msg => ({
            ...msg,
            serverId: msg.serverId || msg.server_id || serverId,
            channelId: msg.channelId || msg.channel_id || channelId,
        }));
        const reconciled = [];
        for (const msg of normalized) {
            const clientId = String(msg.clientId || msg.client_id || '').trim();
            if (clientId && this.finalizePendingMessage(clientId, msg.id)) {
                this.dropPendingOutbox(clientId);
                continue;
            }
            reconciled.push(msg);
        }
        this.mergeServerChatMessages(key, reconciled);
        if (this.currentServerChatKey() === key) {
            this.requestMessagesScroll('bottom');
            this.renderMessages();
        }
        this.scheduleFlushPendingOutbox(300);
        this.trace(`loadServerHistory done server=${serverId} channel=${channelId} merged=${reconciled.length}`);
    }

    refreshAfterKey() {
        if (this.S.navMode === 'servers' && this.S.activeServer && this.S.activeChannel) {
            this.ensureConversationCryptoKey({
                serverId: this.S.activeServer,
                channelId: this.S.activeChannel,
                reason: 'refreshAfterKey'
            });
            this.loadServerMessages(this.S.activeServer, this.S.activeChannel, { silent: true });
            this.scheduleFlushPendingOutbox(300);
            return;
        }

        if (this.S.current) {
            this.ensureConversationCryptoKey({ peer: this.S.current, reason: 'refreshAfterKey' });
        }
        if (this.nativeSupports('sendMessage')) {
            this.postNativeMessage({ type: 'REFRESH_HISTORY' });
        }
        this.scheduleFlushPendingOutbox(300);
    }

    syncActiveConversation({ force = false } = {}) {
        if (!force && !this.S.session?.token) return;
        if (this.S.navMode === 'servers') {
            const serverId = this.S.activeServer;
            const channelId = this.S.activeChannel;
            if (serverId && channelId) {
                this.trace(`syncActiveConversation server=${serverId} channel=${channelId}`);
                this.loadServerMessages(serverId, channelId, { silent: true });
            }
            return;
        }

        const peer = String(this.S.current || '').trim();
        if (!peer) return;
        this.trace(`syncActiveConversation peer=${peer} force=${force}`);
        this.ensureConversationCryptoKey({ peer, reason: 'syncActiveConversation' });
        if (this.nativeSupports('sendMessage')) {
            this.postNativeMessage({ type: 'REFRESH_HISTORY' });
        }
    }

    renderServerInterface() {
        this.ensureServersState();
        this.ensureServerSelection();
        this.renderServerToolbar();
        this.updateSendButtonState();
    }

    renderServerToolbar() {
        const channelList = document.getElementById('serverChannelList');
        const chatHdr = document.getElementById('chatHdr');
        const chatHdrAva = document.getElementById('chatHdrAva');
        const chatHdrName = document.getElementById('chatHdrName');
        const chatHdrSub = document.getElementById('chatHdrSub');
        const chatCallBtn = document.getElementById('chatCallBtn');
        const serverSettingsBtn = document.getElementById('serverSettingsBtn');
        const tbChat = document.getElementById('tbChat');
        const server = this.currentServer();
        const channel = this.currentChannel();
        const isServers = this.S.navMode === 'servers';
        const canManage = this.canManageServer(server);

        if (chatHdr) chatHdr.classList.toggle('server-mode', isServers);
        if (channelList) channelList.hidden = !isServers;
        if (chatCallBtn) {
            chatCallBtn.hidden = isServers || !this.S.current;
        }
        if (serverSettingsBtn) {
            serverSettingsBtn.hidden = !isServers || !server || !canManage;
            serverSettingsBtn.disabled = !canManage;
        }
        if (!isServers) {
            if (channelList) channelList.innerHTML = '';
            if (chatHdrAva) chatHdrAva.innerHTML = this.renderAvatarHTML(this.S.current || this.myName(), 'avatar-img', this.S.current || this.myName());
            if (chatHdrName) chatHdrName.textContent = this.S.current || 'Выберите чат';
            if (chatHdrSub) {
                chatHdrSub.innerHTML = '';
                if (this.S.current) {
                    this.updateChatHeaderCryptoKey({ peer: this.S.current });
                } else {
                    chatHdrSub.textContent = 'Личное сообщение';
                }
            }
            return;
        }
        if (!server) {
            if (channelList) channelList.innerHTML = '';
            return;
        }

        if (chatHdrAva) chatHdrAva.innerHTML = this.esc(server.icon || server.name?.[0] || 'S');
        if (chatHdrName) {
            const membersText = Number(server.memberCount || 0) > 0 ? `${Number(server.memberCount)} участников` : '';
            const channelLabel = channel
                ? `${this.isVoiceChannel(channel) ? '🔊 ' : '#'}${channel.name}`
                : server.name;
            chatHdrName.innerHTML = `
                <span class="chat-hdr-title">${this.esc(channelLabel)}</span>
                ${membersText ? `<span class="chat-hdr-count">${this.esc(membersText)}</span>` : ''}
            `;
        }
        if (chatHdrSub) {
            chatHdrSub.textContent = channel
                ? `${server.name}${channel.topic ? ` · ${channel.topic}` : ''}`
                : (server.description || 'Сервер');
        }
        if (tbChat) {
            tbChat.textContent = channel
                ? `${server.name} / ${this.isVoiceChannel(channel) ? '🔊' : '#'}${channel.name}`
                : server.name;
        }

        if (channelList) {
            const channels = Array.isArray(server.channels) ? server.channels : [];
            channelList.innerHTML = channels.map(ch => {
                const active = ch.id === this.S.activeChannel ? 'active' : '';
                const kind = String(ch.kind || 'text').trim().toLowerCase();
                const icon = kind === 'voice' ? '◉' : '#';
                const title = kind === 'voice' ? 'Голосовой канал' : 'Текстовый канал';
                return `<button class="server-channel ${active}" type="button" data-channel-id="${this.esc(ch.id)}" data-channel-kind="${this.esc(kind)}" title="${this.esc(title)}">
                    <span class="server-channel-hash ${kind}">${this.esc(icon)}</span>
                    <span class="server-channel-name">${this.esc(ch.name)}</span>
                </button>`;
            }).join('');

            const activeChannel = channelList.querySelector('.server-channel.active');
            if (activeChannel && typeof activeChannel.scrollIntoView === 'function') {
                requestAnimationFrame(() => {
                    activeChannel.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
                });
            }
        }
    }

    setActiveChannel(channelId, { persist = true } = {}) {
        const next = String(channelId || '').trim();
        const server = this.currentServer();
        if (!server || !next) return;
        const channel = (server.channels || []).find(ch => ch.id === next) || null;
        if (!channel) return;
        if (this.S.navMode === 'servers' && this.S.activeChannel === next) return;
        if (this.voice.roomType === 'channel' && this.voice.roomId) {
            const currentChannelId = String(this.voice.channelId || '').trim();
            if (currentChannelId && currentChannelId !== next) {
                this.leaveVoiceRoom({ announce: true });
            }
        }
        this.S.activeChannel = next;
        if (persist) this.saveStoredActiveChannel(next);
        this.saveStoredNavMode('servers');
        this.renderServerToolbar();
        this.requestMessagesScroll('bottom');
        this.renderMessages();
        this.updateSendButtonState();
        if (this.isVoiceChannel(channel)) {
            const roomId = this.voiceRoomKeyForChannel(server.id, next);
            const alreadyJoined = this.voice.roomId === roomId && this.voice.participants.includes(this.myName());
            if (!alreadyJoined) {
                this.joinVoiceChannel({ serverId: server.id, channelId: next });
            } else {
                this.renderVoicePanel();
            }
            this.renderVoicePanel();
            return;
        }
        this.requestMessagesScroll('bottom');
        this.loadServerMessages(server.id, next, { silent: true });
    }

    setNavMode(mode, { persist = true, refresh = true } = {}) {
        const next = mode === 'servers' ? 'servers' : 'dm';
        if (this.S.navMode === next) {
            this.updateNavModeButtons();
            return;
        }
        this.S.navMode = next;
        if (next === 'servers') {
            this.ensureServersState();
            this.ensureServerSelection();
        }
        if (persist) {
            this.saveStoredNavMode(next);
        }
        this.updateNavModeButtons();
        if (!refresh) return;
        this.renderServerInterface();
        this.renderContacts();
        this.requestMessagesScroll('bottom');
        this.renderMessages();
        this.renderVoicePanel();
        if (next === 'servers' && this.S.activeServer && this.S.activeChannel) {
            this.requestMessagesScroll('bottom');
            this.loadServerMessages(this.S.activeServer, this.S.activeChannel, { silent: true });
        }
    }

    avatarCacheKey(username) {
        return String(username || '').trim().toLowerCase();
    }

    loadStoredAvatar(username) {
        const key = this.avatarCacheKey(username);
        return this.avatarCache.has(key) ? this.avatarCache.get(key) : undefined;
    }

    saveStoredAvatar(username, dataUrl) {
        const key = this.avatarCacheKey(username);
        const prev = this.avatarCache.get(key);
        if (prev && typeof prev === 'string' && prev.startsWith('blob:') && prev !== dataUrl) {
            try { URL.revokeObjectURL(prev); } catch (e) {}
        }
        this.avatarFetchSeq.set(key, (this.avatarFetchSeq.get(key) || 0) + 1);
        this.avatarCache.set(key, dataUrl || null);
    }

    clearStoredAvatar(username) {
        const key = this.avatarCacheKey(username);
        const prev = this.avatarCache.get(key);
        if (prev && typeof prev === 'string' && prev.startsWith('blob:')) {
            try { URL.revokeObjectURL(prev); } catch (e) {}
        }
        this.avatarFetchSeq.set(key, (this.avatarFetchSeq.get(key) || 0) + 1);
        this.avatarCache.delete(key);
    }

    avatarFallback(username) {
        const value = String(username || '').trim();
        return value ? value[0].toUpperCase() : 'Z';
    }

    renderAvatarHTML(username, className = 'ava', alt = '') {
        const src = this.loadStoredAvatar(username);
        const fallback = this.avatarFallback(username);
        const safeAlt = this.esc(alt || username || fallback);
        if (src === undefined) {
            this.ensureAvatarLoaded(username);
        } else if (src) {
            const classes = String(className || '')
                .split(/\s+/)
                .filter(Boolean)
                .concat('avatar-img')
                .filter((v, i, arr) => arr.indexOf(v) === i)
                .join(' ');
            return `<img class="${classes}" src="${this.esc(src)}" alt="${safeAlt}">`;
        }
        return this.esc(fallback);
    }

    serverAssetCacheKey(serverId, kind) {
        return `${String(serverId || '').trim()}:${kind}`;
    }

    async loadServerAsset(serverId, kind, { force = false } = {}) {
        const sid = String(serverId || '').trim();
        if (!sid) return null;
        const key = this.serverAssetCacheKey(sid, kind);
        if (!force && this.serverAssetCache.has(key)) {
            return this.serverAssetCache.get(key);
        }
        if (this.serverAssetRequests.has(key) && !force) {
            return this.serverAssetRequests.get(key);
        }

        const seq = (this.serverAssetFetchSeq.get(key) || 0) + 1;
        this.serverAssetFetchSeq.set(key, seq);

        const request = (async () => {
            try {
                const res = await this.apiFetch(`/api/servers/${encodeURIComponent(sid)}/assets/${kind}`);
                if (this.serverAssetFetchSeq.get(key) !== seq) return null;
                if (res.status === 404) {
                    this.serverAssetCache.set(key, null);
                    return null;
                }
                if (!res.ok) return null;
                const blob = await res.blob();
                if (!blob || blob.size === 0) {
                    this.serverAssetCache.set(key, null);
                    return null;
                }
                const url = await this.blobToObjectUrl(blob);
                this.serverAssetCache.set(key, url);
                return url;
            } catch (e) {
                return null;
            } finally {
                if (this.serverAssetRequests.get(key) === request) {
                    this.serverAssetRequests.delete(key);
                }
            }
        })();

        this.serverAssetRequests.set(key, request);
        return request;
    }

    clearServerAssetCache(serverId, kind) {
        const key = this.serverAssetCacheKey(serverId, kind);
        const prev = this.serverAssetCache.get(key);
        if (prev && typeof prev === 'string' && prev.startsWith('blob:')) {
            try { URL.revokeObjectURL(prev); } catch (e) {}
        }
        this.serverAssetFetchSeq.set(key, (this.serverAssetFetchSeq.get(key) || 0) + 1);
        this.serverAssetCache.delete(key);
    }

    serverAssetFallback(server, kind) {
        if (kind === 'avatar') {
            return this.esc(server?.icon || server?.name?.[0] || 'S');
        }
        return this.esc((server?.name || 'BAN').slice(0, 3).toUpperCase());
    }

    resetServerAssetPreview() {
        const avatarBox = document.getElementById('serverAvatarPreview');
        const bannerBox = document.getElementById('serverBannerPreview');
        if (avatarBox) {
            avatarBox.innerHTML = '';
            avatarBox.style.backgroundImage = '';
            avatarBox.textContent = 'S';
        }
        if (bannerBox) {
            bannerBox.innerHTML = '';
            bannerBox.style.backgroundImage = '';
            bannerBox.style.backgroundSize = '';
            bannerBox.style.backgroundPosition = '';
            bannerBox.textContent = 'BAN';
        }
    }

    async syncServerAssetPreview(serverId) {
        const sid = String(serverId || '').trim();
        const avatar = await this.loadServerAsset(serverId, 'avatar');
        const banner = await this.loadServerAsset(serverId, 'banner');
        const avatarBox = document.getElementById('serverAvatarPreview');
        const bannerBox = document.getElementById('serverBannerPreview');
        const server = (this.S.servers || []).find(item => item.id === sid) || null;
        if (avatarBox) {
            avatarBox.style.backgroundImage = '';
            if (avatar) {
                avatarBox.innerHTML = `<img class="avatar-img" src="${this.esc(avatar)}" alt="server avatar">`;
            } else {
                avatarBox.innerHTML = '';
                avatarBox.textContent = this.serverAssetFallback(server, 'avatar');
            }
        }
        if (bannerBox) {
            if (banner) {
                bannerBox.innerHTML = '';
                bannerBox.style.backgroundImage = `url('${this.esc(banner)}')`;
                bannerBox.style.backgroundSize = 'cover';
                bannerBox.style.backgroundPosition = 'center';
            } else {
                bannerBox.style.backgroundImage = '';
                bannerBox.innerHTML = '';
                bannerBox.textContent = this.serverAssetFallback(server, 'banner');
            }
        }
    }

    scheduleAvatarRefresh() {
        if (this.avatarRefreshScheduled) return;
        this.avatarRefreshScheduled = true;
        requestAnimationFrame(() => {
            this.avatarRefreshScheduled = false;
            this.renderSidebarProfile();
            this.renderContacts();
            this.renderMessages();
        });
    }

    updateAvatarViews() {
        this.renderSidebarProfile();
        this.renderContacts();
        this.renderMessages();
    }

    refreshVisibleAvatars() {
        if (this.nativeSupports('serverHistory') && this.nativeSupports('voice') && this.nativeSupports('downloadAttachment')) return;
        const users = new Set([this.myName(), this.S.current, ...(this.S.contacts || [])].filter(Boolean));
        Object.values(this.S.serverChats || {}).forEach(msgs => {
            (msgs || []).forEach(msg => {
                if (msg?.sender) users.add(msg.sender);
            });
        });
        users.forEach(username => {
            this.ensureAvatarLoaded(username, { force: true });
        });
    }

    async blobToObjectUrl(blob) {
        return URL.createObjectURL(blob);
    }

    dataUrlToBlob(dataUrl) {
        const value = String(dataUrl || '').trim();
        if (!value.startsWith('data:')) return null;

        const commaIndex = value.indexOf(',');
        if (commaIndex < 0) return null;

        const meta = value.slice(5, commaIndex);
        const payload = value.slice(commaIndex + 1);
        const parts = meta.split(';').filter(Boolean);
        const mimeType = parts[0] || 'application/octet-stream';
        const isBase64 = parts.includes('base64');

        try {
            if (isBase64) {
                const binary = atob(payload);
                const bytes = new Uint8Array(binary.length);
                for (let i = 0; i < binary.length; i += 1) {
                    bytes[i] = binary.charCodeAt(i);
                }
                return new Blob([bytes], { type: mimeType });
            }

            return new Blob([decodeURIComponent(payload)], { type: mimeType });
        } catch (error) {
            console.error('Failed to decode data URL', error);
            return null;
        }
    }

    async downloadAttachmentFromHref(href, filename) {
        const source = String(href || '').trim();
        const safeName = String(filename || 'attachment').trim() || 'attachment';
        if (!source) return false;

        if (this.nativeSupports('downloadAttachment') && source.startsWith('data:')) {
            this.postNativeMessage({
                type: 'DOWNLOAD_ATTACHMENT',
                dataUrl: source,
                filename: safeName,
            });
            return true;
        }

        let objectUrl = source;
        let shouldRevoke = false;

        try {
            if (source.startsWith('data:')) {
                const blob = this.dataUrlToBlob(source);
                if (!blob || blob.size === 0) {
                    throw new Error('Empty attachment payload');
                }
                objectUrl = URL.createObjectURL(blob);
                shouldRevoke = true;
            } else if (!source.startsWith('blob:')) {
                const response = await fetch(source);
                if (!response.ok) {
                    throw new Error(`Unexpected response while downloading attachment: ${response.status}`);
                }
                const blob = await response.blob();
                if (!blob || blob.size === 0) {
                    throw new Error('Empty attachment payload');
                }
                objectUrl = URL.createObjectURL(blob);
                shouldRevoke = true;
            }

            const link = document.createElement('a');
            link.href = objectUrl;
            link.download = safeName;
            link.rel = 'noopener';
            link.style.display = 'none';
            document.body.appendChild(link);
            link.click();
            link.remove();

            if (shouldRevoke) {
                setTimeout(() => {
                    try { URL.revokeObjectURL(objectUrl); } catch (e) {}
                }, 1000);
            }

            return true;
        } catch (error) {
            console.error('Failed to download attachment', error);
            return false;
        }
    }

    async ensureAvatarLoaded(username, { force = false } = {}) {
        const name = String(username || '').trim();
        if (!name) return null;
        const key = this.avatarCacheKey(name);
        if (!force && this.avatarCache.has(key)) {
            return this.avatarCache.get(key);
        }
        if (this.avatarRequests.has(key)) {
            if (!force) {
                return this.avatarRequests.get(key);
            }
        }

        const seq = (this.avatarFetchSeq.get(key) || 0) + 1;
        this.avatarFetchSeq.set(key, seq);

        const request = (async () => {
            try {
                const res = await this.apiFetch(`/api/avatar/${encodeURIComponent(name)}`);
                if (this.avatarFetchSeq.get(key) !== seq) {
                    return null;
                }
                if (res.status === 404) {
                    this.saveStoredAvatar(name, null);
                    this.scheduleAvatarRefresh();
                    return null;
                }
                if (!res.ok) {
                    return null;
                }

                const blob = await res.blob();
                if (this.avatarFetchSeq.get(key) !== seq) {
                    return null;
                }
                if (!blob || blob.size === 0) {
                    this.saveStoredAvatar(name, null);
                    this.scheduleAvatarRefresh();
                    return null;
                }

                const url = await this.blobToObjectUrl(blob);
                if (this.avatarFetchSeq.get(key) !== seq) {
                    try { URL.revokeObjectURL(url); } catch (e) {}
                    return null;
                }
                this.saveStoredAvatar(name, url);
                this.scheduleAvatarRefresh();
                return url;
            } catch (e) {
                return null;
            } finally {
                if (this.avatarRequests.get(key) === request) {
                    this.avatarRequests.delete(key);
                }
            }
        })();

        this.avatarRequests.set(key, request);
        return request;
    }

    renderSidebarProfile() {
        const meName = document.getElementById('meName');
        const meSub = document.getElementById('meSub');
        const meAva = document.getElementById('meAva');
        const avatarPreview = document.getElementById('avatarPreview');
        const username = this.myName();
        if (meName) meName.textContent = username;
        if (meAva) meAva.innerHTML = this.renderAvatarHTML(username, 'avatar-img', username);
        if (avatarPreview) {
            avatarPreview.innerHTML = this.renderAvatarHTML(username, 'avatar-img', username);
            avatarPreview.title = `Ваш аватар: ${username}`;
        }
        this.ensureAvatarLoaded(username);
        if (meSub) {
            meSub.innerHTML = this.S.session?.token
                ? '<span class="online-dot"></span> В сети'
                : '<span class="online-dot guest"></span> Гостевой режим';
        }
        this.updateContactControls();
        this.renderContactSuggestions();
        this.updateNavModeButtons();
        this.ensureServersState();
    }

    readFileAsDataURL(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(String(reader.result || ''));
            reader.onerror = () => reject(new Error('Не удалось прочитать файл'));
            reader.readAsDataURL(file);
        });
    }

    async setProfileAvatar(file) {
        if (!file) return;
        const target = String(this.myName()).trim();
        if (!file.type || !file.type.startsWith('image/')) {
            throw new Error('Нужен файл изображения');
        }
        const MAX_AVATAR_BYTES = 2 * 1024 * 1024;
        if (file.size > MAX_AVATAR_BYTES) {
            throw new Error('Аватар слишком большой. Выберите изображение до 2 МБ');
        }
        const formData = new FormData();
        formData.append('file', file, file.name || 'avatar.png');
        const res = await this.apiFetch('/api/avatar', {
            method: 'POST',
            body: formData,
        });
        if (!res.ok) {
            throw new Error(await res.text() || 'Не удалось сохранить аватар на сервере');
        }
        const objectUrl = URL.createObjectURL(file);
        this.saveStoredAvatar(target, objectUrl);
        this.updateAvatarViews();
    }

    async resetProfileAvatar() {
        const target = String(this.myName()).trim();
        const res = await this.apiFetch('/api/avatar', { method: 'DELETE' });
        if (!res.ok && res.status !== 204) {
            throw new Error(await res.text() || 'Не удалось удалить аватар на сервере');
        }
        this.saveStoredAvatar(target, null);
        this.updateAvatarViews();
    }

    apiHeaders(extra = {}) {
        const headers = { ...extra };
        if (this.S.session?.token) {
            headers.Authorization = `Bearer ${this.S.session.token}`;
        }
        return headers;
    }

    async apiFetch(path, options = {}) {
        const method = String(options?.method || 'GET').toUpperCase();
        this.trace(`apiFetch request method=${method} path=${path} auth=${!!this.S.session?.token}`);
        const res = await fetch(`${this.getApiBaseUrl()}${path}`, {
            ...options,
            headers: this.apiHeaders(options.headers || {}),
        });
        this.trace(`apiFetch response method=${method} path=${path} status=${res.status} ok=${res.ok}`);
        return res;
    }

    async bootstrapSession() {
        this.trace('bootstrapSession start');
        this.sessionBootstrapInProgress = true;
        try {
            const stored = this.loadStoredSession();
            const lastStored = this.loadStoredSession(this.lastAuthStorageKey());
            const candidates = [stored, lastStored].filter(s => s && s.token);

            let restored = false;
            for (const candidate of candidates) {
                restored = await this.restoreSession(candidate);
                if (restored) break;
            }

            if (!restored) {
                if (stored?.token) this.clearStoredSession();
                if (lastStored?.token) this.clearLastStoredSession();
                this.applySession({ username: 'Zalikus', token: null, guest: true }, { persist: false });
            }

            this.clearAuthInputs();
            this.S.auth.fieldsCleared = true;

            await this.loadContacts();
            await this.loadUsers();
            await this.loadServers({ silent: true });
            this.updateAuthView();
            this.applyNetworkConfigToInputs();
            this.syncNativeNetworkConfig();
            this.updateSendButtonState();
            if (this.nativeSupports('sessionSync')) {
                this.syncNativeSession();
            }
        } finally {
            this.sessionBootstrapInProgress = false;
            this.rehydratePendingOutbox();
            this.scheduleFlushPendingOutbox(300);
            this.trace('bootstrapSession done');
        }
    }

    async restoreSession(session) {
        try {
            const token = session?.token || null;
            if (!token) return false;
            this.trace(`restoreSession start username=${session?.username || ''} tokenSet=${!!token}`);
            const res = await this.apiFetch('/api/auth/me', {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });
            if (!res.ok) return false;
            const data = await res.json();
            this.trace(`restoreSession success username=${data.username || session.username || 'Zalikus'}`);
            this.applySession({
                username: data.username || session.username || 'Zalikus',
                token,
                guest: false,
            }, { persist: true, syncNative: true });
            return true;
        } catch (e) {
            this.trace(`restoreSession failed error=${e?.message || e}`);
            return false;
        }
    }

    applySession(session, { persist = true, syncNative = true, connectVoiceSocket = true } = {}) {
        const previousUsername = this.S.session?.username;
        const previousToken = this.S.session?.token;
        const username = session?.username || 'Zalikus';
        const token = session?.token || null;
        const guest = !!session?.guest || !token;
        this.trace(`applySession username=${username} tokenSet=${!!token} guest=${guest} persist=${persist} syncNative=${syncNative}`);

        if (previousUsername !== username || previousToken !== token) {
            this.S.current = null;
            this.S.activeServer = null;
            this.S.activeChannel = null;
            this.S.draftAttachments = [];
            this.resetVoiceState({ preserveInvite: false });
            this.disconnectBrowserVoiceSocket();
            this.setServerModalState({
                mode: 'create',
                serverId: null,
                members: [],
                loading: false,
                saving: false,
                error: '',
            });
            this.closeServerOverlay();
        }

        this.S.session = { username, token, guest };
        if (token) {
            this.S.auth.dismissed = true;
        }
        if (persist) {
            if (token) {
                this.saveStoredSession(this.S.session);
            } else {
                this.clearStoredSession();
            }
        }

        this.updateAuthView();
        const overlay = document.getElementById('authOverlay');
        if (overlay && token) {
            overlay.classList.remove('visible');
        }
        this.normalizeDmChatStore();
        this.renderSidebarProfile();
        this.updateContactControls();
        this.renderContacts();
        this.renderMessages();
        this.updateSendButtonState();
        if (syncNative) {
            this.syncNativeSession();
        }
        if (connectVoiceSocket && !this.nativeSupports('voice')) {
            this.connectBrowserVoiceSocket();
        }
        if (!this.sessionBootstrapInProgress) {
            this.rehydratePendingOutbox();
            this.scheduleFlushPendingOutbox(300);
        }
    }

    clearAuthInputs() {
        const usernameInput = document.getElementById('authUsername');
        const passwordInput = document.getElementById('authPassword');
        if (usernameInput) usernameInput.value = '';
        if (passwordInput) passwordInput.value = '';
    }

    updateContactControls() {
        const enabled = !!this.S.session?.token;
        const contactInput = document.getElementById('contactInput');
        if (contactInput) {
            contactInput.disabled = !enabled;
            contactInput.placeholder = enabled
                ? 'Добавить контакт'
                : 'Войдите, чтобы добавить контакт';
        }
        if (!enabled) {
            this.hideContactSuggestions();
        }
    }

    getContactSuggestions(query = '') {
        const q = String(query || '').trim().toLowerCase();
        const me = this.myName();
        const existing = new Set((this.S.contacts || []).map(u => String(u).toLowerCase()));
        return (this.S.users || [])
            .filter(Boolean)
            .filter(u => u !== me)
            .filter(u => !existing.has(String(u).toLowerCase()))
            .filter(u => !q || String(u).toLowerCase().includes(q))
            .slice(0, 8);
    }

    hideContactSuggestions() {
        const outer = document.getElementById('contactSuggestionsWrap');
        const wrap = document.getElementById('contactSuggestions');
        if (outer) outer.hidden = true;
        if (!wrap) return;
        wrap.hidden = true;
        wrap.innerHTML = '';
    }

    renderContactSuggestions(force = false) {
        const outer = document.getElementById('contactSuggestionsWrap');
        const wrap = document.getElementById('contactSuggestions');
        const input = document.getElementById('contactInput');
        if (!outer || !wrap || !input) return;

        if (!this.S.session?.token) {
            this.hideContactSuggestions();
            return;
        }

        const query = input.value || '';
        const list = this.getContactSuggestions(query);
        const hasFocus = document.activeElement === input;
        const shouldShow = force || hasFocus || query.trim().length > 0;

        if (!shouldShow || list.length === 0) {
            outer.hidden = true;
            wrap.hidden = true;
            wrap.innerHTML = '';
            return;
        }

        outer.hidden = false;
        wrap.hidden = false;
        wrap.innerHTML = list.map(username => {
            return `
                <button class="contact-suggest-item" type="button" data-username="${this.esc(username)}">
                    <div class="contact-suggest-ava">${this.renderAvatarHTML(username, 'avatar-img', username)}</div>
                    <div class="contact-suggest-meta">
                        <div class="contact-suggest-name">${this.esc(username)}</div>
                        <div class="contact-suggest-hint">Добавить и начать чат</div>
                    </div>
                    <div class="contact-suggest-plus">+</div>
                </button>
            `;
        }).join('');
    }

    setAuthMode(mode, { clearInputs = true, focus = true } = {}) {
        this.S.auth.mode = mode === 'register' ? 'register' : 'login';
        this.S.auth.error = '';
        this.S.auth.loading = false;
        this.S.auth.fieldsCleared = false;
        if (clearInputs) {
            this.clearAuthInputs();
            this.S.auth.fieldsCleared = true;
        }
        this.updateAuthView();
        if (focus) {
            const usernameInput = document.getElementById('authUsername');
            if (usernameInput) usernameInput.focus();
        }
    }

    syncNativeSession() {
        if (!this.nativeSupports('sessionSync')) return;
        this.trace(`syncNativeSession username=${this.S.session.username} tokenSet=${!!this.S.session.token}`);
        this.postNativeMessage({
            type: 'SET_SESSION',
            username: this.S.session.username,
            token: this.S.session.token || '',
            guest: this.S.session.guest,
        });
    }

    async loadContacts() {
        try {
            this.trace(`loadContacts start user=${this.myName()} tokenSet=${!!this.S.session?.token}`);
            const res = await this.apiFetch('/api/contacts');
            if (!res.ok) {
                const text = await res.text().catch(() => '');
                this.trace(`loadContacts failed status=${res.status} body=${text.slice(0, 300)}`);
                this.S.contacts = [];
                this.renderContacts();
                return;
            }
            const data = await res.json();
            const contacts = Array.isArray(data?.contacts) ? data.contacts : [];
            this.trace(`loadContacts success count=${contacts.length} contacts=${contacts.join(',')}`);
            this.setContacts(contacts);
        } catch (e) {
            this.trace(`loadContacts error=${e?.message || e}`);
            this.S.contacts = [];
            this.renderContacts();
        }
    }

    async loadUsers() {
        try {
            this.trace(`loadUsers start user=${this.myName()} tokenSet=${!!this.S.session?.token}`);
            const res = await this.apiFetch('/api/users');
            if (!res.ok) {
                const text = await res.text().catch(() => '');
                this.trace(`loadUsers failed status=${res.status} body=${text.slice(0, 300)}`);
                return;
            }
            const users = await res.json();
            this.trace(`loadUsers success count=${Array.isArray(users) ? users.length : 0} users=${Array.isArray(users) ? users.join(',') : 'invalid'}`);
            this.setUsers(users);
        } catch (e) {
            this.trace(`loadUsers error=${e?.message || e}`);
        }
    }

    async executeAuth(mode, username, password, { logAttempt = true } = {}) {
        const errorBox = document.getElementById('authError');
        this.S.auth.loading = true;
        this.updateAuthView();

        try {
            const endpoint = mode === 'register' ? '/api/auth/register' : '/api/auth/login';
            if (mode === 'register' && logAttempt) {
                this.addLogEntry({
                    type: 'INFO',
                    msg: `Попытка регистрации: ${username}`,
                    ts: new Date().toLocaleTimeString()
                });
            }

            const requestAuth = async () => {
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 12000);
                try {
                    return await fetch(`${this.getApiBaseUrl()}${endpoint}`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ username, password }),
                        signal: controller.signal,
                    });
                } finally {
                    clearTimeout(timeoutId);
                }
            };

            let res;
            let lastError = null;
            for (let attempt = 0; attempt < 2; attempt++) {
                try {
                    res = await requestAuth();
                    lastError = null;
                    break;
                } catch (err) {
                    lastError = err;
                    const msg = String(err?.message || err || '');
                    if (!/load failed|failed to fetch|network error/i.test(msg) || attempt === 1) {
                        break;
                    }
                    await new Promise(resolve => setTimeout(resolve, 250));
                }
            }

            if (!res) {
                throw lastError || new Error('Не удалось связаться с сервером');
            }

            if (mode === 'register') {
                if (!res.ok) {
                    const text = await res.text();
                    if (res.status === 409 || /Пользователь уже существует/i.test(text)) {
                        this.addLogEntry({
                            type: 'INFO',
                            msg: `Аккаунт ${username} уже есть, пробуем войти с этим паролем`,
                            ts: new Date().toLocaleTimeString()
                        });

                        const recovered = await this.executeAuth('login', username, password, { logAttempt: false });
                        if (recovered) {
                            this.addLogEntry({
                                type: 'SUCCESS',
                                msg: `Вход восстановлен для ${username}`,
                                ts: new Date().toLocaleTimeString()
                            });
                            return true;
                        }
                    }

                    this.addLogEntry({
                        type: 'WARN',
                        msg: `Регистрация отклонена для ${username}: ${text || res.status}`,
                        ts: new Date().toLocaleTimeString()
                    });
                    throw new Error(text || 'Не удалось зарегистрироваться');
                }

                const data = await res.json();
                this.applySession({
                    username: data.username || username,
                    token: data.token,
                    guest: false,
                });
                this.setAuthMode('login', { clearInputs: true, focus: false });
                await this.loadContacts();
                await this.loadUsers();

                this.addLogEntry({
                    type: 'SUCCESS',
                    msg: `Регистрация успешна, вход выполнен как ${this.myName()}`,
                    ts: new Date().toLocaleTimeString()
                });
                this.clearAuthInputs();
                return true;
            }

            if (!res.ok) {
                const text = await res.text();
                throw new Error(text || 'Не удалось войти');
            }

            const data = await res.json();
            this.applySession({
                username: data.username || username,
                token: data.token,
                guest: false,
            });
            this.setAuthMode('login', { clearInputs: true, focus: false });
            await this.loadContacts();
            await this.loadUsers();
            this.clearAuthInputs();
            this.addLogEntry({ type: 'SUCCESS', msg: `Вход выполнен как ${this.myName()}`, ts: new Date().toLocaleTimeString() });
            return true;
        } catch (e) {
            const raw = e.message || 'Ошибка входа';
            const apiBaseUrl = this.getApiBaseUrl();
            const friendly = /load failed|failed to fetch|network error/i.test(raw)
                ? `Не удалось связаться с сервером (${apiBaseUrl}). Проверь адрес или запусти backend.`
                : raw;
            this.S.auth.error = friendly;
            if (errorBox) errorBox.textContent = friendly;
            if (mode === 'register') {
                this.addLogEntry({
                    type: 'ERROR',
                    msg: `Ошибка регистрации для ${username}: ${friendly}`,
                    ts: new Date().toLocaleTimeString()
                });
            }
            return false;
        } finally {
            this.S.auth.loading = false;
            this.updateAuthView();
        }
    }

    async submitAuth(mode) {
        if (this.S.auth.loading) {
            return;
        }

        const usernameInput = document.getElementById('authUsername');
        const passwordInput = document.getElementById('authPassword');
        const username = (usernameInput?.value || '').trim();
        const password = passwordInput?.value || '';
        const errorBox = document.getElementById('authError');

        if (errorBox) errorBox.textContent = '';
        this.S.auth.error = '';
        if (!username || !password) {
            const msg = 'Введите логин и пароль';
            this.S.auth.error = msg;
            if (errorBox) errorBox.textContent = msg;
            return;
        }

        if (mode === 'register') {
            if (username.length > 64) {
                const msg = 'Логин слишком длинный: максимум 64 символа';
                this.S.auth.error = msg;
                if (errorBox) errorBox.textContent = msg;
                this.addLogEntry({ type: 'WARN', msg: `Регистрация отклонена для ${username}: ${msg}`, ts: new Date().toLocaleTimeString() });
                return;
            }

            if (password.length < 6) {
                const msg = 'Пароль должен быть не менее 6 символов';
                this.S.auth.error = msg;
                if (errorBox) errorBox.textContent = msg;
                this.addLogEntry({ type: 'WARN', msg: `Регистрация отклонена для ${username}: ${msg}`, ts: new Date().toLocaleTimeString() });
                return;
            }
        }

        const authApiBaseUrl = document.getElementById('authApiBaseUrl');
        const typedApiBaseUrl = String(authApiBaseUrl?.value || '').trim();
        if (typedApiBaseUrl) {
            try {
                const current = this.loadNetworkConfig();
                const typedWsBaseUrl = this.deriveWsBaseUrl(typedApiBaseUrl);
                if (typedApiBaseUrl !== current.apiBaseUrl || typedWsBaseUrl !== current.wsBaseUrl) {
                    this.setNetworkConfig({
                        apiBaseUrl: typedApiBaseUrl,
                        wsBaseUrl: typedWsBaseUrl,
                        iceServers: current.iceServers,
                    });
                }
            } catch (e) {
                const msg = e?.message || 'Не удалось сохранить адрес сервера';
                this.S.auth.error = msg;
                if (errorBox) errorBox.textContent = msg;
                return;
            }
        }

        return this.executeAuth(mode, username, password);
    }

    continueAsGuest() {
        this.S.auth.dismissed = true;
        this.S.auth.error = '';
        this.clearAuthInputs();
        this.S.auth.fieldsCleared = true;
        this.applySession({ username: 'Zalikus', token: null, guest: true }, { persist: false });
        this.loadContacts();
        this.updateAuthView();
    }

    async logout() {
        this.S.auth.dismissed = false;
        this.S.auth.error = '';
        this.setAuthMode('login', { clearInputs: true, focus: false });
        this.clearStoredSession();
        this.applySession({ username: 'Zalikus', token: null, guest: true }, { persist: false, syncNative: false, connectVoiceSocket: false });
        this.S.contacts = [];
        this.S.users = [];
        this.S.current = null;
        this.resetVoiceState({ preserveInvite: false });
        this.disconnectBrowserVoiceSocket();
        this.renderContacts();
        this.renderMessages();
        this.updateAuthView();
        this.addLogEntry({ type: 'WARN', msg: 'Сеанс завершён', ts: new Date().toLocaleTimeString() });
    }

    async addContactFromInput(usernameOverride = null) {
        if (!this.S.session?.token) {
            const msg = 'Сначала войдите в аккаунт, чтобы добавлять контакты';
            this.addLogEntry({ type: 'WARN', msg, ts: new Date().toLocaleTimeString() });
            this.S.auth.error = msg;
            this.updateAuthView();
            return;
        }

        const input = document.getElementById('contactInput');
        const username = (usernameOverride ?? input?.value ?? '').trim();
        if (!username) return;

        try {
            const res = await this.apiFetch('/api/contacts', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username }),
            });
            if (!res.ok) {
                const text = await res.text();
                throw new Error(text || 'Не удалось добавить контакт');
            }
            const data = await res.json();
            this.setContacts(Array.isArray(data?.contacts) ? data.contacts : []);
            if (input) input.value = '';
            this.hideContactSuggestions();
            this.addLogEntry({ type: 'SUCCESS', msg: `Контакт добавлен: ${username}`, ts: new Date().toLocaleTimeString() });
        } catch (e) {
            this.addLogEntry({ type: 'ERROR', msg: e.message || 'Не удалось добавить контакт', ts: new Date().toLocaleTimeString() });
        }
    }

    async removeContact(username) {
        if (!this.S.session?.token) {
            this.addLogEntry({ type: 'WARN', msg: 'Удаление контактов доступно только после входа', ts: new Date().toLocaleTimeString() });
            return;
        }
        try {
            const res = await this.apiFetch(`/api/contacts/${encodeURIComponent(username)}`, { method: 'DELETE' });
            if (!res.ok) {
                const text = await res.text();
                throw new Error(text || 'Не удалось удалить контакт');
            }
            const data = await res.json();
            this.setContacts(Array.isArray(data?.contacts) ? data.contacts : []);
        } catch (e) {
            this.addLogEntry({ type: 'ERROR', msg: e.message || 'Не удалось удалить контакт', ts: new Date().toLocaleTimeString() });
        }
    }

    updateAuthView() {
        const overlay = document.getElementById('authOverlay');
        if (overlay) {
            const shouldShow = !this.S.session?.token && !this.S.auth.dismissed;
            overlay.classList.toggle('visible', shouldShow);
        }

        const authTitle = document.getElementById('authTitle');
        const authHint = document.getElementById('authHint');
        const authError = document.getElementById('authError');
        const loginBtn = document.getElementById('authLoginBtn');
        const regBtn = document.getElementById('authRegisterBtn');
        const guestBtn = document.getElementById('authGuestBtn');
        if (authTitle) authTitle.textContent = this.S.auth.mode === 'register' ? 'Создание аккаунта' : 'Вход в аккаунт';
        if (authHint) authHint.textContent = this.S.auth.mode === 'register'
            ? 'Зарегистрируйтесь, чтобы сохранить контакты и историю.'
            : 'Войдите, чтобы синхронизировать сообщения и контакты.';
        if (authError) authError.textContent = this.S.auth.error || '';
        if (loginBtn) loginBtn.textContent = this.S.auth.loading
            ? 'Входим...'
            : (this.S.auth.mode === 'register' ? 'Создать аккаунт' : 'Войти');
        if (regBtn) regBtn.textContent = this.S.auth.mode === 'register' ? 'Уже есть аккаунт' : 'Создать аккаунт';
        if (loginBtn) loginBtn.disabled = this.S.auth.loading;
        if (regBtn) regBtn.disabled = this.S.auth.loading;
        if (guestBtn) guestBtn.disabled = this.S.auth.loading;
        this.syncAuthNetworkInput();
        if (!this.S.session?.token && overlay && overlay.classList.contains('visible') && !this.S.auth.fieldsCleared && !this.S.auth.loading) {
            this.clearAuthInputs();
            this.S.auth.fieldsCleared = true;
        }
        this.renderSidebarProfile();
    }

    initChat(name) { 
        if (!this.S.chats[name]) this.S.chats[name] = []; 
    }

    ensureContact(name) {
        if (!name || name === this.myName()) return;
        if (!this.S.contacts.includes(name)) {
            this.S.contacts = [name, ...this.S.contacts];
        }
        this.initChat(name);
    }

    normalizeAttachment(att = {}) {
        const mimeType = att.mimeType || att.mime_type || '';
        const kind = att.kind || (
            mimeType.startsWith('video/') ? 'video' :
            mimeType === 'image/gif' ? 'gif' :
            mimeType.startsWith('image/') ? 'image' : 'file'
        );
        return {
            id: att.id || `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
            name: att.name || 'attachment',
            mimeType,
            kind,
            size: Number(att.size || 0),
            dataUrl: att.dataUrl || att.data_url || att.url || '',
            archivePath: att.archivePath || att.archive_path || '',
        };
    }

    normalizeAttachments(attachments) {
        return Array.isArray(attachments) ? attachments.map(att => this.normalizeAttachment(att)) : [];
    }

    formatFileSize(bytes) {
        const size = Number(bytes || 0);
        if (!Number.isFinite(size) || size <= 0) return '0 B';
        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        let value = size;
        let unitIndex = 0;
        while (value >= 1024 && unitIndex < units.length - 1) {
            value /= 1024;
            unitIndex += 1;
        }
        const precision = unitIndex === 0 ? 0 : value < 10 ? 1 : 0;
        return `${value.toFixed(precision)} ${units[unitIndex]}`;
    }

    inferMimeType(file) {
        if (file && file.type) return file.type;
        const name = (file && file.name || '').toLowerCase();
        if (name.endsWith('.png')) return 'image/png';
        if (name.endsWith('.jpg') || name.endsWith('.jpeg')) return 'image/jpeg';
        if (name.endsWith('.webp')) return 'image/webp';
        if (name.endsWith('.gif')) return 'image/gif';
        if (name.endsWith('.mp4')) return 'video/mp4';
        if (name.endsWith('.webm')) return 'video/webm';
        return 'application/octet-stream';
    }

    fileToDataUrl(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(String(reader.result || ''));
            reader.onerror = () => reject(reader.error || new Error('Не удалось прочитать файл'));
            reader.readAsDataURL(file);
        });
    }

    async fileToAttachment(file) {
        const mimeType = this.inferMimeType(file);
        const kind = mimeType.startsWith('video/') ? 'video' : mimeType === 'image/gif' ? 'gif' : mimeType.startsWith('image/') ? 'image' : 'file';
        const dataUrl = await this.fileToDataUrl(file);
        return this.normalizeAttachment({
            name: file.name,
            mimeType,
            kind,
            size: file.size,
            dataUrl,
        });
    }

    async handleFiles(fileList) {
        const files = Array.from(fileList || []);
        if (files.length === 0) return;
        const attachments = await Promise.all(files.map(file => this.fileToAttachment(file)));
        this.S.draftAttachments = this.S.draftAttachments.concat(attachments);
        this.renderDraftAttachments();
        this.updateSendButtonState();
    }

    clearDraftAttachments() {
        this.S.draftAttachments = [];
        this.renderDraftAttachments();
        this.updateSendButtonState();
    }

    renderDraftAttachments() {
        const wrap = document.getElementById('draftAttachments');
        if (!wrap) return;

        if (!this.S.draftAttachments.length) {
            wrap.innerHTML = '';
            wrap.classList.remove('has-items');
            return;
        }

        wrap.classList.add('has-items');
        wrap.innerHTML = this.S.draftAttachments.map(att => {
            const thumb = this.renderAttachmentPreview(att, true);
            return `<div class="draft-att" data-att-id="${this.esc(att.id)}">
                <button class="draft-att-remove" type="button" data-att-id="${this.esc(att.id)}" title="Удалить вложение">×</button>
                ${thumb}
                <div class="draft-att-name">${this.esc(att.name)}</div>
            </div>`;
        }).join('');
    }

    resizeComposer() {
        const inp = document.getElementById('msgInput');
        if (!inp) return;
        inp.style.height = 'auto';
        inp.style.height = `${Math.min(inp.scrollHeight, 140)}px`;
    }

    extractUrls(text) {
        if (!text) return [];
        const re = /https?:\/\/[^\s<>()"]+/gi;
        return String(text).match(re) || [];
    }

    isTenorUrl(url) {
        try {
            const u = new URL(url);
            return /(^|\.)tenor\.com$/.test(u.hostname) || /(^|\.)media\d*\.tenor\.com$/.test(u.hostname) || /(^|\.)c\.tenor\.com$/.test(u.hostname);
        } catch (e) {
            return false;
        }
    }

    tenorCacheKey(url) {
        return `tenor:${url}`;
    }

    requestTenorResolution(url) {
        const key = this.tenorCacheKey(url);
        if (this.tenorCache.has(key) || this.tenorPending.has(key)) return;
        this.tenorPending.add(key);

        if (this.nativeSupports('tenor')) {
            this.postNativeMessage({
                type: 'RESOLVE_TENOR',
                url,
                requestId: key,
            });
        } else {
            this.tenorPending.delete(key);
        }
    }

    onTenorResolved(payload) {
        let data = payload;
        if (typeof payload === 'string') {
            try {
                data = JSON.parse(payload);
            } catch (e) {
                return;
            }
        }

        if (!data || !data.sourceUrl) return;
        const key = this.tenorCacheKey(data.sourceUrl);
        this.tenorPending.delete(key);

        if (data.mediaUrl) {
            this.tenorCache.set(key, {
                mediaUrl: data.mediaUrl,
                mimeType: data.mimeType || '',
                kind: data.kind || '',
            });
            this.renderMessages();
            this.renderContacts();
        }
    }

    isDirectMediaUrl(url) {
        try {
            const u = new URL(url);
            return /\.(gif|png|jpe?g|webp|mp4|webm)(\?.*)?$/i.test(u.pathname);
        } catch (e) {
            return false;
        }
    }

    renderMessageText(text) {
        const urls = this.extractUrls(text);
        if (!urls.length) {
            return this.esc(text).replace(/\n/g, '<br>');
        }

        const escaped = this.esc(text).replace(/\n/g, '<br>');
        return escaped.replace(/https?:\/\/[^\s<>()"]+/gi, (match) => {
            const safe = this.esc(match);
            return `<a href="${safe}" target="_blank" rel="noopener noreferrer">${safe}</a>`;
        });
    }

    mediaAspectRatioForSrc(src, fallback = '1 / 1') {
        const cached = this.mediaSizeCache.get(src);
        if (cached?.width && cached?.height) {
            return `${cached.width} / ${cached.height}`;
        }
        return fallback;
    }

    renderAttachmentPreview(att, compact = false, options = {}) {
        const attachment = this.normalizeAttachment(att);
        const src = attachment.dataUrl || attachment.url || '';
        const gifLike = !!options.gifLike || attachment.kind === 'gif' || attachment.mimeType === 'image/gif';
        const showControls = options.controls !== undefined ? !!options.controls : !gifLike;
        if (!src) {
            return `<div class="media-unknown">${this.esc(attachment.name)}</div>`;
        }

        if (attachment.kind === 'video' || (attachment.mimeType || '').startsWith('video/')) {
            const shellClass = `discord-media-shell discord-media-shell-video${gifLike ? ' discord-media-shell-gif' : ''}${compact ? ' compact' : ''}`;
            const shellStyle = gifLike
                ? ` style="aspect-ratio: ${this.mediaAspectRatioForSrc(src)};"`
                : '';
            return `<div class="${shellClass}"${shellStyle}>
                <video class="media media-video${compact ? ' compact' : ''}${gifLike ? ' media-gif-like' : ''}" data-gif-like="${gifLike ? '1' : '0'}" src="${this.esc(src)}"${showControls ? ' controls' : ''} autoplay loop muted playsinline preload="${gifLike ? 'auto' : 'metadata'}"></video>
            </div>`;
        }

        if (attachment.kind === 'gif' || attachment.mimeType === 'image/gif' || (attachment.mimeType || '').startsWith('image/')) {
            const gifClass = gifLike ? ' media-gif-like' : '';
            const shellGifClass = gifLike ? ' discord-media-shell-gif' : '';
            const shellStyle = gifLike
                ? ` style="aspect-ratio: ${this.mediaAspectRatioForSrc(src)};"`
                : '';
            return `<div class="discord-media-shell discord-media-shell-image${shellGifClass}${compact ? ' compact' : ''}"${shellStyle}>
                <img class="media media-img${compact ? ' compact' : ''}${gifClass}" src="${this.esc(src)}" alt="${this.esc(attachment.name)}" loading="eager" decoding="async" fetchpriority="high">
            </div>`;
        }

        const sizeLabel = this.formatFileSize(attachment.size);
        if (compact) {
            return `<a class="file-chip${compact ? ' compact' : ''}" href="${this.esc(src)}" download="${this.esc(attachment.name)}">
                <span class="file-chip-name">${this.esc(attachment.name)}</span>
                <span class="file-chip-size">${this.esc(sizeLabel)}</span>
            </a>`;
        }

        return `<a class="file-message" href="${this.esc(src)}" download="${this.esc(attachment.name)}">
            <span class="file-message-name">${this.esc(attachment.name)}</span>
            <span class="file-message-size">${this.esc(sizeLabel)}</span>
        </a>`;
    }

    hydrateGifMedia(root = document) {
        const videos = root.querySelectorAll?.('video.media-gif-like[data-gif-like="1"]') || [];
        videos.forEach(video => {
            if (!(video instanceof HTMLMediaElement)) return;
            if (video.dataset.gifBound === '1') return;

            video.dataset.gifBound = '1';
            video.loop = true;
            video.muted = true;
            video.playsInline = true;
            video.preload = 'auto';
            video.style.backgroundColor = 'transparent';
            video.style.objectFit = 'contain';
            video.style.width = '100%';
            video.style.height = '100%';

            const shell = video.closest('.discord-media-shell');
            const src = video.currentSrc || video.src || video.getAttribute('src') || '';
            const cacheSize = (width, height) => {
                if (!src || !width || !height) return;
                this.mediaSizeCache.set(src, { width, height });
            };

            const ensurePlaying = () => {
                if (video.dataset.userPaused === '1') return;
                if (video.paused) {
                    video.play?.().catch(() => {});
                }
            };

            const syncFromMetadata = () => {
                const width = Number(video.videoWidth || 0);
                const height = Number(video.videoHeight || 0);
                cacheSize(width, height);
                ensurePlaying();
            };

            video.addEventListener('loadedmetadata', syncFromMetadata, { once: true });
            video.addEventListener('loadeddata', syncFromMetadata, { once: true });

            if (window.IntersectionObserver) {
                const observer = new IntersectionObserver((entries) => {
                    const entry = entries[0];
                    if (!entry) return;
                    if (video.dataset.userPaused === '1') return;
                    if (entry.isIntersecting) {
                        ensurePlaying();
                    }
                }, { root: null, threshold: 0.15, rootMargin: '160px' });
                observer.observe(video);
                video.dataset.gifObserver = '1';
                return;
            }

            ensurePlaying();
        });

        const images = root.querySelectorAll?.('img.media-gif-like:not([data-gif-like="1"])') || [];
        images.forEach(img => {
            if (!(img instanceof HTMLImageElement)) return;
            if (img.dataset.gifBound === '1') return;
            img.dataset.gifBound = '1';
            const shell = img.closest('.discord-media-shell');
            const src = img.currentSrc || img.src || img.getAttribute('src') || '';
            const cacheSize = (width, height) => {
                if (!src || !width || !height) return;
                this.mediaSizeCache.set(src, { width, height });
            };
            const syncFromImage = () => {
                const width = Number(img.naturalWidth || 0);
                const height = Number(img.naturalHeight || 0);
                cacheSize(width, height);
            };
            if (img.complete) {
                syncFromImage();
            } else {
                img.addEventListener('load', syncFromImage, { once: true });
            }
        });
    }

    renderUrlPreview(url) {
        if (!url) return '';
        let path = '';
        try {
            path = new URL(url).pathname.toLowerCase();
        } catch (e) {
            path = url.toLowerCase();
        }

        if (this.isTenorUrl(url)) {
            if (this.isDirectMediaUrl(url)) {
                return this.renderAttachmentPreview({
                    name: 'Tenor',
                    mimeType: path.endsWith('.mp4') ? 'video/mp4' : path.endsWith('.webm') ? 'video/webm' : 'image/gif',
                    kind: path.endsWith('.mp4') || path.endsWith('.webm') ? 'video' : 'gif',
                    dataUrl: url
                }, false, { gifLike: true });
            }

            const cached = this.tenorCache.get(this.tenorCacheKey(url));
            if (cached?.mediaUrl) {
                const mimeType = cached.mimeType || (path.endsWith('.mp4') ? 'video/mp4' : 'image/gif');
                const kind = cached.kind || (mimeType.startsWith('video/') ? 'video' : 'gif');
                return this.renderAttachmentPreview({
                    name: 'Tenor',
                    mimeType,
                    kind,
                    dataUrl: cached.mediaUrl
                }, false, { gifLike: true });
            }

            this.requestTenorResolution(url);
            return `<div class="media media-tenor media-tenor-pending">
                <div class="tenor-badge">Tenor GIF</div>
                <div class="tenor-hint">Загружаем анимацию...</div>
            </div>`;
        }

        if (this.isDirectMediaUrl(url)) {
            return this.renderAttachmentPreview({
                name: url.split('/').pop() || 'media',
                mimeType: path.endsWith('.mp4') ? 'video/mp4' : path.endsWith('.webm') ? 'video/webm' : path.endsWith('.gif') ? 'image/gif' : 'image/*',
                kind: path.endsWith('.mp4') || path.endsWith('.webm') ? 'video' : 'image',
                dataUrl: url
            });
        }

        return '';
    }

    renderMessageBody(msg) {
        if (msg?.kind === 'call') {
            return this.renderCallMessage(msg);
        }
        const attachments = this.normalizeAttachments(msg.attachments);
        const urls = this.extractUrls(msg.text);
        const isOnlyUrl = (msg.text || '').trim() && urls.length === 1 && (msg.text || '').trim() === urls[0];
        const previewBlocks = urls.map(url => this.renderUrlPreview(url)).filter(Boolean);
        const bodyParts = [];

        if (!isOnlyUrl || previewBlocks.length === 0 || (msg.text || '').trim() !== urls[0]) {
            if (msg.text) {
                bodyParts.push(`<div class="msg-text">${this.renderMessageText(msg.text)}</div>`);
            }
        }

        if (attachments.length) {
            bodyParts.push(`<div class="msg-attachments">${attachments.map(att => this.renderAttachmentPreview(att)).join('')}</div>`);
        }

        if (previewBlocks.length) {
            bodyParts.push(`<div class="msg-attachments msg-link-previews">${previewBlocks.join('')}</div>`);
        }

        return bodyParts.join('');
    }

    renderCallMessage(msg) {
        const call = msg?.call || {};
        const direction = String(call.direction || '').trim() || (this.isOutgoingMessage(msg) ? 'outgoing' : 'incoming');
        const outcome = String(call.outcome || '').trim() || 'completed';
        const peer = String(call.peer || msg.receiver || msg.sender || '').trim();
        const startedAt = call.connectedAt || call.startedAt || msg.timestamp;
        const endedAt = call.endedAt || msg.timestamp;
        const durationMs = Number(call.durationMs || 0) || 0;
        const whenLabel = this.fmtDate(startedAt);
        const timeLabel = this.fmtTime(startedAt || endedAt);
        const durationLabel = this.formatDuration(durationMs);
        const title = outcome === 'missed'
            ? `Пропущенный звонок`
            : outcome === 'rejected'
                ? `Звонок отклонён`
                : outcome === 'cancelled'
                    ? `Звонок отменён`
                    : direction === 'outgoing'
                        ? `Исходящий звонок`
                        : `Входящий звонок`;
        const subject = direction === 'outgoing'
            ? `К ${peer || 'контакту'}`
            : `От ${peer || 'контакта'}`;
        const durationText = durationLabel === '00:00' && outcome !== 'completed'
            ? '00:00'
            : durationLabel;
        return `
            <div class="call-card ${this.esc(outcome)} ${this.esc(direction)}">
                <div class="call-card-top">
                    <div class="call-card-icon">${outcome === 'completed' ? '📞' : '⨯'}</div>
                    <div class="call-card-copy">
                        <div class="call-card-title">${this.esc(title)}</div>
                        <div class="call-card-sub">${this.esc(subject)}</div>
                    </div>
                </div>
                <div class="call-card-meta">
                    <span>Когда: ${this.esc(whenLabel ? `${whenLabel}, ${timeLabel}` : timeLabel)}</span>
                    <span>Длительность: ${this.esc(durationText)}</span>
                </div>
            </div>
        `;
    }

    messageHasMedia(msg) {
        const attachments = this.normalizeAttachments(msg.attachments);
        if (attachments.some(att => att.kind === 'image' || att.kind === 'video' || att.kind === 'gif' || (att.mimeType || '').startsWith('image/') || (att.mimeType || '').startsWith('video/'))) {
            return true;
        }
        const urls = this.extractUrls(msg.text);
        return urls.some(url => this.isTenorUrl(url) || this.isDirectMediaUrl(url));
    }

    messageIsGifOnly(msg) {
        const text = (msg.text || '').trim();
        if (text) return false;

        const attachments = this.normalizeAttachments(msg.attachments);
        if (attachments.length > 0) {
            return attachments.every(att =>
                att.kind === 'gif' ||
                att.mimeType === 'image/gif' ||
                (att.mimeType || '').startsWith('image/')
            );
        }

        const urls = this.extractUrls(msg.text);
        if (urls.length !== 1) return false;

        const url = urls[0];
        if (!this.isTenorUrl(url) && !this.isDirectMediaUrl(url)) return false;
        const path = (() => {
            try { return new URL(url).pathname.toLowerCase(); }
            catch (e) { return url.toLowerCase(); }
        })();
        return path.endsWith('.gif') || this.isTenorUrl(url);
    }

    messageSummary(msg) {
        if (msg?.kind === 'call') {
            const call = msg.call || {};
            const direction = String(call.direction || '').trim();
            const outcome = String(call.outcome || '').trim();
            const peer = String(call.peer || msg.receiver || msg.sender || '').trim();
            const duration = this.formatDuration(call.durationMs || 0);
            if (outcome === 'missed') return `Пропущенный звонок${peer ? ` · ${peer}` : ''}`;
            if (outcome === 'rejected') return `Отклонённый звонок${peer ? ` · ${peer}` : ''}`;
            if (outcome === 'cancelled') return `Отменённый звонок${peer ? ` · ${peer}` : ''}`;
            return `Звонок${peer ? ` · ${peer}` : ''}${duration ? ` · ${duration}` : ''}`;
        }
        const attachments = this.normalizeAttachments(msg.attachments);
        if (attachments.length) {
            const first = attachments[0];
            if (first.kind === 'video' || first.mimeType.startsWith('video/')) return 'Видео';
            if (first.kind === 'gif' || first.mimeType === 'image/gif') return 'GIF';
            if (first.mimeType.startsWith('image/')) return 'Фото';
            return 'Файл';
        }

        const urls = this.extractUrls(msg.text);
        if (urls.some(url => this.isTenorUrl(url))) {
            return 'Tenor GIF';
        }

        const text = (msg.text || '').trim();
        if (!text) return 'Сообщение';
        return text.length > 32 ? `${text.slice(0, 32)}…` : text;
    }

    messageRenderKey(msg) {
        if (!msg || typeof msg !== 'object') return '';
        if (msg.clientId) return `cid:${msg.clientId}`;
        if (msg.id) return `id:${msg.id}`;
        const attachments = this.normalizeAttachments(msg.attachments);
        const attachmentKey = attachments
            .map(att => `${att.name}:${att.kind}:${att.size}:${att.mimeType}`)
            .join('|');
        const call = msg.kind === 'call' ? msg.call || {} : {};
        return [
            msg.kind || '',
            msg.sender || '',
            msg.receiver || '',
            msg.timestamp || '',
            msg.text || '',
            call.roomId || '',
            call.direction || '',
            call.outcome || '',
            call.peer || '',
            call.durationMs || '',
            attachmentKey,
        ].join('::');
    }

    normalizeReactions(reactions) {
        if (!reactions) return [];
        const list = Array.isArray(reactions)
            ? reactions
            : Object.entries(reactions).map(([emoji, count]) => ({ emoji, count }));
        return list
            .map(item => ({
                emoji: String(item?.emoji || '').trim(),
                count: Number(item?.count || 0) || 0,
            }))
            .filter(item => item.emoji && item.count > 0)
            .sort((a, b) => b.count - a.count || a.emoji.localeCompare(b.emoji));
    }

    findMessageById(messageId) {
        const id = String(messageId || '').trim();
        if (!id) return null;
        for (const [peer, msgs] of Object.entries(this.S.chats)) {
            const index = msgs.findIndex(msg => String(msg.id || '').trim() === id || String(msg.clientId || '').trim() === id);
            if (index >= 0) {
                return { peer, msg: msgs[index], index };
            }
        }
        for (const [key, msgs] of Object.entries(this.S.serverChats || {})) {
            const index = msgs.findIndex(msg => String(msg.id || '').trim() === id || String(msg.clientId || '').trim() === id);
            if (index >= 0) {
                return { peer: key, msg: msgs[index], index, serverKey: key };
            }
        }
        return null;
    }

    renderMessageReactions(msg) {
        const messageId = String(msg?.id || '').trim();
        if (!messageId) return '';

        const reactions = this.normalizeReactions(msg.reactions);
        const myReaction = String(msg.myReaction || '').trim();
        return reactions.length
            ? `<div class="reaction-row">
                ${reactions.map(reaction => {
                    const mine = myReaction && myReaction === reaction.emoji ? ' mine' : '';
                    return `<span class="reaction-chip${mine}" title="${this.esc(reaction.emoji)}">
                        <span class="reaction-emoji">${this.esc(reaction.emoji)}</span>
                        <span class="reaction-count">${reaction.count}</span>
                    </span>`;
                }).join('')}
            </div>`
            : '';
    }

    ensureReactionMenu() {
        let menu = document.getElementById('reactionMenu');
        if (menu) return menu;
        menu = document.createElement('div');
        menu.id = 'reactionMenu';
        menu.className = 'reaction-menu';
        menu.setAttribute('aria-hidden', 'true');
        menu.innerHTML = this.reactionOptions.map(emoji => (
            `<button class="reaction-btn" type="button" data-menu-reaction="${this.esc(emoji)}">${this.esc(emoji)}</button>`
        )).join('');
        document.body.appendChild(menu);

        menu.addEventListener('click', (e) => {
            const btn = e.target.closest('[data-menu-reaction]');
            if (!btn) return;
            const emoji = btn.getAttribute('data-menu-reaction');
            const messageId = menu.getAttribute('data-message-id');
            if (messageId && emoji) {
                this.addReaction(messageId, emoji);
            }
            this.hideReactionMenu();
        });

        return menu;
    }

    showReactionMenu(messageEl, messageId, x, y) {
        const menu = this.ensureReactionMenu();
        if (!menu || !messageEl) return;
        menu.setAttribute('data-message-id', messageId);
        menu.classList.add('visible');
        menu.setAttribute('aria-hidden', 'false');
        menu.style.left = '0px';
        menu.style.top = '0px';
        const rect = menu.getBoundingClientRect();
        const pad = 12;
        const maxLeft = window.innerWidth - rect.width - pad;
        const maxTop = window.innerHeight - rect.height - pad;
        const left = Math.max(pad, Math.min(x, maxLeft));
        const top = Math.max(pad, Math.min(y, maxTop));
        menu.style.left = `${left}px`;
        menu.style.top = `${top}px`;
    }

    hideReactionMenu() {
        const menu = document.getElementById('reactionMenu');
        if (!menu) return;
        menu.classList.remove('visible');
        menu.setAttribute('aria-hidden', 'true');
        menu.removeAttribute('data-message-id');
    }

    markMessageSeen(msg) {
        const key = this.messageRenderKey(msg);
        if (key) this.messageAnimSeen.add(key);
    }

    markMessageStatus(clientId, status) {
        if (!clientId) return;
        let updated = false;
        for (const peer of Object.keys(this.S.chats)) {
            const msgs = this.S.chats[peer];
            for (let i = msgs.length - 1; i >= 0; i--) {
                if (msgs[i].clientId === clientId) {
                    msgs[i].status = status;
                    if (status === 'error') msgs[i].error = true;
                    updated = true;
                    break;
                }
            }
            // No visible status badges in the message UI, so avoid full rerender.
            // The data is still updated for persistence / history consistency.
            if (updated) break;
        }
        if (!updated) {
            for (const key of Object.keys(this.S.serverChats || {})) {
                const msgs = this.S.serverChats[key];
                for (let i = msgs.length - 1; i >= 0; i--) {
                    if (msgs[i].clientId === clientId) {
                        msgs[i].status = status;
                        if (status === 'error') msgs[i].error = true;
                        updated = true;
                        break;
                    }
                }
                if (updated) break;
            }
        }
    }

    finalizePendingMessage(clientId, messageId) {
        const pendingId = String(clientId || '').trim();
        if (!pendingId) return false;
        const serverId = String(messageId || '').trim();
        let updated = false;
        for (const peer of Object.keys(this.S.chats)) {
            const msgs = this.S.chats[peer];
            for (let i = msgs.length - 1; i >= 0; i--) {
                if (String(msgs[i].clientId || '').trim() === pendingId) {
                    msgs[i].status = 'sent';
                    if (serverId) msgs[i].id = serverId;
                    updated = true;
                    break;
                }
            }
            if (updated) break;
        }
        if (!updated) {
            for (const key of Object.keys(this.S.serverChats || {})) {
                const msgs = this.S.serverChats[key];
                for (let i = msgs.length - 1; i >= 0; i--) {
                    if (String(msgs[i].clientId || '').trim() === pendingId) {
                        msgs[i].status = 'sent';
                        if (serverId) msgs[i].id = serverId;
                        updated = true;
                        break;
                    }
                }
                if (updated) break;
            }
        }
        if (updated) {
            this.renderMessages();
        }
        return updated;
    }

    applyLocalReaction(found, emoji) {
        if (!found || !found.msg) return;
        const message = found.msg;
        const current = String(message.myReaction || '').trim();
        const next = current === emoji ? '' : emoji;
        const map = new Map(this.normalizeReactions(message.reactions).map(item => [item.emoji, item.count]));

        if (current && map.has(current)) {
            const nextCount = (map.get(current) || 0) - 1;
            if (nextCount > 0) map.set(current, nextCount);
            else map.delete(current);
        }
        if (next) {
            map.set(next, (map.get(next) || 0) + 1);
        }

        message.myReaction = next;
        message.reactions = Array.from(map.entries())
            .map(([reactionEmoji, count]) => ({ emoji: reactionEmoji, count }))
            .sort((a, b) => b.count - a.count || a.emoji.localeCompare(b.emoji));

        const shouldRender = found.serverKey
            ? found.serverKey === this.currentServerChatKey()
            : found.peer === this.S.current;
        if (shouldRender) {
            this.renderMessages();
        }
    }

    async addReaction(messageId, emoji) {
        const id = String(messageId || '').trim();
        const reaction = String(emoji || '').trim();
        if (!id || !reaction) return;

        const found = this.findMessageById(id);
        if (!found) return;

        const current = String(found.msg.myReaction || '').trim();
        const next = current === reaction ? '' : reaction;

        const hasRealServerId = !!found.msg.id && (!found.msg.clientId || String(found.msg.id) !== String(found.msg.clientId));
        if (!hasRealServerId) {
            this.applyLocalReaction(found, reaction);
            return;
        }

        try {
            const res = await this.apiFetch(`/api/message/${encodeURIComponent(found.msg.id)}/reaction`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ emoji: next }),
            });

            if (!res.ok) {
                throw new Error(await res.text() || 'Не удалось поставить реакцию');
            }

            const payload = await res.json();
            this.onReactionUpdated(payload);
        } catch (e) {
            this.addLogEntry({ type: 'ERROR', msg: `Реакция не отправлена: ${e.message || e}`, ts: new Date().toLocaleTimeString() });
            this.applyLocalReaction(found, reaction);
        }
    }

    // --- DOM Rendering Methods ---

    renderContacts() {
        const el = document.getElementById('contacts');
        if (!el) return;
        this.updateSidebarModeLabel();
        if (this.S.navMode === 'servers') {
            this.renderServers(el);
            return;
        }
        const q = this.S.searchQ.toLowerCase();
        const list = this.S.contacts.filter(u => u !== this.myName() && (!q || u.toLowerCase().includes(q)));

        if (list.length === 0) {
            el.innerHTML = `<div style="text-align:center;color:var(--text3);font-size:11px;padding:24px 0">${q ? 'Ничего не найдено' : 'Добавьте первый контакт'}</div>`;
            return;
        }

        el.innerHTML = list.map(u => {
            this.initChat(u);
            const msgs = this.S.chats[u];
            const last = msgs[msgs.length-1];
            let preview = '<span style="color:var(--text3);font-style:italic;font-size:10px">Начните диалог...</span>';
            if (last) {
                const who = last.sender === this.myName() ? 'Вы: ' : '';
                preview = who + this.esc(this.messageSummary(last));
            }
            const cnt = this.S.unread[u] || 0;
            const badge = cnt > 0 ? `<div class="badge">${cnt > 99 ? '99+' : cnt}</div>` : '';
            const active = u === this.S.current ? 'active' : '';
            return `<div class="contact ${active}" data-name="${this.esc(u)}">
                <div class="ava">${this.renderAvatarHTML(u, 'avatar-img', u)}</div>
                <div class="contact-info">
                    <div class="contact-name">${this.esc(u)}</div>
                    <div class="contact-prev">${preview}</div>
                </div>
                <button class="contact-remove" type="button" data-remove-contact="${this.esc(u)}" title="Удалить контакт">×</button>
                ${badge}
            </div>`;
        }).join('');
    }

    renderServers(el = null) {
        const target = el || document.getElementById('contacts');
        if (!target) return;
        this.ensureServersState();
        const q = this.S.searchQ.toLowerCase();
        const list = (this.S.servers || [])
            .filter(Boolean)
            .filter(server => {
                const haystack = `${server.name || ''} ${server.description || server.hint || ''}`.toLowerCase();
                return !q || haystack.includes(q);
            });

        const createTile = `
            <button class="server-item server-create" type="button" id="createServerBtn" title="Создать сервер" aria-label="Создать сервер">
                <span class="server-avatar server-create-plus">+</span>
                <div class="server-meta">
                    <div class="server-name">Создать сервер</div>
                    <div class="server-prev">Новый сервер, команда или сообщество</div>
                </div>
            </button>
        `;
        const joinTile = `
            <button class="server-item server-join" type="button" id="joinServerBtn" title="Войти по ссылке" aria-label="Войти по ссылке">
                <span class="server-avatar server-create-plus">↗</span>
                <div class="server-meta">
                    <div class="server-name">Войти по ссылке</div>
                    <div class="server-prev">Введите адрес сервера</div>
                </div>
            </button>
        `;
        const publicTile = `
            <button class="server-item server-public" type="button" id="publicServersBtn" title="Открыть публичные серверы" aria-label="Открыть публичные серверы">
                <span class="server-avatar server-create-plus">☰</span>
                <div class="server-meta">
                    <div class="server-name">Публичные серверы</div>
                    <div class="server-prev">Просмотр и вход из меню</div>
                </div>
            </button>
        `;

        target.innerHTML = `
            <div class="server-list">
                ${list.length === 0 ? `<div class="server-empty">
                    <div class="empty-ttl">Сервера не найдены</div>
                    <div class="empty-sub">Попробуйте другой запрос</div>
                </div>` : list.map(server => {
                    const active = server.id === this.S.activeServer ? 'active' : '';
                    const badge = Number(server.unread || 0) > 0
                        ? `<div class="badge server-badge">${Number(server.unread) > 99 ? '99+' : Number(server.unread)}</div>`
                        : '';
                    const preview = server.description || server.hint || 'Сервер';
                    return `
                        <button class="server-item ${active}" type="button" data-server-id="${this.esc(server.id)}" title="${this.esc(server.name)}" aria-label="${this.esc(server.name)}">
                            <span class="server-avatar" style="background:${this.esc(server.color || 'linear-gradient(180deg, #cbff00, #8c8c8c)')}">${this.esc(server.icon || server.name?.[0] || 'S')}</span>
                            <div class="server-meta">
                                <div class="server-name">${this.esc(server.name)}</div>
                                <div class="server-prev">${this.esc(preview)}</div>
                            </div>
                            ${badge}
                        </button>
                    `;
                }).join('')}
                ${createTile}
                ${joinTile}
                ${publicTile}
            </div>
        `;
    }

    updateServerSelection() {
        const rows = document.querySelectorAll('.server-item[data-server-id]');
        rows.forEach(row => {
            const serverId = row.getAttribute('data-server-id');
            row.classList.toggle('active', serverId === this.S.activeServer);
        });
    }

    setActiveServer(serverId, { persist = true } = {}) {
        const next = String(serverId || '').trim();
        if (!next) return;
        this.ensureServersState();
        if (!this.S.servers.some(server => server.id === next)) return;
        const previousVoiceServer = String(this.voice.serverId || '').trim();
        const previousVoiceChannel = String(this.voice.channelId || '').trim();
        const current = this.currentServer();
        const currentChannel = this.currentChannel();
        if (this.S.navMode === 'servers' && this.S.activeServer === next && current && currentChannel) return;
        this.S.activeServer = next;
        this.S.navMode = 'servers';
        const server = this.currentServer();
        if (server) {
            const storedChannel = this.loadStoredActiveChannel();
            const fallbackChannel = (server.channels || [])[0]?.id || null;
            this.S.activeChannel = storedChannel && (server.channels || []).some(ch => ch.id === storedChannel)
                ? storedChannel
                : fallbackChannel;
        }
        if (persist) {
            this.saveStoredNavMode('servers');
            this.saveStoredActiveServer(next);
            this.saveStoredActiveChannel(this.S.activeChannel);
        }
        if (this.voice.roomType === 'channel' && previousVoiceServer && previousVoiceChannel) {
            const nextVoiceChannel = String(this.S.activeChannel || '').trim();
            if (previousVoiceServer !== next || previousVoiceChannel !== nextVoiceChannel) {
                this.leaveVoiceRoom({ announce: true });
            }
        }
        this.updateNavModeButtons();
        this.renderServerToolbar();
        this.requestMessagesScroll('bottom');
        this.renderMessages();
        this.updateSendButtonState();
        this.updateServerSelection();
        if (this.S.activeServer && this.S.activeChannel) {
            this.requestMessagesScroll('bottom');
            this.loadServerMessages(this.S.activeServer, this.S.activeChannel, { silent: true });
        }
    }

    getCurrentMessages() {
        if (this.S.navMode === 'servers') {
            const key = this.currentServerChatKey();
            return this.S.serverChats[key] || [];
        }
        return this.S.chats[this.S.current] || [];
    }

    ensureConversationLoaded(peer = null) {
        const currentPeer = String(peer || this.S.current || '').trim();
        if (!currentPeer) return false;
        const currentMsgs = this.S.chats[currentPeer];
        if (Array.isArray(currentMsgs) && currentMsgs.length > 0) {
            return true;
        }

        const cache = this.loadStoredMessageCache();
        const cachedMsgs = Array.isArray(cache?.chats?.[currentPeer]) ? cache.chats[currentPeer] : [];
        if (cachedMsgs.length === 0) return false;

        this.S.chats[currentPeer] = cachedMsgs.filter(msg => msg && typeof msg === 'object');
        this.trace(`ensureConversationLoaded peer=${currentPeer} restored=${this.S.chats[currentPeer].length}`);
        return true;
    }

    renderMessages() {
        const box = document.getElementById('msgs');
        if (!box) return;
        this.hideReactionMenu();
        const isServers = this.S.navMode === 'servers';
        const conversationKey = isServers ? this.currentServerChatKey() : String(this.S.current || '').trim();
        const previousConversationKey = this.lastRenderedConversationKey || '';
        const conversationChanged = previousConversationKey !== conversationKey;
        const previousScrollTop = box.scrollTop;
        const previousScrollHeight = box.scrollHeight;
        const stickToBottom = this.isMessagesNearBottom(box);
        const msgs = this.getCurrentMessages();
        const channel = this.currentChannel();
        const server = this.currentServer();

        if (!isServers && (!Array.isArray(msgs) || msgs.length === 0) && !this.S.loading) {
            const restored = this.ensureConversationLoaded(this.S.current);
            if (restored) {
                this.trace(`renderMessages rerender restored peer=${String(this.S.current || '').trim()}`);
                requestAnimationFrame(() => this.renderMessages());
                return;
            }
        }

        if (isServers && channel && this.isVoiceChannel(channel)) {
            box.innerHTML = this.renderVoiceRoomView();
            this.requestMessagesScroll('top');
            this.applyPendingMessagesScroll(box);
            if (isServers && server) {
                const chatHdrAva = document.getElementById('chatHdrAva');
                const chatHdrName = document.getElementById('chatHdrName');
                const chatHdrSub = document.getElementById('chatHdrSub');
                if (chatHdrAva) chatHdrAva.innerHTML = this.esc(server.icon || server.name?.[0] || 'S');
                if (chatHdrName) chatHdrName.innerHTML = `<span class="chat-hdr-title">${this.esc(`🔊 ${channel.name}`)}</span><span class="chat-hdr-count">${this.esc(`Голосовой канал`)}</span>`;
                if (chatHdrSub) chatHdrSub.textContent = `${server.name}${channel.topic ? ` · ${channel.topic}` : ''}`;
                this.updateChatHeaderCryptoKey({
                    serverId: server.id,
                    channelId: channel?.id || null,
                });
            }
            this.renderVoicePanel();
            return;
        }

        if (msgs.length === 0 && !this.S.loading) {
            if (isServers) {
                box.innerHTML = `<div class="empty-state">
                    <div class="empty-ttl">Нет сообщений в канале</div>
                    <div class="empty-sub">${channel ? `#${this.esc(channel.name)}` : 'Выберите канал'}</div>
                </div>`;
                return;
            }
            box.innerHTML = `<div class="empty-state">
                <div class="empty-ttl">Нет сообщений</div>
                <div class="empty-sub">Начните разговор</div>
            </div>`;
            return;
        }

        let html = '';
        const GROUP_WINDOW_MS = 10 * 60 * 1000;
        const items = msgs.map(msg => {
            const ts = msg.timestamp ? new Date(msg.timestamp).getTime() : 0;
            const dayKey = ts ? new Date(ts).toDateString() : '';
            return { msg, ts, dayKey, groupPos: 'single' };
        });

        items.forEach((item, idx) => {
            const prev = items[idx - 1];
            const next = items[idx + 1];
            const samePrev = !!(prev && prev.dayKey && prev.dayKey === item.dayKey && prev.msg.sender === item.msg.sender && item.ts && prev.ts && (item.ts - prev.ts) <= GROUP_WINDOW_MS);
            const sameNext = !!(next && next.dayKey && next.dayKey === item.dayKey && next.msg.sender === item.msg.sender && item.ts && next.ts && (next.ts - item.ts) <= GROUP_WINDOW_MS);

            if (samePrev && sameNext) item.groupPos = 'mid';
            else if (!samePrev && sameNext) item.groupPos = 'start';
            else if (samePrev && !sameNext) item.groupPos = 'end';
            else item.groupPos = 'single';
        });

        let lastDate = null;
        items.forEach(item => {
            const msg = item.msg;
            const isOut = this.isOutgoingMessage(msg);
            const isCall = msg.kind === 'call';
            const dateStr = this.fmtDate(msg.timestamp);
            const mediaCard = !isCall && this.messageHasMedia(msg) ? 'media-card' : '';
            const gifOnly = !isCall && this.messageIsGifOnly(msg);
            const isSending = isOut && msg.status === 'sending';
            const messageId = String(msg.id || '').trim();
            if (dateStr && dateStr !== lastDate) {
                html += `<div class="date-sep"><span>${this.esc(dateStr)}</span></div>`;
                lastDate = dateStr;
            }

            const dir = isCall ? (isOut ? 'out' : 'in') : (isOut ? 'out' : 'in');
            const showAvatar = !isCall && !isOut && (item.groupPos === 'single' || item.groupPos === 'end');
            const bubbleClass = isCall ? '' : (gifOnly ? 'media-only' : `bubble ${mediaCard}`);

            html += `<div class="msg ${dir} ${isCall ? 'call-msg' : `group-${item.groupPos}`} ${isSending ? 'sending' : ''} ${gifOnly ? 'gif-only' : ''}"${messageId ? ` data-message-id="${this.esc(messageId)}"` : ''}>`;
            if (!isCall && !isOut && showAvatar) {
                html += `<div class="msg-ava">${this.renderAvatarHTML(msg.sender, 'avatar-img', msg.sender)}</div>`;
            } else if (!isCall && !isOut) {
                html += `<div class="msg-ava msg-ava-spacer" aria-hidden="true"></div>`;
            }
            html += `<div class="bwrap ${isCall ? 'call-wrap' : ''}">
                ${isCall ? this.renderMessageBody(msg) : `<div class="${bubbleClass}">${this.renderMessageBody(msg)}</div>`}
                ${!isCall ? this.renderMessageReactions(msg) : ''}
            </div></div>`;
        });

        if (this.S.loading) {
            html += `<div class="sk sk-bubble sk-w2"></div>
                     <div class="sk sk-bubble sk-w3 sk-self"></div>
                     <div class="sk sk-bubble sk-w1"></div>
                     <div class="sk sk-bubble sk-w2 sk-self"></div>`;
        }

        box.innerHTML = html;
        this.hydrateGifMedia(box);
        if (this.pendingMessagesScroll === 'top') {
            this.applyPendingMessagesScroll(box);
        } else if (this.pendingMessagesScroll === 'bottom') {
            const shouldAutoScroll = conversationChanged || stickToBottom || previousScrollHeight <= box.clientHeight;
            if (shouldAutoScroll) {
                this.applyPendingMessagesScroll(box);
            } else {
                this.pendingMessagesScroll = null;
            }
        }

        if (isServers && server) {
            const chatHdrAva = document.getElementById('chatHdrAva');
            const chatHdrName = document.getElementById('chatHdrName');
            const chatHdrSub = document.getElementById('chatHdrSub');
            if (chatHdrAva) chatHdrAva.innerHTML = this.esc(server.icon || server.name?.[0] || 'S');
            if (chatHdrName) {
                const channelLabel = channel
                    ? `${this.isVoiceChannel(channel) ? '🔊 ' : '#'}${channel.name}`
                    : server.name;
                chatHdrName.innerHTML = `<span class="chat-hdr-title">${this.esc(channelLabel)}</span>`;
            }
            if (chatHdrSub) {
                chatHdrSub.textContent = channel
                    ? `${server.name}${channel.topic ? ` · ${channel.topic}` : ''}`
                    : (server.description || 'Сервер');
            }
        }
        this.lastRenderedConversationKey = conversationKey;
    }

    switchChat(name) {
        const peer = String(name || '').trim();
        if (!peer) return;
        this.trace(`switchChat peer=${peer}`);
        this.S.current = peer;
        this.S.unread[peer] = 0;
        this.initChat(peer);
        this.ensureConversationCryptoKey({ peer, reason: 'switchChat' });
        this.saveStoredCurrentContact(peer);
        this.requestMessagesScroll('bottom');
        const wasServers = this.S.navMode === 'servers';
        this.setNavMode('dm', { refresh: !wasServers });

        const set = (id, v) => { const e = document.getElementById(id); if(e) e.textContent = v; };
        set('tbChat',       peer);
        set('chatHdrName',  peer);
        this.updateChatHeaderCryptoKey({ peer });
        const chatHdrAva = document.getElementById('chatHdrAva');
        if (chatHdrAva) chatHdrAva.innerHTML = this.renderAvatarHTML(peer, 'avatar-img', peer);
        const chatCallBtn = document.getElementById('chatCallBtn');
        if (chatCallBtn) chatCallBtn.hidden = !this.S.current;
        const serverSettingsBtn = document.getElementById('serverSettingsBtn');
        if (serverSettingsBtn) serverSettingsBtn.hidden = true;

        if (wasServers) {
            this.renderServerInterface();
            this.renderContacts();
            this.renderMessages();
            this.renderVoicePanel();
        } else {
            this.renderContacts();
            this.renderMessages();
        }
        this.updateSendButtonState();
        this.syncActiveConversation({ force: true });
    }

    sendInputMessage() {
        const inp = document.getElementById('msgInput');
        const textValue = (inp && inp.value) || '';
        const text = textValue.trim();
        const attachments = this.normalizeAttachments(this.S.draftAttachments);
        if (!text && attachments.length === 0) return;

        const clientId = (window.crypto && window.crypto.randomUUID) ? window.crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
        const payloadAttachments = attachments.map(att => ({ ...att }));
        const ts = new Date().toISOString();
        const isServers = this.S.navMode === 'servers';
        const server = isServers ? this.currentServer() : null;
        const channel = isServers ? this.currentChannel() : null;
        const conversationKey = isServers ? this.currentServerChatKey() : this.S.current;
        if (isServers && (!server || !channel)) return;
        if (isServers && this.isVoiceChannel(channel)) return;
        if (!isServers && !this.S.current) return;
        const cryptoKey = this.ensureConversationCryptoKey({
            peer: isServers ? null : this.S.current,
            serverId: isServers ? server.id : null,
            channelId: isServers ? channel.id : null,
            reason: 'sendInputMessage'
        });
        this.trace(`sendInputMessage start clientId=${clientId} sender=${this.myName()} receiver=${isServers ? channel.id : this.S.current} server=${isServers ? server.id : 'dm'} channel=${isServers ? channel.id : 'dm'} attachments=${payloadAttachments.length} textBytes=${text.length} keySet=${!!cryptoKey} tokenSet=${!!this.S.session?.token}`);

        const outgoingMessage = {
            id: clientId,
            sender: this.myName(),
            receiver: isServers ? channel.id : this.S.current,
            text,
            attachments: payloadAttachments,
            timestamp: ts,
            status: 'sending',
            clientId,
            serverId: isServers ? server.id : null,
            channelId: isServers ? channel.id : null,
        };

        const bridgeAvailable = this.nativeSupports('sendMessage');
        if (!bridgeAvailable) {
            this.trace(`sendInputMessage noNativeBridge clientId=${clientId}`);
            if (isServers) {
                if (!this.S.serverChats[conversationKey]) this.S.serverChats[conversationKey] = [];
                this.S.serverChats[conversationKey].push(outgoingMessage);
            } else {
                this.ensureContact(this.S.current);
                this.initChat(this.S.current);
                this.S.chats[this.S.current].push(outgoingMessage);
            }
            this.saveStoredMessageCache();
            this.renderMessages();
            this.renderContacts();
            this.renderServerInterface();
            if (inp) {
                inp.value = '';
                this.resizeComposer();
            }
            this.clearDraftAttachments();
            this.updateSendButtonState();
            inp && inp.focus();
            this.addLogEntry({ type: 'WARN', msg: 'Native bridge не обнаружен. Сообщение сохранено только в локальном интерфейсе.', ts: new Date().toLocaleTimeString() });
            return;
        }

        if (!cryptoKey) {
            this.trace(`sendInputMessage missingKey clientId=${clientId}`);
            this.addLogEntry({ type: 'ERROR', msg: 'Для отправки сообщения нужен E2E-ключ', ts: new Date().toLocaleTimeString() });
            return;
        }
        if (!this.S.session?.token) {
            this.trace(`sendInputMessage missingToken clientId=${clientId}`);
            this.addLogEntry({ type: 'ERROR', msg: 'Для отправки сообщения нужно войти в аккаунт', ts: new Date().toLocaleTimeString() });
            return;
        }

        if (isServers) {
            if (!this.S.serverChats[conversationKey]) this.S.serverChats[conversationKey] = [];
            this.S.serverChats[conversationKey].push(outgoingMessage);
        } else {
            this.ensureContact(this.S.current);
            this.initChat(this.S.current);
            this.S.chats[this.S.current].push(outgoingMessage);
        }
        this.saveStoredMessageCache();

        this.renderMessages();
        this.renderContacts();
        this.renderServerInterface();

        if (inp) {
            inp.value = '';
            this.resizeComposer();
        }

        this.clearDraftAttachments();
        this.updateSendButtonState();
        inp && inp.focus();

        this.enqueuePendingOutbox({
            ...outgoingMessage,
            key: cryptoKey,
        });
        this.trace(`sendInputMessage queued clientId=${clientId}`);

        this.postNativeMessage({
            type: 'SEND_MESSAGE',
            text: text,
            recipient: isServers ? channel.id : this.S.current,
            serverId: isServers ? server.id : '',
            channelId: isServers ? channel.id : '',
            sender: this.myName(),
            key: cryptoKey,
            clientId,
            attachments: payloadAttachments.map(att => ({
                name: att.name,
                mimeType: att.mimeType,
                kind: att.kind,
                size: att.size,
                dataUrl: att.dataUrl,
            }))
        });
    }

    _getKey() {
        try {
            return this.ensureConversationCryptoKey({
                peer: this.S.navMode === 'servers' ? null : this.S.current,
                serverId: this.S.navMode === 'servers' ? this.currentServer()?.id || null : null,
                channelId: this.S.navMode === 'servers' ? this.currentChannel()?.id || null : null,
                reason: '_getKey'
            });
        } catch (e) {
            return '';
        }
    }

    updateSendButtonState() {
        const btn = document.getElementById('sendBtn');
        const inp = document.getElementById('msgInput');
        const hasText = !!(inp && inp.value.trim().length);
        const hasAttachments = this.S.draftAttachments.length > 0;
        const channel = this.currentChannel();
        const canSend = this.S.navMode === 'servers'
            ? !!(this.currentServer() && channel && !this.isVoiceChannel(channel))
            : !!this.S.current;
        if (btn) btn.disabled = !(hasText || hasAttachments) || !canSend;
    }

    // --- Bus Command Handlers ---

    receiveMessage(payload = {}) {
        const {
            id,
            sender,
            receiver,
            text,
            timestamp,
            attachments,
            reactions,
            myReaction,
        } = payload || {};
        const serverId = payload?.serverId || payload?.server_id || null;
        const channelId = payload?.channelId || payload?.channel_id || null;
        const clientId = String(payload?.clientId || payload?.client_id || '').trim();
        this.trace(`receiveMessage id=${String(id || '').trim()} clientId=${clientId || 'none'} sender=${String(sender || '').trim()} receiver=${String(receiver || '').trim()} server=${serverId || 'dm'} channel=${channelId || 'dm'} textBytes=${String(text || '').length} attachments=${Array.isArray(attachments) ? attachments.length : 0} reactions=${Array.isArray(reactions) ? reactions.length : 0}`);
        if (clientId) {
            const reconciled = this.finalizePendingMessage(clientId, id);
            if (reconciled) {
                this.dropPendingOutbox(clientId);
                if (serverId && channelId) {
                    this.renderServerInterface();
                } else {
                    this.renderMessages();
                    this.renderContacts();
                }
                this.addLogEntry({ type: 'SUCCESS', msg: `Сообщение подтверждено сервером: ${sender}`, ts: new Date().toLocaleTimeString() });
                return;
            }
        }
        if (serverId && channelId) {
            const key = `${serverId}:${channelId}`;
            const msgs = this.S.serverChats[key] || (this.S.serverChats[key] = []);
            const incomingAttachments = this.normalizeAttachments(attachments);
            const incomingReactions = this.normalizeReactions(reactions);
            const messageId = String(id || '').trim();
            const attachmentKey = incomingAttachments.map(att => `${att.name}:${att.kind}:${att.size}`).join('|');
            const isDup = msgs.slice(-6).some(m =>
                (messageId && String(m.id || '').trim() === messageId) ||
                (m.sender === sender && m.text === text && this.normalizeAttachments(m.attachments).map(att => `${att.name}:${att.kind}:${att.size}`).join('|') === attachmentKey)
            );
            if (isDup) return;
            const ts = timestamp || new Date().toISOString();
            msgs.push({
                id: messageId,
                sender,
                receiver,
                text,
                attachments: incomingAttachments,
                reactions: incomingReactions,
                myReaction: myReaction || '',
                timestamp: ts,
                serverId,
                channelId,
            });
            this.saveStoredMessageCache();
            if (this.currentServerChatKey() === key) {
                this.renderMessages();
            } else {
                this.renderServerInterface();
            }
            this.addLogEntry({ type: 'SUCCESS', msg: `Получено в канале ${serverId}/${channelId}: ${sender}`, ts: new Date().toLocaleTimeString() });
            return;
        }

        const peer = sender === this.myName() ? receiver : sender;
        this.ensureContact(peer);
        this.initChat(peer);
        const msgs = this.S.chats[peer];
        const incomingAttachments = this.normalizeAttachments(attachments);
        const incomingReactions = this.normalizeReactions(reactions);
        const messageId = String(id || '').trim();
        const attachmentKey = incomingAttachments.map(att => `${att.name}:${att.kind}:${att.size}`).join('|');
        const isDup = msgs.slice(-6).some(m =>
            (messageId && String(m.id || '').trim() === messageId) ||
            (m.sender === sender && m.text === text && this.normalizeAttachments(m.attachments).map(att => `${att.name}:${att.kind}:${att.size}`).join('|') === attachmentKey)
        );
        if (isDup) return;
        const ts = timestamp || new Date().toISOString();
        msgs.push({
            id: messageId,
            sender,
            receiver,
            text,
            attachments: incomingAttachments,
            reactions: incomingReactions,
            myReaction: myReaction || '',
            timestamp: ts
        });
        this.saveStoredMessageCache();
        if (!this.S.current) {
            this.switchChat(peer);
        }
        if (peer === this.S.current) {
            this.renderMessages();
        } else {
            this.S.unread[peer] = (this.S.unread[peer] || 0) + 1;
            this.renderContacts();
        }
        this.addLogEntry({ type: 'SUCCESS', msg: `Получено: ${sender} → ${receiver}`, ts: new Date().toLocaleTimeString() });
    }

    handleAvatarUpdated({ username, deleted = false } = {}) {
        const name = String(username || '').trim();
        if (!name) return;

        if (deleted) {
            this.saveStoredAvatar(name, null);
        } else {
            this.clearStoredAvatar(name);
            this.ensureAvatarLoaded(name, { force: true });
        }

        this.scheduleAvatarRefresh();
    }

    setUsers(users) {
        this.S.users = Array.isArray(users) ? users : [];
        this.S.users.forEach(u => this.initChat(u));
        const others = this.S.users.filter(u => u !== this.myName());
        if (this.S.navMode !== 'servers' && !this.S.current && this.S.contacts.length > 0) this.switchChat(this.S.contacts[0]);
        this.trace(`setUsers count=${this.S.users.length} others=${others.join(',')}`);
        this.addLogEntry({ type: 'INFO', msg: `Загружен список пользователей: ${others.join(', ')}`, ts: new Date().toLocaleTimeString() });
        this.renderContactSuggestions();
    }

    setContacts(contacts) {
        const me = this.myName();
        this.S.contacts = Array.isArray(contacts) ? contacts.filter(Boolean).filter(u => u !== me) : [];
        this.S.contacts.forEach(u => this.initChat(u));
        this.trace(`setContacts count=${this.S.contacts.length} me=${me} contacts=${this.S.contacts.join(',')}`);
        if (this.S.navMode !== 'servers') {
            const storedCurrent = this.loadStoredCurrentContact();
            const currentValid = !!(this.S.current && this.S.contacts.includes(this.S.current));
            const storedValid = !!(storedCurrent && this.S.contacts.includes(storedCurrent));

            if (storedValid && (!currentValid || this.S.current !== storedCurrent)) {
                this.switchChat(storedCurrent);
            } else if (currentValid) {
                this.renderMessages();
                this.renderContacts();
            } else if (this.S.contacts.length > 0) {
                this.switchChat(this.S.contacts[0]);
            } else {
                this.S.current = null;
                this.saveStoredCurrentContact(null);
                const set = (id, v) => { const e = document.getElementById(id); if(e) e.textContent = v; };
                set('tbChat', 'Нет контактов');
                set('chatHdrAva', 'Z');
                set('chatHdrName', 'Добавьте контакт');
            }
            if (this.S.current) {
                this.ensureConversationCryptoKey({ peer: this.S.current, reason: 'setContacts' });
                this.syncActiveConversation({ force: true });
            }
        }
        this.renderContacts();
        this.renderMessages();
        this.renderContactSuggestions();
    }

    setSession(session) {
        if (!session || typeof session !== 'object') return;
        this.applySession({
            username: session.username || 'Zalikus',
            token: session.token || null,
            guest: !!session.guest || !session.token,
        }, { persist: false, syncNative: false });
        this.loadContacts();
        this.loadUsers();
        this.loadServers({ silent: true });
        this.renderContactSuggestions();
    }

    loadHistory(messages) {
        this.trace(`loadHistory count=${Array.isArray(messages) ? messages.length : 0}`);
        this.addLogEntry({ type: 'INFO', msg: `Загрузка истории чата: ${messages.length} сообщений`, ts: new Date().toLocaleTimeString() });
        messages.forEach(msg => {
            const peer = msg.kind === 'call'
                ? String(msg.call?.peer || msg.receiver || msg.sender || '').trim()
                : (msg.sender === this.myName() ? msg.receiver : msg.sender);
            this.ensureContact(peer);
            this.initChat(peer);
            const arr = this.S.chats[peer];
            const normalizedAttachments = this.normalizeAttachments(msg.attachments);
            const normalizedReactions = this.normalizeReactions(msg.reactions);
            const msgId = String(msg.id || '').trim();
            const clientId = String(msg.clientId || msg.client_id || '').trim();
            this.trace(`loadHistory item id=${msgId || 'none'} clientId=${clientId || 'none'} sender=${String(msg.sender || '').trim()} receiver=${String(msg.receiver || '').trim()} peer=${peer} attachments=${normalizedAttachments.length} reactions=${normalizedReactions.length}`);
            if (clientId && this.finalizePendingMessage(clientId, msgId)) {
                this.trace(`loadHistory finalized pending clientId=${clientId} messageId=${msgId}`);
                this.dropPendingOutbox(clientId);
                this.markMessageSeen(msg);
                return;
            }
            const incoming = {
                ...msg,
                attachments: normalizedAttachments,
                reactions: normalizedReactions,
                myReaction: msg.myReaction || '',
            };
            const incomingKey = this.messageRenderKey(incoming);
            const isDup = arr.some(m => {
                if (msgId && String(m.id || '').trim() === msgId) return true;
                return this.messageRenderKey(m) === incomingKey;
            });
            if (!isDup) {
                arr.push({
                    ...msg,
                    id: msgId || msg.id || '',
                    attachments: normalizedAttachments,
                    reactions: normalizedReactions,
                    myReaction: msg.myReaction || '',
                    status: 'sent'
                });
            }
            this.markMessageSeen(msg);
        });
        Object.keys(this.S.chats).forEach(u => {
            this.S.chats[u].sort((a,b) => new Date(a.timestamp||0) - new Date(b.timestamp||0));
        });
        this.normalizeDmChatStore();
        this.saveStoredMessageCache();
        this.requestMessagesScroll('bottom');
        if (this.S.navMode !== 'servers') {
            const currentKey = String(this.S.current || '').trim();
            const currentMsgs = currentKey ? (this.S.chats[currentKey] || []) : [];
            const storedCurrent = this.loadStoredCurrentContact();
            const pendingPeers = this.loadPendingOutbox()
                .filter(item => String(item?.sender || '').trim() === this.myName())
                .map(item => String(item?.receiver || '').trim())
                .filter(Boolean);
            const preferredPeer = (() => {
                if (storedCurrent && (this.S.chats[storedCurrent] || []).length) return storedCurrent;
                for (let i = pendingPeers.length - 1; i >= 0; i -= 1) {
                    const peer = pendingPeers[i];
                    if ((this.S.chats[peer] || []).length) return peer;
                }
                const populated = Object.entries(this.S.chats)
                    .filter(([, msgs]) => Array.isArray(msgs) && msgs.length > 0)
                    .sort((a, b) => new Date(b[1][b[1].length - 1]?.timestamp || 0) - new Date(a[1][a[1].length - 1]?.timestamp || 0));
                return populated[0]?.[0] || null;
            })();

            if (!this.S.current && preferredPeer && preferredPeer !== this.S.current) {
                this.switchChat(preferredPeer);
            }
        }
        this.renderMessages();
        this.renderContacts();
        if (!this.S.current && this.S.contacts.length > 0) {
            this.switchChat(this.S.contacts[0]);
        }
        this.scheduleFlushPendingOutbox(300);
        this.trace(`loadHistory done current=${this.S.current || 'none'} chats=${Object.keys(this.S.chats).length}`);
    }

    setLoading(on) {
        this.S.loading = !!on;
        this.renderMessages();
    }

    setConnectionStatus(connected) {
        this.S.wsOn = !!connected;
        const pill = document.getElementById('wsPill');
        const lbl  = document.getElementById('wsLabel');
        if (pill) pill.className = 'ws-pill' + (connected ? ' on' : '');
        if (lbl)  lbl.textContent = connected ? 'Подключено' : 'Переподключение...';
        this.addLogEntry({ type: connected ? 'SUCCESS' : 'WARN', msg: connected ? 'WebSocket соединение установлено' : 'WebSocket соединение разорвано', ts: new Date().toLocaleTimeString() });
    }

    onSendSuccess(payload) {
        if (payload && typeof payload === 'object') {
            this.trace(`onSendSuccess clientId=${String(payload.clientId || '').trim()} messageId=${String(payload.messageId || '').trim()}`);
            this.finalizePendingMessage(payload.clientId, payload.messageId);
            this.dropPendingOutbox(payload.clientId);
        } else {
            this.trace(`onSendSuccess payload=${String(payload || '').trim()}`);
            this.markMessageStatus(payload, 'sent');
            this.dropPendingOutbox(payload);
        }
        this.addLogEntry({ type: 'SUCCESS', msg: 'Сообщение доставлено адресату', ts: new Date().toLocaleTimeString() });
    }

    onSendError(clientId) {
        this.trace(`onSendError clientId=${String(clientId || '').trim()}`);
        this.markMessageStatus(clientId, 'error');
        this.scheduleFlushPendingOutbox(2000);
        this.addLogEntry({ type: 'ERROR', msg: 'Сообщение отклонено сервером', ts: new Date().toLocaleTimeString() });
    }

    onReactionUpdated(payload) {
        if (!payload || typeof payload !== 'object') return;
        const found = this.findMessageById(payload.messageId);
        if (!found) return;
        found.msg.reactions = this.normalizeReactions(payload.reactions);
        found.msg.myReaction = String(payload.myReaction || '').trim();
        const shouldRender = found.serverKey
            ? found.serverKey === this.currentServerChatKey()
            : found.peer === this.S.current;
        if (shouldRender) {
            this.renderMessages();
        }
    }

    addLogEntry({ type, msg, ts }) {
        const body = document.getElementById('logBody');
        if (body) {
            const div = document.createElement('div');
            div.className = `log-entry log-${type}`;
            div.innerHTML = `<span class="ts">[${ts}]</span>${this.esc(type)}: ${this.esc(msg)}`;
            body.appendChild(div);
            body.scrollTop = body.scrollHeight;
            if (body.childElementCount > 300) body.removeChild(body.firstElementChild);
        }
    }

    voiceTrace(stage, details = {}, level = 'INFO') {
        const ts = new Date().toLocaleTimeString();
        const compact = Object.entries(details)
            .filter(([, value]) => value !== undefined && value !== null && value !== '')
            .map(([key, value]) => {
                if (Array.isArray(value)) return `${key}=[${value.join(',')}]`;
                if (typeof value === 'object') {
                    try { return `${key}=${JSON.stringify(value)}`; } catch (e) { return `${key}=[object]`; }
                }
                return `${key}=${String(value)}`;
            })
            .join(' ');
        const message = compact ? `${stage} ${compact}` : stage;
        this.voice.traceLines = Array.isArray(this.voice.traceLines) ? this.voice.traceLines : [];
        this.voice.traceLines.push({ ts, level, stage, message });
        if (this.voice.traceLines.length > 14) {
            this.voice.traceLines.splice(0, this.voice.traceLines.length - 14);
        }
        this.addLogEntry({ type: level, msg: `[VOICE] ${message}`, ts });
        try {
            const fn = level === 'ERROR' ? console.error : level === 'WARN' ? console.warn : console.debug;
            fn?.('[VOICE]', stage, details);
        } catch (e) {}
    }

    // --- UI Event Binding ---

    bindEvents() {
        // 1. Click on contacts
        const contactsEl = document.getElementById('contacts');
        if (contactsEl) {
            contactsEl.addEventListener('click', (e) => {
                const serverBtn = e.target.closest('.server-item[data-server-id]');
                if (serverBtn) {
                    const serverId = serverBtn.getAttribute('data-server-id');
                    if (serverId) this.setActiveServer(serverId);
                    e.stopPropagation();
                    return;
                }
                const createBtn = e.target.closest('.server-create');
                if (createBtn) {
                    this.openServerModal('create');
                    e.stopPropagation();
                    return;
                }
                const joinBtn = e.target.closest('.server-join');
                if (joinBtn) {
                    const raw = prompt('Введите ссылку на сервер:');
                    const link = this.extractInviteCode(raw);
                    if (link) this.joinServerByLink(link);
                    e.stopPropagation();
                    return;
                }
                const publicBtn = e.target.closest('.server-public');
                if (publicBtn) {
                    this.openPublicServersModal();
                    e.stopPropagation();
                    return;
                }
                const removeBtn = e.target.closest('.contact-remove');
                if (removeBtn) {
                    const username = removeBtn.getAttribute('data-remove-contact');
                    if (username) this.removeContact(username);
                    e.stopPropagation();
                    return;
                }
                const row = e.target.closest('.contact');
                if (row && row.dataset.name) this.switchChat(row.dataset.name);
            });
        }

        const serverChannelList = document.getElementById('serverChannelList');
        if (serverChannelList) {
            serverChannelList.addEventListener('click', (e) => {
                const channelBtn = e.target.closest('.server-channel[data-channel-id]');
                if (!channelBtn) return;
                const channelId = channelBtn.getAttribute('data-channel-id');
                if (channelId) this.setActiveChannel(channelId);
            });
        }

        const voicePanel = document.getElementById('voicePanel');
        if (voicePanel) {
            voicePanel.addEventListener('click', async (e) => {
                const callBtn = e.target.closest('#voiceCallBtn');
                if (callBtn) {
                    await this.startDirectCall(this.S.current);
                    return;
                }
                const joinBtn = e.target.closest('#voiceJoinBtn');
                if (joinBtn) {
                    await this.joinVoiceChannel();
                    return;
                }
                const leaveBtn = e.target.closest('#voiceLeaveBtn');
                if (leaveBtn) {
                    await this.leaveVoiceRoom({ announce: true });
                    return;
                }
                const muteBtn = e.target.closest('#voiceMuteBtn');
                if (muteBtn) {
                    this.toggleVoiceMute();
                    return;
                }
                const acceptBtn = e.target.closest('#voiceAcceptBtn');
                if (acceptBtn) {
                    await this.acceptIncomingCall();
                    return;
                }
                const rejectBtn = e.target.closest('#voiceRejectBtn');
                if (rejectBtn) {
                    await this.rejectIncomingCall();
                    return;
                }
                const cancelBtn = e.target.closest('#voiceCancelBtn');
                if (cancelBtn) {
                    const invite = this.voice.outgoingInvite;
                    if (invite?.roomId && invite?.target) {
                        this.sendVoiceEvent({
                            type: 'voice_call_cancel',
                            roomId: invite.roomId,
                            target: invite.target,
                        });
                    }
                    this.recordVoiceCallHistory({ outcome: 'cancelled', endedAt: Date.now() });
                    this.resetVoiceState({ preserveInvite: false });
                }
            });
        }

        const chatCallBtn = document.getElementById('chatCallBtn');
        if (chatCallBtn) {
            chatCallBtn.addEventListener('click', async () => {
                if (!this.S.current) return;
                await this.startDirectCall(this.S.current);
            });
        }

        const msgsEl = document.getElementById('msgs');
        if (msgsEl) {
            msgsEl.addEventListener('click', (e) => {
                const fileLink = e.target.closest('a.file-chip, a.file-message');
                if (fileLink) {
                    e.preventDefault();
                    e.stopPropagation();
                    const href = fileLink.getAttribute('href') || '';
                    const filename = fileLink.getAttribute('download') || fileLink.textContent || 'attachment';
                    this.downloadAttachmentFromHref(href, filename);
                    return;
                }
                const reactionBtn = e.target.closest('[data-message-reaction]');
                if (reactionBtn) {
                    const messageId = reactionBtn.getAttribute('data-message-id');
                    const emoji = reactionBtn.getAttribute('data-message-reaction');
                    if (messageId && emoji) {
                        this.addReaction(messageId, emoji);
                    }
                    e.stopPropagation();
                    return;
                }
                this.hideReactionMenu();
            });
            msgsEl.addEventListener('contextmenu', (e) => {
                const msgEl = e.target.closest('.msg[data-message-id]');
                if (!msgEl) return;
                const messageId = msgEl.getAttribute('data-message-id');
                if (!messageId) return;
                e.preventDefault();
                this.showReactionMenu(msgEl, messageId, e.clientX, e.clientY);
                e.stopPropagation();
            });
        }

        document.addEventListener('click', (e) => {
            const menu = document.getElementById('reactionMenu');
            if (!menu || !menu.classList.contains('visible')) return;
            if (menu.contains(e.target)) return;
            if (e.target.closest('.msg[data-message-id]')) return;
            this.hideReactionMenu();
        });
        window.addEventListener('blur', () => this.hideReactionMenu());

        const contactInput = document.getElementById('contactInput');
        if (contactInput) {
            contactInput.addEventListener('input', () => this.renderContactSuggestions(true));
            contactInput.addEventListener('focus', () => this.renderContactSuggestions(true));
            contactInput.addEventListener('blur', () => {
                setTimeout(() => this.hideContactSuggestions(), 120);
            });
            contactInput.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    e.preventDefault();
                    this.hideContactSuggestions();
                    contactInput.blur();
                    return;
                }
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.addContactFromInput();
                }
            });
        }

        const contactSuggestions = document.getElementById('contactSuggestions');
        if (contactSuggestions) {
            contactSuggestions.addEventListener('pointerdown', (e) => {
                const item = e.target.closest('.contact-suggest-item');
                if (!item) return;
                e.preventDefault();
                const username = item.getAttribute('data-username');
                if (username) {
                    this.addContactFromInput(username);
                }
            });
        }

        // 2. Click send button & keyboard listener
        const sendBtn = document.getElementById('sendBtn');
        if (sendBtn) sendBtn.addEventListener('click', () => this.sendInputMessage());

        const attachBtn = document.getElementById('attachBtn');
        const attachmentInput = document.getElementById('attachmentInput');
        if (attachBtn && attachmentInput) {
            attachBtn.addEventListener('click', () => attachmentInput.click());
            attachmentInput.addEventListener('change', (e) => {
                this.handleFiles(e.target.files || []);
                e.target.value = '';
            });
        }

        const msgInput = document.getElementById('msgInput');
        if (msgInput) {
            msgInput.addEventListener('input', () => {
                this.resizeComposer();
                this.updateSendButtonState();
            });
            msgInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) { 
                    e.preventDefault(); 
                    this.sendInputMessage(); 
                }
            });
            msgInput.addEventListener('paste', (e) => {
                const files = Array.from(e.clipboardData?.files || []).filter(Boolean);
                if (files.length > 0) {
                    e.preventDefault();
                    this.handleFiles(files);
                }
            });
        }

        const inputBar = document.getElementById('inputBar');
        if (inputBar) {
            inputBar.addEventListener('dragover', (e) => {
                e.preventDefault();
                inputBar.classList.add('drop-active');
            });
            inputBar.addEventListener('dragleave', () => {
                inputBar.classList.remove('drop-active');
            });
            inputBar.addEventListener('drop', (e) => {
                e.preventDefault();
                inputBar.classList.remove('drop-active');
                const files = Array.from(e.dataTransfer?.files || []).filter(Boolean);
                if (files.length > 0) this.handleFiles(files);
            });
        }

        const draftAttachments = document.getElementById('draftAttachments');
        if (draftAttachments) {
            draftAttachments.addEventListener('click', (e) => {
                const btn = e.target.closest('.draft-att-remove');
                if (!btn) return;
                const id = btn.getAttribute('data-att-id');
                this.S.draftAttachments = this.S.draftAttachments.filter(att => att.id !== id);
                this.renderDraftAttachments();
                this.updateSendButtonState();
            });
        }

        // 3. Search filter input
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.S.searchQ = e.target.value;
                this.renderContacts();
            });
        }

        const modeDmBtn = document.getElementById('modeDmBtn');
        const modeServersBtn = document.getElementById('modeServersBtn');
        if (modeDmBtn) modeDmBtn.addEventListener('click', () => this.setNavMode('dm'));
        if (modeServersBtn) modeServersBtn.addEventListener('click', () => this.setNavMode('servers'));

        const authForm = document.getElementById('authForm');
        const authLoginBtn = document.getElementById('authLoginBtn');
        if (authForm) {
            authForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.submitAuth(this.S.auth.mode);
            });
        }
        if (authLoginBtn) {
            authLoginBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.submitAuth(this.S.auth.mode);
            });
        }

        const authRegisterBtn = document.getElementById('authRegisterBtn');
        if (authRegisterBtn) authRegisterBtn.addEventListener('click', () => {
            this.setAuthMode(this.S.auth.mode === 'register' ? 'login' : 'register');
        });

        const authNetworkSaveBtn = document.getElementById('authNetworkSaveBtn');
        const authApiBaseUrl = document.getElementById('authApiBaseUrl');
        if (authApiBaseUrl) {
            authApiBaseUrl.addEventListener('input', () => {
                authApiBaseUrl.dataset.dirty = '1';
                const authNote = document.getElementById('authNetworkNote');
                const value = String(authApiBaseUrl.value || '').trim();
                if (authNote) {
                    authNote.textContent = value ? `Будет использован: ${value}` : 'Автоматически подставляется из настроек';
                }
            });
            authApiBaseUrl.addEventListener('blur', () => {
                this.syncAuthNetworkInput({ force: true });
            });
        }
        if (authNetworkSaveBtn) {
            authNetworkSaveBtn.addEventListener('click', () => {
                const apiBaseUrl = String(authApiBaseUrl?.value || '').trim();
                if (!apiBaseUrl) {
                    this.addLogEntry({
                        type: 'ERROR',
                        msg: 'Укажите адрес API сервера',
                        ts: new Date().toLocaleTimeString(),
                    });
                    return;
                }
                const current = this.loadNetworkConfig();
                this.setNetworkConfig({
                    apiBaseUrl,
                    wsBaseUrl: this.deriveWsBaseUrl(apiBaseUrl),
                    iceServers: current.iceServers,
                });
                if (authApiBaseUrl) {
                    authApiBaseUrl.dataset.dirty = '0';
                }
                this.addLogEntry({
                    type: 'SUCCESS',
                    msg: `Адрес сервера обновлён: ${apiBaseUrl}`,
                    ts: new Date().toLocaleTimeString(),
                });
                this.updateAuthView();
            });
        }

        const authGuestBtn = document.getElementById('authGuestBtn');
        if (authGuestBtn) authGuestBtn.addEventListener('click', () => this.continueAsGuest());

        const authUsername = document.getElementById('authUsername');
        const authPassword = document.getElementById('authPassword');
        if (authUsername) {
            authUsername.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.submitAuth(this.S.auth.mode);
                }
            });
        }
        if (authPassword) {
            authPassword.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.submitAuth(this.S.auth.mode);
                }
            });
        }
        if (authApiBaseUrl) {
            authApiBaseUrl.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    authNetworkSaveBtn?.click();
                }
            });
        }

        requestAnimationFrame(() => {
            this.clearAuthInputs();
            this.S.auth.fieldsCleared = true;
        });
        setTimeout(() => {
            this.clearAuthInputs();
            this.S.auth.fieldsCleared = true;
        }, 120);

        const settingsBtn = document.getElementById('settingsBtn');
        const serverSettingsBtn = document.getElementById('serverSettingsBtn');
        const serverOverlay = document.getElementById('serverOverlay');
        const serverModalClose = document.getElementById('serverModalClose');
        const serverModalCancel = document.getElementById('serverModalCancel');
        const serverSaveBtn = document.getElementById('serverSaveBtn');
        const serverDeleteBtn = document.getElementById('serverDeleteBtn');
        const serverMemberAddBtn = document.getElementById('serverMemberAddBtn');
        const serverJoinLinkGenerateBtn = document.getElementById('serverJoinLinkGenerateBtn');
        const serverJoinLinkCopyBtn = document.getElementById('serverJoinLinkCopyBtn');
        const serverAvatarUploadBtn = document.getElementById('serverAvatarUploadBtn');
        const serverAvatarRemoveBtn = document.getElementById('serverAvatarRemoveBtn');
        const serverBannerUploadBtn = document.getElementById('serverBannerUploadBtn');
        const serverBannerRemoveBtn = document.getElementById('serverBannerRemoveBtn');
        const serverRoleCreateBtn = document.getElementById('serverRoleCreateBtn');
        const serverRoleNameInput = document.getElementById('serverRoleNameInput');
        const settingsLogoutBtn = document.getElementById('settingsLogoutBtn');
        const clearLogsBtn = document.getElementById('clearLogs');
        const closeSettings = document.getElementById('closeSettings');
        const networkConfigSaveBtn = document.getElementById('networkConfigSaveBtn');
        const networkConfigResetBtn = document.getElementById('networkConfigResetBtn');
        const networkTurnApplyBtn = document.getElementById('networkTurnApplyBtn');
        const networkTurnFillBtn = document.getElementById('networkTurnFillBtn');
        const inputApiBaseUrl = document.getElementById('inputApiBaseUrl');
        const inputWsBaseUrl = document.getElementById('inputWsBaseUrl');
        const inputIceServers = document.getElementById('inputIceServers');
        const avatarUploadBtn = document.getElementById('avatarUploadBtn');
        const avatarResetBtn = document.getElementById('avatarResetBtn');
        const meAva = document.getElementById('meAva');

        const openAvatarPicker = () => {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'image/*';
            input.style.position = 'fixed';
            input.style.left = '-9999px';
            input.style.top = '0';
            input.style.width = '1px';
            input.style.height = '1px';
            input.style.opacity = '0';
            input.setAttribute('aria-hidden', 'true');
            document.body.appendChild(input);

            const cleanup = () => {
                input.removeEventListener('change', onChange);
                input.remove();
            };

            const onChange = async () => {
                const file = input.files && input.files[0];
                cleanup();
                if (!file) return;
                try {
                    await this.setProfileAvatar(file, this.myName());
                    this.addLogEntry({ type: 'SUCCESS', msg: `Аватар обновлён: ${this.myName()}`, ts: new Date().toLocaleTimeString() });
                } catch (err) {
                    this.addLogEntry({ type: 'ERROR', msg: err?.message || 'Не удалось обновить аватар', ts: new Date().toLocaleTimeString() });
                }
            };

            input.addEventListener('change', onChange, { once: true });
            input.click();
        };

        const showChatView = () => {
            const cv = document.getElementById('viewChat');
            const sv = document.getElementById('viewSettings');
            if (sv) sv.classList.remove('active');
            if (cv) cv.classList.add('active');
        };

        const showSettingsView = () => {
            const cv = document.getElementById('viewChat');
            const sv = document.getElementById('viewSettings');
            if (cv) cv.classList.remove('active');
            if (sv) sv.classList.add('active');
            this.applyNetworkConfigToInputs();
        };

        if (settingsBtn) settingsBtn.addEventListener('click', () => {
            this.applyNetworkConfigToInputs();
            showSettingsView();
        });
        if (serverSettingsBtn) {
            serverSettingsBtn.addEventListener('click', () => {
                if (this.canManageServer()) {
                    this.openServerModal('edit', this.S.activeServer);
                }
            });
        }
        if (serverOverlay) {
            serverOverlay.addEventListener('click', (e) => {
                if (e.target === serverOverlay) {
                    this.closeServerOverlay();
                }
            });
        }
        const serverDiscoverQuery = document.getElementById('serverDiscoverQuery');
        if (serverDiscoverQuery) {
            serverDiscoverQuery.addEventListener('input', () => this.renderPublicServersModal());
        }
        const serverDiscoverRefreshBtn = document.getElementById('serverDiscoverRefreshBtn');
        if (serverDiscoverRefreshBtn) {
            serverDiscoverRefreshBtn.addEventListener('click', () => this.loadPublicServers({ silent: true }));
        }
        if (serverModalClose) serverModalClose.addEventListener('click', () => this.closeServerOverlay());
        if (serverModalCancel) serverModalCancel.addEventListener('click', () => this.closeServerOverlay());
        if (serverSaveBtn) serverSaveBtn.addEventListener('click', () => this.submitServerModal());
        if (serverDeleteBtn) {
            serverDeleteBtn.addEventListener('click', async () => {
                const serverId = this.S.serverModal.serverId || this.S.activeServer;
                const server = (this.S.servers || []).find(item => item.id === serverId);
                if (!server || this.normalizeMemberRole(server.myRole || server.my_role || '') !== 'owner') return;
                const confirmDelete = confirm(`Удалить сервер "${server.name}"?`);
                if (!confirmDelete) return;
                try {
                    const res = await this.apiFetch(`/api/servers/${encodeURIComponent(serverId)}`, { method: 'DELETE' });
                    if (!res.ok && res.status !== 204) {
                        throw new Error(await res.text() || 'Не удалось удалить сервер');
                    }
                    this.closeServerOverlay();
                    await this.loadServers({ silent: true });
                } catch (e) {
                    this.setServerModalState({ error: e?.message || 'Не удалось удалить сервер' });
                    this.renderServerModal();
                }
            });
        }
        if (serverMemberAddBtn) {
            serverMemberAddBtn.addEventListener('click', async () => {
                const serverId = this.S.serverModal.serverId;
                const input = document.getElementById('serverMemberInput');
                const roleSelect = document.getElementById('serverMemberRole');
                const username = (input?.value || '').trim();
                const role = roleSelect?.value || 'member';
                if (!serverId || !username) return;
                try {
                    const res = await this.apiFetch(`/api/servers/${encodeURIComponent(serverId)}/members`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ username, role }),
                    });
                    if (!res.ok) {
                        throw new Error(await res.text() || 'Не удалось добавить участника');
                    }
                    if (input) input.value = '';
                    const data = await res.json();
                    this.setServerModalState({
                        members: Array.isArray(data?.members) ? data.members : this.S.serverModal.members,
                        error: '',
                    });
                    this.renderServerModal();
                    await this.loadServers({ silent: true });
                } catch (e) {
                    this.setServerModalState({ error: e?.message || 'Не удалось добавить участника' });
                    this.renderServerModal();
                }
            });
        }
        if (serverJoinLinkGenerateBtn) {
            serverJoinLinkGenerateBtn.addEventListener('click', async () => {
                try {
                    const link = await this.generateServerJoinLink();
                    if (link) {
                        this.addLogEntry({ type: 'SUCCESS', msg: `Ссылка сервера обновлена`, ts: new Date().toLocaleTimeString() });
                    }
                } catch (e) {
                    this.setServerModalState({ error: e?.message || 'Не удалось обновить ссылку' });
                    this.renderServerModal();
                }
            });
        }
        if (serverJoinLinkCopyBtn) {
            serverJoinLinkCopyBtn.addEventListener('click', async () => {
                const text = this.S.serverModal.joinLink || '';
                if (!text) return;
                try {
                    await navigator.clipboard.writeText(text);
                    this.addLogEntry({ type: 'SUCCESS', msg: 'Ссылка сервера скопирована', ts: new Date().toLocaleTimeString() });
                } catch (e) {
                    this.addLogEntry({ type: 'WARN', msg: 'Не удалось скопировать ссылку сервера', ts: new Date().toLocaleTimeString() });
                }
            });
        }
        const serverDiscoverList = document.getElementById('serverDiscoverList');
        if (serverDiscoverList) {
            serverDiscoverList.addEventListener('click', async (e) => {
                const card = e.target.closest('[data-public-server-id]');
                if (card && card.classList.contains('server-discover-item')) {
                    const serverId = card.getAttribute('data-public-server-id');
                    if (!serverId) return;
                    const server = (this.S.publicServers || []).find(item => String(item.id || '') === serverId);
                    if (!server) return;
                    const role = this.normalizeMemberRole(server.myRole || server.my_role || '');
                    if (role === 'owner' || role === 'admin' || role === 'member') {
                        this.closeServerOverlay();
                        this.setActiveServer(serverId);
                    } else {
                        await this.enterPublicServer(server.joinLink || server.join_link || server.id);
                    }
                    return;
                }
                const openBtn = e.target.closest('[data-public-server-open]');
                if (openBtn) {
                    const serverId = openBtn.getAttribute('data-public-server-open');
                    if (!serverId) return;
                    const server = (this.S.publicServers || []).find(item => String(item.id || '') === serverId);
                    if (!server) return;
                    if (this.normalizeMemberRole(server.myRole || server.my_role || '') === 'owner'
                        || this.normalizeMemberRole(server.myRole || server.my_role || '') === 'admin'
                        || this.normalizeMemberRole(server.myRole || server.my_role || '') === 'member') {
                        this.closeServerOverlay();
                        this.setActiveServer(serverId);
                        return;
                    }
                    await this.enterPublicServer(server.joinLink || server.join_link || server.id);
                    return;
                }
                const joinBtn = e.target.closest('[data-public-server-join]');
                if (joinBtn) {
                    await this.enterPublicServer(joinBtn.getAttribute('data-public-server-join'));
                }
            });
        }
        if (serverRoleCreateBtn) {
            serverRoleCreateBtn.addEventListener('click', async () => {
                try {
                    const mode = this.S.serverModal.mode;
                    await this.createServerRole();
                    this.addLogEntry({
                        type: 'SUCCESS',
                        msg: mode === 'create' ? 'Черновик роли добавлен' : 'Роль создана',
                        ts: new Date().toLocaleTimeString(),
                    });
                } catch (e) {
                    this.setServerModalState({ error: e?.message || 'Не удалось создать роль' });
                    this.renderServerModal();
                }
            });
        }
        const pickServerAsset = (kind) => {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'image/*';
            input.style.position = 'fixed';
            input.style.left = '-9999px';
            input.style.top = '0';
            document.body.appendChild(input);
            input.addEventListener('change', async () => {
                const file = input.files && input.files[0];
                input.remove();
                if (!file) return;
                try {
                    await this.uploadServerAsset(kind, file);
                    this.addLogEntry({ type: 'SUCCESS', msg: `${kind === 'avatar' ? 'Аватар' : 'Баннер'} сервера обновлён`, ts: new Date().toLocaleTimeString() });
                } catch (e) {
                    this.setServerModalState({ error: e?.message || 'Не удалось обновить медиа сервера' });
                    this.renderServerModal();
                }
            }, { once: true });
            input.click();
        };
        if (serverAvatarUploadBtn) serverAvatarUploadBtn.addEventListener('click', () => pickServerAsset('avatar'));
        if (serverBannerUploadBtn) serverBannerUploadBtn.addEventListener('click', () => pickServerAsset('banner'));
        if (serverAvatarRemoveBtn) {
            serverAvatarRemoveBtn.addEventListener('click', async () => {
                try {
                    await this.removeServerAsset('avatar');
                } catch (e) {
                    this.setServerModalState({ error: e?.message || 'Не удалось удалить аватар' });
                    this.renderServerModal();
                }
            });
        }
        if (serverBannerRemoveBtn) {
            serverBannerRemoveBtn.addEventListener('click', async () => {
                try {
                    await this.removeServerAsset('banner');
                } catch (e) {
                    this.setServerModalState({ error: e?.message || 'Не удалось удалить баннер' });
                    this.renderServerModal();
                }
            });
        }
        if (settingsLogoutBtn) settingsLogoutBtn.addEventListener('click', () => this.logout());
        if (avatarUploadBtn) {
            avatarUploadBtn.addEventListener('click', () => openAvatarPicker());
        }
        if (avatarResetBtn) {
            avatarResetBtn.addEventListener('click', async () => {
                try {
                    await this.resetProfileAvatar(this.myName());
                    this.addLogEntry({ type: 'SUCCESS', msg: 'Аватар профиля удалён', ts: new Date().toLocaleTimeString() });
                } catch (err) {
                    this.addLogEntry({ type: 'ERROR', msg: err?.message || 'Не удалось удалить аватар', ts: new Date().toLocaleTimeString() });
                }
            });
        }
        if (meAva) {
            meAva.title = 'Нажмите, чтобы сменить свой аватар';
            meAva.addEventListener('click', () => openAvatarPicker());
        }
        if (clearLogsBtn) {
            clearLogsBtn.addEventListener('click', () => {
                const logBody = document.getElementById('logBody');
                if (logBody) logBody.innerHTML = '';
            });
        }
        if (closeSettings) closeSettings.addEventListener('click', () => showChatView());
        if (networkConfigSaveBtn) {
            networkConfigSaveBtn.addEventListener('click', () => {
                let iceServers = [];
                try {
                    iceServers = this.parseIceServersText(inputIceServers?.value || '');
                } catch (error) {
                    this.addLogEntry({
                        type: 'ERROR',
                        msg: `Не удалось сохранить network config: ${error?.message || error}`,
                        ts: new Date().toLocaleTimeString(),
                    });
                    return;
                }
                const turnUrl = String(document.getElementById('inputTurnUrl')?.value || '').trim();
                if (turnUrl) {
                    try {
                        iceServers = this.appendTurnPresetToIceServers(iceServers);
                    } catch (error) {
                        this.addLogEntry({
                            type: 'ERROR',
                            msg: `Не удалось добавить TURN: ${error?.message || error}`,
                            ts: new Date().toLocaleTimeString(),
                        });
                        return;
                    }
                }
                this.setNetworkConfig({
                    apiBaseUrl: inputApiBaseUrl?.value || '',
                    wsBaseUrl: inputWsBaseUrl?.value || '',
                    iceServers,
                });
            });
        }
        if (networkConfigResetBtn) {
            networkConfigResetBtn.addEventListener('click', () => this.resetNetworkConfig());
        }
        if (networkTurnApplyBtn) {
            networkTurnApplyBtn.addEventListener('click', () => {
                try {
                    const nextIceServers = this.appendTurnPresetToIceServers(
                        this.parseIceServersText(inputIceServers?.value || '')
                    );
                    this.setNetworkConfig({
                        apiBaseUrl: inputApiBaseUrl?.value || '',
                        wsBaseUrl: inputWsBaseUrl?.value || '',
                        iceServers: nextIceServers,
                    });
                } catch (error) {
                    this.addLogEntry({
                        type: 'ERROR',
                        msg: `Не удалось добавить TURN: ${error?.message || error}`,
                        ts: new Date().toLocaleTimeString(),
                    });
                }
            });
        }
        if (networkTurnFillBtn) {
            networkTurnFillBtn.addEventListener('click', () => {
                const turnUrlInput = document.getElementById('inputTurnUrl');
                const turnUsernameInput = document.getElementById('inputTurnUsername');
                const turnCredentialInput = document.getElementById('inputTurnCredential');
                const turnRelayOnlyInput = document.getElementById('inputTurnRelayOnly');
                if (turnUrlInput) turnUrlInput.value = 'turns:turn.example.com:5349';
                if (turnUsernameInput) turnUsernameInput.value = 'user';
                if (turnCredentialInput) turnCredentialInput.value = 'pass';
                if (turnRelayOnlyInput) turnRelayOnlyInput.checked = true;
            });
        }

        this.bindColorWheel({
            wheelId: 'serverColorWheel',
            hiddenId: 'serverColorInput',
            hexId: 'serverColorHexInput',
            initialValue: '#cbff00',
        });
        this.bindColorWheel({
            wheelId: 'serverRoleColorWheel',
            hiddenId: 'serverRoleColorInput',
            hexId: 'serverRoleColorHexInput',
            initialValue: '#cbff00',
        });

        // 6. Dynamic styler selector events
        document.querySelectorAll('.btn-theme').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const themeName = e.target.getAttribute('data-theme');
                this.bus.send('zali_styler:set_theme', themeName);
            });
        });

        const serverMembersList = document.getElementById('serverMembersList');
        if (serverMembersList) {
            serverMembersList.addEventListener('change', async (e) => {
                const roleSelect = e.target.closest('select[data-member-role]');
                if (!roleSelect) return;
                const serverId = this.S.serverModal.serverId;
                const username = roleSelect.getAttribute('data-member-role');
                if (!serverId || !username) return;
                try {
                    const res = await this.apiFetch(`/api/servers/${encodeURIComponent(serverId)}/members/${encodeURIComponent(username)}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ username, role: roleSelect.value }),
                    });
                    if (!res.ok) {
                        throw new Error(await res.text() || 'Не удалось изменить роль');
                    }
                    const data = await res.json();
                    this.setServerModalState({
                        members: Array.isArray(data?.members) ? data.members : this.S.serverModal.members,
                        error: '',
                    });
                    this.renderServerModal();
                    await this.loadServers({ silent: true });
                } catch (err) {
                    this.setServerModalState({ error: err?.message || 'Не удалось изменить роль' });
                    this.renderServerModal();
                }
            });

            serverMembersList.addEventListener('click', async (e) => {
                const removeBtn = e.target.closest('[data-member-remove]');
                if (!removeBtn) return;
                const serverId = this.S.serverModal.serverId;
                const username = removeBtn.getAttribute('data-member-remove');
                if (!serverId || !username) return;
                try {
                    const res = await this.apiFetch(`/api/servers/${encodeURIComponent(serverId)}/members/${encodeURIComponent(username)}`, {
                        method: 'DELETE',
                    });
                    if (!res.ok && res.status !== 204) {
                        throw new Error(await res.text() || 'Не удалось удалить участника');
                    }
                    if (res.status === 204) {
                        this.setServerModalState({
                            members: (this.S.serverModal.members || []).filter(member => String(member.username || '') !== username),
                            error: '',
                        });
                        this.renderServerModal();
                        await this.loadServers({ silent: true });
                        return;
                    }
                    const data = await res.json();
                    this.setServerModalState({
                        members: Array.isArray(data?.members) ? data.members : this.S.serverModal.members,
                        error: '',
                    });
                    this.renderServerModal();
                    await this.loadServers({ silent: true });
                } catch (err) {
                    this.setServerModalState({ error: err?.message || 'Не удалось удалить участника' });
                    this.renderServerModal();
                }
            });
        }

        const serverRolesList = document.getElementById('serverRolesList');
        if (serverRolesList) {
            serverRolesList.addEventListener('input', () => {
                if (this.S.serverModal.mode !== 'create') return;
                this.syncDraftServerRolesFromDom();
            });
            serverRolesList.addEventListener('click', async (e) => {
                const draftToggleBtn = e.target.closest('[data-draft-role-toggle]');
                if (draftToggleBtn) {
                    if (this.S.serverModal.mode !== 'create') return;
                    const draftId = String(draftToggleBtn.getAttribute('data-draft-role-toggle') || '').trim();
                    if (!draftId) return;
                    const nextRoles = this.syncDraftServerRolesFromDom().map(role => {
                        if (String(role.draftId || '') !== draftId) return role;
                        return {
                            ...role,
                            collapsed: !role.collapsed,
                        };
                    });
                    this.setServerModalState({ draftRoles: nextRoles, error: '' });
                    this.renderServerModal();
                    return;
                }
                const draftHead = e.target.closest('.server-role-head--draft');
                if (draftHead) {
                    if (this.S.serverModal.mode !== 'create') return;
                    const card = draftHead.closest('[data-draft-role-card]');
                    const draftId = String(card?.getAttribute('data-draft-role-card') || '').trim();
                    if (!draftId) return;
                    const nextRoles = this.syncDraftServerRolesFromDom().map(role => {
                        if (String(role.draftId || '') !== draftId) return role;
                        return {
                            ...role,
                            collapsed: !role.collapsed,
                        };
                    });
                    this.setServerModalState({ draftRoles: nextRoles, error: '' });
                    this.renderServerModal();
                    return;
                }
                const draftDeleteBtn = e.target.closest('[data-draft-role-delete]');
                if (draftDeleteBtn) {
                    if (this.S.serverModal.mode !== 'create') return;
                    const draftId = String(draftDeleteBtn.getAttribute('data-draft-role-delete') || '').trim();
                    if (!draftId) return;
                    const nextRoles = this.syncDraftServerRolesFromDom().filter(role => String(role.draftId || '') !== draftId);
                    this.setServerModalState({ draftRoles: nextRoles, error: '' });
                    this.renderServerModal();
                    return;
                }
                const saveBtn = e.target.closest('[data-role-save]');
                if (saveBtn) {
                    const roleId = saveBtn.getAttribute('data-role-save');
                    try {
                        await this.saveServerRole(roleId);
                        this.addLogEntry({ type: 'SUCCESS', msg: `Роль обновлена: ${roleId}`, ts: new Date().toLocaleTimeString() });
                    } catch (err) {
                        this.setServerModalState({ error: err?.message || 'Не удалось сохранить роль' });
                        this.renderServerModal();
                    }
                    return;
                }
                const deleteBtn = e.target.closest('[data-role-delete]');
                if (deleteBtn) {
                    const roleId = deleteBtn.getAttribute('data-role-delete');
                    if (!roleId) return;
                    const role = (this.S.serverModal.roles || []).find(item => String(item.roleId || '') === roleId);
                    const confirmDelete = confirm(`Удалить роль "${role?.name || roleId}"?`);
                    if (!confirmDelete) return;
                    try {
                        await this.deleteServerRole(roleId);
                        this.addLogEntry({ type: 'SUCCESS', msg: `Роль удалена: ${role?.name || roleId}`, ts: new Date().toLocaleTimeString() });
                    } catch (err) {
                        this.setServerModalState({ error: err?.message || 'Не удалось удалить роль' });
                        this.renderServerModal();
                    }
                }
            });
        }

        const sliderRadius = document.getElementById('sliderRadius');
        if (sliderRadius) {
            sliderRadius.addEventListener('input', (e) => {
                const radius = e.target.value;
                const radiusValText = document.getElementById('radiusVal');
                if (radiusValText) radiusValText.textContent = `${radius}px`;
                this.bus.send('zali_styler:set_border_radius', radius);
            });
        }

        const sliderMsgGap = document.getElementById('sliderMsgGap');
        if (sliderMsgGap) {
            const currentMsgGap = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--msg-gap'), 10);
            if (!Number.isNaN(currentMsgGap)) {
                sliderMsgGap.value = String(currentMsgGap);
                const out = document.getElementById('msgGapVal');
                if (out) out.textContent = `${currentMsgGap}px`;
            }
            sliderMsgGap.addEventListener('input', (e) => {
                const gap = e.target.value;
                const out = document.getElementById('msgGapVal');
                if (out) out.textContent = `${gap}px`;
                this.bus.send('zali_styler:set_variable', '--msg-gap', gap);
            });
        }

        const sliderSuggestHeight = document.getElementById('sliderSuggestHeight');
        if (sliderSuggestHeight) {
            sliderSuggestHeight.addEventListener('input', (e) => {
                const height = `${e.target.value}px`;
                const out = document.getElementById('suggestHeightVal');
                if (out) out.textContent = height;
                this.bus.send('zali_styler:set_variable', '--contact-suggest-max-h', height);
            });
        }

        const sliderSuggestContrast = document.getElementById('sliderSuggestContrast');
        if (sliderSuggestContrast) {
            sliderSuggestContrast.addEventListener('input', (e) => {
                const percent = Number(e.target.value) || 0;
                const bgAlpha = Math.min(0.98, Math.max(0.72, 0.58 + (percent / 100) * 0.32));
                const borderAlpha = Math.min(0.95, Math.max(0.18, 0.08 + (percent / 100) * 0.28));
                const shadowAlpha = Math.min(0.65, Math.max(0.24, 0.12 + (percent / 100) * 0.5));
                const bg = `rgba(8,10,14,${bgAlpha.toFixed(3)})`;
                const border = `rgba(255,255,255,${borderAlpha.toFixed(3)})`;
                const shadow = `0 22px 48px rgba(0,0,0,${shadowAlpha.toFixed(3)})`;
                const out = document.getElementById('suggestContrastVal');
                if (out) out.textContent = `${percent}%`;
                this.bus.send('zali_styler:set_variable', '--contact-suggest-bg', bg);
                this.bus.send('zali_styler:set_variable', '--contact-suggest-border', border);
                this.bus.send('zali_styler:set_variable', '--contact-suggest-shadow', shadow);
            });
        }

        const sliderSuggestDensity = document.getElementById('sliderSuggestDensity');
        if (sliderSuggestDensity) {
            sliderSuggestDensity.addEventListener('input', (e) => {
                const density = Number(e.target.value) || 0;
                const padY = Math.max(8, 16 - Math.round(density / 3));
                const padX = Math.max(10, 16 - Math.round(density / 4));
                const gap = Math.max(4, 12 - Math.round(density / 3));
                const font = Math.min(16, 13 + Math.round(density / 8));
                const hint = Math.max(0.34, Math.min(0.72, 0.42 + density / 60));
                const out = document.getElementById('suggestDensityVal');
                if (out) out.textContent = String(density);
                this.bus.send('zali_styler:set_variable', '--contact-suggest-item-pad-y', `${padY}px`);
                this.bus.send('zali_styler:set_variable', '--contact-suggest-item-pad-x', `${padX}px`);
                this.bus.send('zali_styler:set_variable', '--contact-suggest-gap', `${gap}px`);
                this.bus.send('zali_styler:set_variable', '--contact-suggest-font', `${font}px`);
                this.bus.send('zali_styler:set_variable', '--contact-suggest-hint', `rgba(255,255,255,${hint.toFixed(3)})`);
            });
        }

        // 7. Cryptography setting custom key
        // Routes through zali_styler which proxies to Swift → Rust backend
        const inputCryptoKey = document.getElementById('inputCryptoKey');
        if (inputCryptoKey) {
            const storedKey = this.loadStoredCryptoKey();
            if (storedKey && !inputCryptoKey.value.trim()) {
                inputCryptoKey.value = storedKey;
            }
            inputCryptoKey.addEventListener('input', (e) => {
                const newKey = e.target.value.trim();
                this.saveStoredCryptoKey(newKey);
                this.bus.send('zali_styler:set_key', newKey);
            });
        }

        // 8. Title bar drag helper
        const titlebar = document.getElementById('titlebar');
        if (titlebar && this.nativeSupports('windowDrag')) {
            titlebar.addEventListener('mousedown', (e) => {
                if (!e.target.closest('.ws-pill') && !e.target.closest('.hdr-btn')) {
                    this.postNativeMessage({ type: 'START_DRAG' });
                }
            });
        }

        // Report app loaded
        this.addLogEntry({ type: 'INFO', msg: 'ZaliMessenger v6.0 (Rust Backend) запущен — шифрование и сетевой стек работают в Rust', ts: new Date().toLocaleTimeString() });
        this.resizeComposer();
    }
}
window.ZaliInterface = ZaliInterface;


// --- MODULE: bootstrap.js ---
(function() {
    'use strict';

    function createNativeBridge() {
        const macBridge = window.webkit?.messageHandlers?.nativeApp || null;
        const wryBridge = window.ipc?.postMessage ? window.ipc : null;
        const webView2Bridge = window.chrome?.webview?.postMessage ? window.chrome.webview : null;

        const transport = macBridge
            ? {
                kind: 'webkit',
                postMessage(payload) {
                    macBridge.postMessage(payload);
                    return true;
                },
            }
            : wryBridge
                ? {
                    kind: 'ipc',
                    postMessage(payload) {
                        const data = typeof payload === 'string' ? payload : JSON.stringify(payload);
                        wryBridge.postMessage(data);
                        return true;
                    },
                }
                : webView2Bridge
                    ? {
                        kind: 'webview2',
                        postMessage(payload) {
                            const data = typeof payload === 'string' ? payload : JSON.stringify(payload);
                            webView2Bridge.postMessage(data);
                            return true;
                        },
                    }
                    : null;

        const defaultCaps = macBridge
            ? {
                sendMessage: true,
                sessionSync: true,
                networkConfig: true,
                setKey: true,
                saveStyle: true,
                downloadAttachment: true,
                serverHistory: true,
                tenor: true,
                voice: true,
                windowDrag: true,
            }
            : transport
                ? {
                    sendMessage: true,
                    sessionSync: true,
                    networkConfig: true,
                    setKey: true,
                    saveStyle: true,
                    downloadAttachment: false,
                    serverHistory: false,
                    tenor: false,
                    voice: false,
                    windowDrag: false,
                }
                : {};

        const injectedCaps = window.__ZALI_NATIVE_CAPS__ && typeof window.__ZALI_NATIVE_CAPS__ === 'object'
            ? window.__ZALI_NATIVE_CAPS__
            : {};

        return {
            available: !!transport,
            transport: transport ? transport.kind : 'none',
            supports: { ...defaultCaps, ...injectedCaps },
            postMessage(payload) {
                if (!transport) return false;
                return transport.postMessage(payload);
            },
        };
    }

    window.__ZALI_NATIVE = createNativeBridge();

    // Create the minimal JS-side loader (only interface + styler)
    const loader = new ZaliLoader();

    // Register only frontend modules.
    // Crypto, Net, Bus logic live in the Rust backend (Core crate).
    loader.register(new ZaliStyler());
    loader.register(new ZaliInterface());

    // Initialize all registered modules
    loader.init();

    // Expose loader to window for native iOS/macOS WebView invocation
    window.loader = loader;
    
    // Legacy helper functions that native layer calls directly
    window.receiveMessage = function(...args) {
        if (args.length === 1 && args[0] && typeof args[0] === 'object') {
            loader.bus.send('zali_interface:receive_message', args[0]);
            return;
        }
        const [id, sender, receiver, text, attachments, serverId, channelId] = args;
        loader.bus.send('zali_interface:receive_message', { id, sender, receiver, text, attachments, serverId, channelId });
    };
    window.receiveReactionUpdate = function(payload) {
        loader.bus.send('zali_interface:reaction_updated', payload);
    };
    window.receiveVoiceEvent = function(payload) {
        loader.bus.send('zali_interface:voice_event', payload);
    };
    window.setUsers = function(users) {
        loader.bus.send('zali_interface:set_users', users);
    };
    window.setContacts = function(contacts) {
        loader.bus.send('zali_interface:set_contacts', contacts);
    };
    window.setSession = function(session) {
        loader.bus.send('zali_interface:set_session', session);
    };
    window.loadHistory = function(messages) {
        loader.bus.send('zali_interface:load_history', messages);
    };
    window.loadServerHistory = function(serverId, channelId, messages) {
        loader.bus.send('zali_interface:load_server_history', { serverId, channelId, messages });
    };
    window.setLoading = function(on) {
        loader.bus.send('zali_interface:set_loading', on);
    };
    window.setConnectionStatus = function(connected) {
        loader.bus.send('zali_interface:set_connection_status', connected);
    };
    window.avatarUpdated = function(username) {
        loader.bus.send('zali_interface:avatar_updated', { username, deleted: false });
    };
    window.avatarDeleted = function(username) {
        loader.bus.send('zali_interface:avatar_updated', { username, deleted: true });
    };
    window.addLog = function(type, msg) {
        loader.bus.send('zali_interface:add_log_entry', { type, msg, ts: new Date().toLocaleTimeString() });
    };

    const hasNativeBridge = !!window.__ZALI_NATIVE?.available;
    if (!hasNativeBridge) {
        loader.bus.send('zali_interface:set_users', ['Alice', 'Bob', 'Zalikus']);
        loader.bus.send('zali_interface:set_loading', false);
        loader.bus.send('zali_interface:set_connection_status', false);
        loader.bus.send('zali_interface:add_log_entry', {
            type: 'WARN',
            msg: 'Запущен браузерный режим без native bridge: доступен просмотр интерфейса',
            ts: new Date().toLocaleTimeString()
        });
    }
})();



</script>
</body>
</html>

"""#
}
