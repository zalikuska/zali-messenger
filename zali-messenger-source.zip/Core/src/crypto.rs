use crate::bus::ZaliBus;
use crate::loader::ZaliModule;
use base64::prelude::BASE64_STANDARD;
use base64::Engine;
use serde_json::json;

pub struct ZaliCrypto;

impl ZaliCrypto {
    pub(crate) fn djb2_hash(text: &str, key: &str) -> String {
        let mut hash: u32 = 5381;
        let combined = format!("{}{}", text, key);
        for c in combined.bytes() {
            hash = hash
                .wrapping_shl(5)
                .wrapping_add(hash)
                .wrapping_add(c as u32);
        }
        format!("{:08x}", hash)
    }

    pub(crate) fn xor_bytes(input: &[u8], key: &str) -> Vec<u8> {
        if key.is_empty() {
            return input.to_vec();
        }
        let key_bytes = key.as_bytes();
        let mut result = Vec::with_capacity(input.len());
        for (i, c) in input.iter().enumerate() {
            result.push(c ^ key_bytes[i % key_bytes.len()]);
        }
        result
    }
}

impl ZaliModule for ZaliCrypto {
    fn name(&self) -> &str {
        "zali_crypto"
    }

    fn init(&self, bus: &mut ZaliBus) -> Result<(), String> {
        // 1. zali_crypto:encrypt
        // Args: { "text": "...", "key": "..." }
        // Returns: { "ciphertext": "base64...", "signature": "hex..." }
        bus.register_command(
            "zali_crypto",
            "encrypt",
            Box::new(|args| {
                let text = args["text"].as_str().ok_or("Missing text parameter")?;
                let key = args["key"].as_str().ok_or("Missing key parameter")?;

                let xored = Self::xor_bytes(text.as_bytes(), key);
                let base64_cipher = BASE64_STANDARD.encode(xored);
                let signature = Self::djb2_hash(&base64_cipher, key);

                Ok(json!({
                    "ciphertext": base64_cipher,
                    "signature": signature
                }))
            }),
        );

        // 2. zali_crypto:decrypt
        // Args: { "ciphertext": "...", "signature": "...", "key": "..." }
        // Returns: { "text": "..." }
        bus.register_command(
            "zali_crypto",
            "decrypt",
            Box::new(|args| {
                let ciphertext = args["ciphertext"]
                    .as_str()
                    .ok_or("Missing ciphertext parameter")?;
                let signature = args["signature"]
                    .as_str()
                    .ok_or("Missing signature parameter")?;
                let key = args["key"].as_str().ok_or("Missing key parameter")?;

                // Verify signature first
                let expected_sig = Self::djb2_hash(ciphertext, key);
                if expected_sig != signature {
                    return Err(
                        "Tampering detected: DJB2 signature verification failed!".to_string()
                    );
                }

                // Decode base64
                let decoded_bytes = BASE64_STANDARD
                    .decode(ciphertext)
                    .map_err(|e| format!("Base64 decode error: {}", e))?;
                let plain_bytes = Self::xor_bytes(&decoded_bytes, key);
                let plain_text = String::from_utf8(plain_bytes)
                    .map_err(|e| format!("UTF-8 decode error: {}", e))?;

                Ok(json!({
                    "text": plain_text
                }))
            }),
        );

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::loader::ZaliLoader;

    #[test]
    fn encrypt_decrypt_preserves_unicode_text() {
        let mut loader = ZaliLoader::new();
        loader.register_module(ZaliCrypto).unwrap();

        let key = "ключ-секрет-2026";
        let text = "Привет, Zali! 🔐 Новая строка\nи emoji.";
        let encrypted = loader
            .bus
            .send("zali_crypto:encrypt", json!({ "text": text, "key": key }))
            .unwrap();

        let decrypted = loader
            .bus
            .send(
                "zali_crypto:decrypt",
                json!({
                    "ciphertext": encrypted["ciphertext"],
                    "signature": encrypted["signature"],
                    "key": key
                }),
            )
            .unwrap();

        assert_eq!(decrypted["text"].as_str(), Some(text));
    }
}
