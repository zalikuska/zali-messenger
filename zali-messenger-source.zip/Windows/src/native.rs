use base64::prelude::BASE64_STANDARD;
use base64::Engine;
use reqwest::multipart;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::ffi::CString;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};
use tokio::runtime::Runtime;
use uuid::Uuid;
use tao::event_loop::EventLoopProxy;

use zali_messenger_core::{zali_bus_dispatch, zali_bus_free_string};

#[derive(Debug, Clone)]
pub enum AppEvent {
    EvaluateScript(String),
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
struct PersistedConfig {
    api_base_url: Option<String>,
    ws_base_url: Option<String>,
}

#[derive(Debug, Clone)]
pub struct NativeState {
    pub api_base_url: Option<String>,
    pub ws_base_url: Option<String>,
    pub current_username: String,
    pub auth_token: Option<String>,
    pub current_key: String,
    pub saved_css: String,
    config_path: PathBuf,
    css_path: PathBuf,
}

impl NativeState {
    pub fn load() -> Self {
        let root = Self::app_data_dir();
        let _ = fs::create_dir_all(&root);
        let config_path = root.join("native_config.json");
        let css_path = root.join("custom_style.css");
        let persisted = Self::load_config(&config_path).unwrap_or_default();
        let saved_css = fs::read_to_string(&css_path).unwrap_or_default();

        Self {
            api_base_url: persisted.api_base_url,
            ws_base_url: persisted.ws_base_url,
            current_username: "Zalikus".to_string(),
            auth_token: None,
            current_key: "ZALI_SECRET_E2E_KEY_2026".to_string(),
            saved_css,
            config_path,
            css_path,
        }
    }

    fn app_data_dir() -> PathBuf {
        std::env::var_os("LOCALAPPDATA")
            .or_else(|| std::env::var_os("APPDATA"))
            .map(PathBuf::from)
            .unwrap_or_else(std::env::temp_dir)
            .join("ZaliMessenger")
    }

    fn load_config(path: &Path) -> Option<PersistedConfig> {
        let raw = fs::read_to_string(path).ok()?;
        serde_json::from_str(&raw).ok()
    }

    fn persist_config(&self) {
        let payload = PersistedConfig {
            api_base_url: self.api_base_url.clone(),
            ws_base_url: self.ws_base_url.clone(),
        };
        if let Ok(json) = serde_json::to_string_pretty(&payload) {
            let _ = fs::write(&self.config_path, json);
        }
    }

    fn persist_css(&self) {
        let _ = fs::write(&self.css_path, &self.saved_css);
    }

    pub fn initialization_script(&self) -> String {
        let mut script = String::new();

        let config = json!({
            "apiBaseUrl": self.api_base_url.clone().unwrap_or_default(),
            "wsBaseUrl": self.ws_base_url.clone().unwrap_or_default(),
        });
        if let Ok(json) = serde_json::to_string(&config) {
            script.push_str(&format!("window.__ZALI_CONFIG = {};\n", json));
        }

        if !self.saved_css.trim().is_empty() {
            if let Ok(json) = serde_json::to_string(&self.saved_css) {
                script.push_str(&format!("window.__ZALI_SAVED_CSS = {};\n", json));
            }
        }

        script
    }

    fn api_base_url(&self) -> String {
        self.api_base_url
            .clone()
            .filter(|value| !value.trim().is_empty())
            .or_else(|| std::env::var("ZALI_API_BASE_URL").ok().filter(|value| !value.trim().is_empty()))
            .unwrap_or_else(|| "http://localhost:3000".to_string())
    }
}

fn json_string_literal(value: &str) -> String {
    serde_json::to_string(value).unwrap_or_else(|_| "\"\"".to_string())
}

fn sanitize_file_name(name: &str, fallback_extension: &str) -> String {
    let cleaned: String = name
        .chars()
        .map(|ch| match ch {
            '/' | '\\' | ':' | '?' | '%' | '*' | '|' | '"' | '<' | '>' => '_',
            _ => ch,
        })
        .collect();

    let trimmed = cleaned.trim();
    if trimmed.is_empty() {
        format!("attachment.{fallback_extension}")
    } else {
        trimmed.to_string()
    }
}

fn decode_data_url(value: &str) -> Option<(Vec<u8>, String, String)> {
    let value = value.trim();
    if !value.starts_with("data:") {
        return None;
    }

    let comma = value.find(',')?;
    let meta = &value[5..comma];
    let payload = &value[comma + 1..];
    let mime_type = meta.split(';').next().unwrap_or("application/octet-stream").trim();
    let file_extension = match mime_type {
        "image/png" => "png",
        "image/jpeg" | "image/jpg" => "jpg",
        "image/gif" => "gif",
        "image/webp" => "webp",
        "video/mp4" => "mp4",
        "video/webm" => "webm",
        _ => "bin",
    };

    if meta.split(';').any(|part| part.trim().eq_ignore_ascii_case("base64")) {
        let bytes = BASE64_STANDARD.decode(payload).ok()?;
        return Some((bytes, mime_type.to_string(), file_extension.to_string()));
    }

    Some((payload.as_bytes().to_vec(), mime_type.to_string(), file_extension.to_string()))
}

fn dispatch_core_command(address_command: &str, args: Value) -> Result<Value, String> {
    let command = CString::new(address_command).map_err(|e| e.to_string())?;
    let args_str = CString::new(args.to_string()).map_err(|e| e.to_string())?;

    let response_ptr = unsafe { zali_bus_dispatch(command.as_ptr(), args_str.as_ptr()) };
    if response_ptr.is_null() {
        return Err("Rust core returned a null response".to_string());
    }

    let response = unsafe {
        let text = std::ffi::CStr::from_ptr(response_ptr)
            .to_string_lossy()
            .into_owned();
        zali_bus_free_string(response_ptr);
        text
    };

    serde_json::from_str(&response).map_err(|e| e.to_string())
}

fn pack_message(
    sender: &str,
    text: &str,
    key: &str,
    output_path: &Path,
    attachments: &[Value],
) -> Result<PathBuf, String> {
    let args = json!({
        "sender": sender,
        "text": text,
        "key": key,
        "output_path": output_path.to_string_lossy().to_string(),
        "attachments": attachments,
    });

    let response = dispatch_core_command("zali_net:pack_message", args)?;
    if response.get("success").and_then(Value::as_bool) == Some(true) {
        Ok(output_path.to_path_buf())
    } else {
        Err(response
            .get("error")
            .and_then(Value::as_str)
            .unwrap_or("Failed to pack message")
            .to_string())
    }
}

async fn upload_message(
    api_base_url: String,
    auth_token: Option<String>,
    sender: String,
    receiver: String,
    file_url: PathBuf,
    server_id: Option<String>,
    channel_id: Option<String>,
) -> Result<Option<String>, String> {
    let url = format!("{}/api/upload", api_base_url.trim_end_matches('/'));
    let file_data = tokio::fs::read(&file_url).await.map_err(|e| e.to_string())?;
    let client = reqwest::Client::new();

    let mut form = multipart::Form::new()
        .text("sender", sender)
        .text("receiver", receiver)
        .part("file", multipart::Part::bytes(file_data).file_name("msg.zali").mime_str("application/octet-stream").map_err(|e| e.to_string())?);

    if let (Some(server_id), Some(channel_id)) = (server_id, channel_id) {
        if !server_id.trim().is_empty() && !channel_id.trim().is_empty() {
            form = form
                .text("server_id", server_id)
                .text("channel_id", channel_id);
        }
    }

    let mut request = client.post(url).multipart(form);
    if let Some(token) = auth_token.filter(|value| !value.trim().is_empty()) {
        request = request.bearer_auth(token);
    }

    let response = request.send().await.map_err(|e| e.to_string())?;
    if !response.status().is_success() {
        return Err(format!("Upload failed with status {}", response.status()));
    }

    let message_id = match response.json::<Value>().await {
        Ok(json) => json.get("id").and_then(Value::as_str).map(|s| s.to_string()),
        Err(_) => None,
    };

    Ok(message_id)
}

fn script_eval_command(command: &str, payload: Value) -> String {
    let command_literal = json_string_literal(command);
    let payload_literal = payload.to_string();
    format!(
        "window.loader?.bus?.send({}, {});",
        command_literal,
        payload_literal
    )
}

fn dispatch_ui_event(proxy: &EventLoopProxy<AppEvent>, command: &str, payload: Value) {
    let _ = proxy.send_event(AppEvent::EvaluateScript(script_eval_command(command, payload)));
}

pub fn handle_ipc_message(
    message: String,
    state: Arc<Mutex<NativeState>>,
    runtime: Arc<Runtime>,
    proxy: EventLoopProxy<AppEvent>,
) {
    let parsed = serde_json::from_str::<Value>(&message).ok();
    let Some(payload) = parsed else {
        return;
    };

    let Some(kind) = payload.get("type").and_then(Value::as_str) else {
        return;
    };

    match kind {
        "SAVE_STYLE" => {
            if let Some(css) = payload.get("css").and_then(Value::as_str) {
                if let Ok(mut guard) = state.lock() {
                    guard.saved_css = css.to_string();
                    guard.persist_css();
                }
            }
        }
        "SET_KEY" => {
            if let Some(key) = payload.get("key").and_then(Value::as_str) {
                if let Ok(mut guard) = state.lock() {
                    guard.current_key = key.to_string();
                }
            }
        }
        "SET_SESSION" => {
            if let Ok(mut guard) = state.lock() {
                guard.current_username = payload
                    .get("username")
                    .and_then(Value::as_str)
                    .unwrap_or("Zalikus")
                    .to_string();
                let token = payload.get("token").and_then(Value::as_str).unwrap_or("").trim();
                guard.auth_token = if token.is_empty() { None } else { Some(token.to_string()) };
            }
        }
        "NETWORK_CONFIG" => {
            if let Ok(mut guard) = state.lock() {
                guard.api_base_url = payload
                    .get("apiBaseUrl")
                    .and_then(Value::as_str)
                    .map(|value| value.to_string())
                    .filter(|value| !value.trim().is_empty());
                guard.ws_base_url = payload
                    .get("wsBaseUrl")
                    .and_then(Value::as_str)
                    .map(|value| value.to_string())
                    .filter(|value| !value.trim().is_empty());
                guard.persist_config();
            }
        }
        "SEND_MESSAGE" => {
            let request = payload.clone();
            let state = Arc::clone(&state);
            let proxy = proxy.clone();
            runtime.spawn(async move {
                let snapshot = {
                    let guard = state.lock().ok();
                    let Some(guard) = guard else {
                        return;
                    };
                    (
                        guard.api_base_url(),
                        guard.auth_token.clone(),
                        guard.current_username.clone(),
                        guard.current_key.clone(),
                    )
                };

                let sender = request
                    .get("sender")
                    .and_then(Value::as_str)
                    .filter(|value| !value.trim().is_empty())
                    .unwrap_or(&snapshot.2)
                    .to_string();
                let receiver = request
                    .get("recipient")
                    .or_else(|| request.get("receiver"))
                    .and_then(Value::as_str)
                    .unwrap_or("")
                    .to_string();
                let text = request.get("text").and_then(Value::as_str).unwrap_or("").to_string();
                let key = request
                    .get("key")
                    .and_then(Value::as_str)
                    .filter(|value| !value.trim().is_empty())
                    .unwrap_or(&snapshot.3)
                    .to_string();
                let client_id = request
                    .get("clientId")
                    .and_then(Value::as_str)
                    .unwrap_or("")
                    .to_string();
                let server_id = request.get("serverId").and_then(Value::as_str).map(|value| value.to_string());
                let channel_id = request.get("channelId").and_then(Value::as_str).map(|value| value.to_string());

                let attachments = request
                    .get("attachments")
                    .and_then(Value::as_array)
                    .cloned()
                    .unwrap_or_default();

                let temp_dir = std::env::temp_dir().join("zali-messenger");
                let _ = tokio::fs::create_dir_all(&temp_dir).await;
                let archive_path = temp_dir.join(format!("{}.zali", Uuid::new_v4()));

                let mut packed_attachments = Vec::<Value>::new();
                let mut cleanup_paths = Vec::<PathBuf>::new();

                for attachment in attachments {
                    let Some(data_url) = attachment.get("dataUrl").and_then(Value::as_str) else {
                        continue;
                    };
                    let Some((data, mime_type, file_extension)) = decode_data_url(data_url) else {
                        continue;
                    };

                    let name = attachment
                        .get("name")
                        .and_then(Value::as_str)
                        .unwrap_or("attachment.bin");
                    let kind = attachment.get("kind").and_then(Value::as_str).unwrap_or("file");
                    let safe_name = sanitize_file_name(name, &file_extension);
                    let attachment_path = temp_dir.join(format!("{}_{}", Uuid::new_v4(), safe_name));

                    if tokio::fs::write(&attachment_path, data).await.is_ok() {
                        let size = if let Some(size) = attachment.get("size").and_then(Value::as_u64) {
                            size
                        } else {
                            tokio::fs::metadata(&attachment_path)
                                .await
                                .map(|meta| meta.len())
                                .unwrap_or(0)
                        };
                        packed_attachments.push(json!({
                            "path": attachment_path.to_string_lossy().to_string(),
                            "archivePath": format!("attachments/{}", safe_name),
                            "name": name,
                            "mimeType": attachment.get("mimeType").and_then(Value::as_str).unwrap_or(&mime_type),
                            "kind": kind,
                            "size": size,
                        }));
                        cleanup_paths.push(attachment_path);
                    }
                }

                let pack_result = pack_message(&sender, &text, &key, &archive_path, &packed_attachments);
                if let Err(error) = pack_result {
                    dispatch_ui_event(
                        &proxy,
                        "zali_interface:on_send_error",
                        Value::String(client_id),
                    );
                    let log = format!("window.addLog({}, {});",
                        json_string_literal("ERROR"),
                        json_string_literal(&format!("Core: {}", error))
                    );
                    let _ = proxy.send_event(AppEvent::EvaluateScript(log));
                    for path in cleanup_paths {
                        let _ = tokio::fs::remove_file(path).await;
                    }
                    let _ = tokio::fs::remove_file(&archive_path).await;
                    return;
                }

                let upload_result = upload_message(
                    snapshot.0,
                    snapshot.1,
                    sender.clone(),
                    receiver,
                    archive_path.clone(),
                    server_id,
                    channel_id,
                ).await;

                match upload_result {
                    Ok(message_id) => {
                        let payload = json!({
                            "clientId": client_id,
                            "messageId": message_id.unwrap_or_default(),
                        });
                        dispatch_ui_event(&proxy, "zali_interface:on_send_success", payload);
                    }
                    Err(error) => {
                        dispatch_ui_event(
                            &proxy,
                            "zali_interface:on_send_error",
                            Value::String(client_id.clone()),
                        );
                        let log = format!("window.addLog({}, {});",
                            json_string_literal("ERROR"),
                            json_string_literal(&format!("Network: {}", error))
                        );
                        let _ = proxy.send_event(AppEvent::EvaluateScript(log));
                    }
                }

                for path in cleanup_paths {
                    let _ = tokio::fs::remove_file(path).await;
                }
                let _ = tokio::fs::remove_file(&archive_path).await;
            });
        }
        "START_DRAG" => {
            // Windows keeps the standard title bar, so this is a no-op.
        }
        _ => {}
    }
}
