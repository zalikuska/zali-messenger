param(
    [switch]$Run
)

$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

Write-Host "Bundling web assets..."
python .\bundle_web.py

Write-Host "Building Windows client..."
cargo build --release --manifest-path .\Windows\Cargo.toml

if ($Run) {
    $exe = Join-Path $PSScriptRoot 'Windows\target\release\zali_messenger_win.exe'
    if (-not (Test-Path $exe)) {
        throw "Expected executable not found: $exe"
    }

    Write-Host "Launching Windows client..."
    & $exe
}
