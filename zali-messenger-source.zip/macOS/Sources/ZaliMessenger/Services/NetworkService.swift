import Foundation

class NetworkService: NSObject, URLSessionWebSocketDelegate {
    static let shared = NetworkService()
    
    private let connectionQueue = DispatchQueue(label: "zali.network.websocket")
    private let configQueue = DispatchQueue(label: "zali.network.config")
    private let apiBaseURLStorageKey = "zali_network_api_base_url"
    private let wsBaseURLStorageKey = "zali_network_ws_base_url"
    
    private var webSocketTask: URLSessionWebSocketTask?
    // Separate session for WebSocket (needs delegate); shared session for HTTP requests
    private var wsSession: URLSession?
    private let httpSession = URLSession.shared
    private var configuredServerURL: String?
    private var configuredWSBaseURL: String?
    private var authToken: String?
    private var currentUsername: String = "Zalikus"
    private var connectionGeneration: Int = 0
    private var reconnectWorkItem: DispatchWorkItem?
    
    // Callback to notify UI when a message is successfully received and unpacked
    var onMessageReceived: ((_ id: String, _ sender: String, _ receiver: String, _ text: String, _ attachments: [[String: Any]], _ serverId: String?, _ channelId: String?) -> Void)?
    var onReactionUpdated: ((_ payload: [String: Any]) -> Void)?
    var onAvatarChanged: ((_ username: String, _ deleted: Bool) -> Void)?
    var onVoiceEvent: ((_ payload: [String: Any]) -> Void)?
    var currentKey: String = "ZALI_SECRET_E2E_KEY_2026"

    var currentUser: String {
        currentUsername
    }

    private var serverURL: String {
        if let configured = configQueue.sync(execute: { configuredServerURL }), !configured.isEmpty {
            return configured
        }
        if let stored = normalizedBaseURL(UserDefaults.standard.string(forKey: apiBaseURLStorageKey)) {
            return stored
        }
        let env = ProcessInfo.processInfo.environment
        if let value = normalizedBaseURL(env["ZALI_API_BASE_URL"]) {
            return value
        }
        return "http://localhost:3000"
    }

    private var wsBaseURL: String {
        if let configured = configQueue.sync(execute: { configuredWSBaseURL }), !configured.isEmpty {
            return configured
        }
        if let apiBaseURL = configQueue.sync(execute: { configuredServerURL }), !apiBaseURL.isEmpty {
            if apiBaseURL.hasPrefix("https://") {
                return apiBaseURL.replacingOccurrences(of: "https://", with: "wss://") + "/ws"
            }
            if apiBaseURL.hasPrefix("http://") {
                return apiBaseURL.replacingOccurrences(of: "http://", with: "ws://") + "/ws"
            }
        }
        if let stored = normalizedWebSocketURL(UserDefaults.standard.string(forKey: wsBaseURLStorageKey)) {
            return stored
        }
        let env = ProcessInfo.processInfo.environment
        if let value = normalizedWebSocketURL(env["ZALI_WS_BASE_URL"]) {
            return value
        }
        if let apiBaseURL = normalizedBaseURL(env["ZALI_API_BASE_URL"]) {
            if apiBaseURL.hasPrefix("https://") {
                return apiBaseURL.replacingOccurrences(of: "https://", with: "wss://") + "/ws"
            }
            if apiBaseURL.hasPrefix("http://") {
                return apiBaseURL.replacingOccurrences(of: "http://", with: "ws://") + "/ws"
            }
        }
        return "ws://localhost:3000/ws"
    }

    private func normalizedBaseURL(_ value: String?) -> String? {
        let trimmed = value?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard !trimmed.isEmpty else { return nil }
        return trimmed.replacingOccurrences(of: #"/+$"#, with: "", options: .regularExpression)
    }

    private func normalizedWebSocketURL(_ value: String?) -> String? {
        let trimmed = value?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard !trimmed.isEmpty else { return nil }
        return trimmed.replacingOccurrences(of: #"/+$"#, with: "", options: .regularExpression)
    }
    
    func start() {
        connectWebSocket()
    }

    func configure(apiBaseURL: String?, wsBaseURL: String?) {
        let normalizedAPI = normalizedBaseURL(apiBaseURL)
        let normalizedWS = normalizedWebSocketURL(wsBaseURL)
        print("[VOICE][NET] configure api=\(normalizedAPI ?? "nil") ws=\(normalizedWS ?? "nil")")
        configQueue.sync {
            configuredServerURL = normalizedAPI
            configuredWSBaseURL = normalizedWS
        }
        if let normalizedAPI {
            UserDefaults.standard.set(normalizedAPI, forKey: apiBaseURLStorageKey)
        } else {
            UserDefaults.standard.removeObject(forKey: apiBaseURLStorageKey)
        }
        if let normalizedWS {
            UserDefaults.standard.set(normalizedWS, forKey: wsBaseURLStorageKey)
        } else {
            UserDefaults.standard.removeObject(forKey: wsBaseURLStorageKey)
        }
        connectWebSocket()
    }

    func setSession(username: String, token: String?, completion: (() -> Void)? = nil) {
        connectionQueue.async { [weak self] in
            guard let self else { return }
            self.currentUsername = username.isEmpty ? "Zalikus" : username
            self.authToken = token?.isEmpty == false ? token : nil
            print("[VOICE][NET] setSession user=\(self.currentUsername) hasToken=\(self.authToken != nil)")
            self.connectWebSocketLocked()
            if let completion {
                DispatchQueue.main.async {
                    completion()
                }
            }
        }
    }
    
    private func connectWebSocket() {
        connectionQueue.async { [weak self] in
            self?.connectWebSocketLocked()
        }
    }

    private func connectWebSocketLocked() {
        reconnectWorkItem?.cancel()
        reconnectWorkItem = nil
        connectionGeneration += 1
        let generation = connectionGeneration

        let urlString: String
        if let authToken, !authToken.isEmpty, let encoded = authToken.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) {
            urlString = "\(wsBaseURL)?token=\(encoded)"
        } else {
            urlString = wsBaseURL
        }

        guard let url = URL(string: urlString) else { return }
        print("[VOICE][NET] ws connect generation=\(generation) url=\(urlString)")
        // Cancel the previous task, but keep the old session object alive until the system releases it.
        webSocketTask?.cancel(with: .goingAway, reason: nil)
        let config = URLSessionConfiguration.default
        let newSession = URLSession(configuration: config, delegate: self, delegateQueue: nil)
        wsSession = newSession
        webSocketTask = newSession.webSocketTask(with: url)
        webSocketTask?.resume()
        
        listenWebSocket(generation: generation)
    }

    func sendWebSocketJSON(_ payload: [String: Any], completion: ((Bool) -> Void)? = nil) {
        connectionQueue.async { [weak self] in
            guard let self else {
                completion?(false)
                return
            }

            guard let task = self.webSocketTask else {
                completion?(false)
                return
            }

            guard let data = try? JSONSerialization.data(withJSONObject: payload, options: []),
                  let text = String(data: data, encoding: .utf8) else {
                completion?(false)
                return
            }

            task.send(.string(text)) { error in
                if let error = error {
                    print("[VOICE][NET] ws send error: \(error)")
                    completion?(false)
                } else {
                    completion?(true)
                }
            }
        }
    }
    
    private func scheduleReconnect(reason: String, generation: Int) {
        connectionQueue.async { [weak self] in
            guard let self else { return }
            guard generation == self.connectionGeneration else { return }

            self.reconnectWorkItem?.cancel()
            let workItem = DispatchWorkItem { [weak self] in
                guard let self else { return }
                guard generation == self.connectionGeneration else { return }
                self.connectWebSocketLocked()
            }
            self.reconnectWorkItem = workItem
            print("[VOICE][NET] ws reconnect scheduled reason=\(reason)")
            self.connectionQueue.asyncAfter(deadline: .now() + 3.0, execute: workItem)
        }
    }

    private func listenWebSocket(generation: Int) {
        webSocketTask?.receive { [weak self] result in
            guard let self else { return }
            guard generation == self.connectionGeneration else { return }
            switch result {
            case .success(let message):
                switch message {
                case .string(let text):
                    if let data = text.data(using: .utf8),
                       let raw = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                       let eventType = raw["type"] as? String,
                       eventType.hasPrefix("voice_") {
                        print("[VOICE][NET][IN] type=\(eventType) roomId=\(raw["roomId"] as? String ?? "") from=\(raw["from"] as? String ?? "") target=\(raw["target"] as? String ?? "")")
                    }
                    self.handleWebSocketMessage(text)
                case .data(let data):
                    if let text = String(data: data, encoding: .utf8) {
                        if let rawData = text.data(using: .utf8),
                           let raw = try? JSONSerialization.jsonObject(with: rawData) as? [String: Any],
                           let eventType = raw["type"] as? String,
                           eventType.hasPrefix("voice_") {
                            print("[VOICE][NET][IN] type=\(eventType) roomId=\(raw["roomId"] as? String ?? "") from=\(raw["from"] as? String ?? "") target=\(raw["target"] as? String ?? "")")
                        }
                        self.handleWebSocketMessage(text)
                    }
                @unknown default:
                    break
                }
                self.listenWebSocket(generation: generation) // Keep listening
            case .failure(let error):
                print("[VOICE][NET] ws connection error: \(error). Reconnecting in 3 seconds...")
                self.scheduleReconnect(reason: "receive failure", generation: generation)
            }
        }
    }
    
    private func handleWebSocketMessage(_ jsonString: String) {
        struct AvatarEvent: Codable {
            let type: String
            let username: String
            let deleted: Bool?
        }

        struct WsMessage: Codable {
            let id: String
            let sender: String
            let receiver: String
            let filename: String
            let serverId: String?
            let channelId: String?
            let server_id: String?
            let channel_id: String?
        }
        
        guard let data = jsonString.data(using: .utf8),
              let raw = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            return
        }

        if let eventType = raw["type"] as? String,
           eventType == "avatar_updated" || eventType == "avatar_deleted",
           let avatarEvent = try? JSONDecoder().decode(AvatarEvent.self, from: data) {
            DispatchQueue.main.async {
                self.onAvatarChanged?(avatarEvent.username, avatarEvent.deleted ?? (eventType == "avatar_deleted"))
            }
            return
        }

        if let eventType = raw["type"] as? String, eventType == "reaction_updated" {
            DispatchQueue.main.async {
                self.onReactionUpdated?(raw)
            }
            return
        }

        if let eventType = raw["type"] as? String, eventType.hasPrefix("voice_") {
            print("[VOICE][NET][DISPATCH] type=\(eventType) roomId=\(raw["roomId"] as? String ?? "") from=\(raw["from"] as? String ?? "") target=\(raw["target"] as? String ?? "")")
            DispatchQueue.main.async {
                self.onVoiceEvent?(raw)
            }
            return
        }

        guard let wsMsg = try? JSONDecoder().decode(WsMessage.self, from: data) else {
            return
        }
        
        let serverId = wsMsg.serverId ?? wsMsg.server_id
        let channelId = wsMsg.channelId ?? wsMsg.channel_id

        // Server messages are broadcast to all connected clients.
        // DM messages still only matter for the current user as receiver.
        if serverId != nil || wsMsg.receiver == currentUsername {
            downloadMessage(messageId: wsMsg.id) { [weak self] fileURL in
                guard let fileURL = fileURL else { return }
                
                // Temp directory for unpacking
                let tempDirName = UUID().uuidString
                let tempDir = (NSTemporaryDirectory() as NSString).appendingPathComponent(tempDirName)
                try? FileManager.default.createDirectory(atPath: tempDir, withIntermediateDirectories: true)
                
                if let unpacked = ZaliCore.shared.unpackMessage(archivePath: fileURL.path, tempDir: tempDir, key: self?.currentKey ?? "ZALI_SECRET_E2E_KEY_2026") {
                    let renderedAttachments = (unpacked.attachments ?? []).compactMap { attachment -> [String: Any]? in
                        let attachmentURL = URL(fileURLWithPath: tempDir).appendingPathComponent(attachment.archivePath)
                        guard let data = try? Data(contentsOf: attachmentURL) else { return nil }

                        return [
                            "name": attachment.name,
                            "mimeType": attachment.mimeType,
                            "kind": attachment.kind,
                            "size": attachment.size,
                            "dataUrl": Self.makeDataURL(data: data, mimeType: attachment.mimeType)
                        ]
                    }

                    DispatchQueue.main.async {
                        self?.onMessageReceived?(wsMsg.id, unpacked.sender, wsMsg.receiver, unpacked.text, renderedAttachments, serverId, channelId)
                    }
                }
                
                // Cleanup
                try? FileManager.default.removeItem(at: fileURL)
                try? FileManager.default.removeItem(atPath: tempDir)
            }
        }
    }
    
    func uploadMessage(sender: String, receiver: String, fileURL: URL, serverId: String? = nil, channelId: String? = nil, completion: @escaping (Bool, String?) -> Void) {
        guard let uploadURL = URL(string: "\(serverURL)/api/upload") else {
            completion(false, nil)
            return
        }
        
        var request = URLRequest(url: uploadURL)
        request.httpMethod = "POST"
        if let authToken, !authToken.isEmpty {
            request.setValue("Bearer \(authToken)", forHTTPHeaderField: "Authorization")
        }
        
        let boundary = "Boundary-\(UUID().uuidString)"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        guard let fileData = try? Data(contentsOf: fileURL) else {
            completion(false, nil)
            return
        }
        
        var body = Data()
        
        // Add sender field
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"sender\"\r\n\r\n".data(using: .utf8)!)
        body.append(sender.data(using: .utf8)!)
        body.append("\r\n".data(using: .utf8)!)
        
        // Add receiver field
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"receiver\"\r\n\r\n".data(using: .utf8)!)
        body.append(receiver.data(using: .utf8)!)
        body.append("\r\n".data(using: .utf8)!)

        if let serverId, !serverId.isEmpty, let channelId, !channelId.isEmpty {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"server_id\"\r\n\r\n".data(using: .utf8)!)
            body.append(serverId.data(using: .utf8)!)
            body.append("\r\n".data(using: .utf8)!)

            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"channel_id\"\r\n\r\n".data(using: .utf8)!)
            body.append(channelId.data(using: .utf8)!)
            body.append("\r\n".data(using: .utf8)!)
        }
        
        // Add file field
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"file\"; filename=\"msg.zali\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: application/octet-stream\r\n\r\n".data(using: .utf8)!)
        body.append(fileData)
        body.append("\r\n".data(using: .utf8)!)
        
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        
        request.httpBody = body
        
        httpSession.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Upload failed: \(error)")
                completion(false, nil)
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 201 {
                let messageId: String? = {
                    guard let data else { return nil }
                    guard let json = try? JSONSerialization.jsonObject(with: data, options: []),
                          let dict = json as? [String: Any] else {
                        return nil
                    }
                    return dict["id"] as? String
                }()
                completion(true, messageId)
            } else {
                completion(false, nil)
            }
        }.resume()
    }

    func fetchUsers(completion: @escaping ([String]) -> Void) {
        guard let usersURL = URL(string: "\(serverURL)/api/users") else {
            completion(["Alice", "Bob", currentUsername])
            return
        }

        var request = URLRequest(url: usersURL)
        if let authToken, !authToken.isEmpty {
            request.setValue("Bearer \(authToken)", forHTTPHeaderField: "Authorization")
        }

        httpSession.dataTask(with: request) { data, response, error in
            guard error == nil,
                  let httpResponse = response as? HTTPURLResponse,
                  (200..<300).contains(httpResponse.statusCode),
                  let data = data,
                  let users = try? JSONDecoder().decode([String].self, from: data) else {
                completion(["Alice", "Bob", self.currentUsername])
                return
            }

            completion(users)
        }.resume()
    }

    func fetchContacts(completion: @escaping ([String]) -> Void) {
        guard let contactsURL = URL(string: "\(serverURL)/api/contacts") else {
            completion([])
            return
        }

        var request = URLRequest(url: contactsURL)
        if let authToken, !authToken.isEmpty {
            request.setValue("Bearer \(authToken)", forHTTPHeaderField: "Authorization")
        }

        httpSession.dataTask(with: request) { data, response, error in
            guard error == nil,
                  let httpResponse = response as? HTTPURLResponse,
                  (200..<300).contains(httpResponse.statusCode),
                  let data = data,
                  let payload = try? JSONDecoder().decode([String: [String]].self, from: data) else {
                completion([])
                return
            }

            completion(payload["contacts"] ?? [])
        }.resume()
    }

    struct RemoteMessageRecord: Codable {
        let id: String
        let sender: String
        let receiver: String
        let filename: String
        let timestamp: String
        let serverId: String?
        let channelId: String?
        let server_id: String?
        let channel_id: String?
        let reactions: [RemoteReactionSummary]?
        let myReaction: String?
    }

    struct RemoteReactionSummary: Codable {
        let emoji: String
        let count: Int
    }

    func fetchMessages(for user: String, completion: @escaping ([RemoteMessageRecord]) -> Void) {
        guard let messagesURL = URL(string: "\(serverURL)/api/messages/\(user.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? user)") else {
            completion([])
            return
        }

        var request = URLRequest(url: messagesURL)
        if let authToken, !authToken.isEmpty {
            request.setValue("Bearer \(authToken)", forHTTPHeaderField: "Authorization")
        }

        httpSession.dataTask(with: request) { data, response, error in
            guard error == nil,
                  let httpResponse = response as? HTTPURLResponse,
                  (200..<300).contains(httpResponse.statusCode),
                  let data = data else {
                completion([])
                return
            }

            let decoder = JSONDecoder()
            if let messages = try? decoder.decode([RemoteMessageRecord].self, from: data) {
                completion(messages)
            } else {
                completion([])
            }
        }.resume()
    }

    func fetchServerMessages(serverId: String, channelId: String, completion: @escaping ([RemoteMessageRecord]) -> Void) {
        let sid = serverId.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? serverId
        let cid = channelId.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? channelId
        guard let messagesURL = URL(string: "\(serverURL)/api/servers/\(sid)/channels/\(cid)/messages") else {
            completion([])
            return
        }

        var request = URLRequest(url: messagesURL)
        if let authToken, !authToken.isEmpty {
            request.setValue("Bearer \(authToken)", forHTTPHeaderField: "Authorization")
        }

        httpSession.dataTask(with: request) { data, response, error in
            guard error == nil,
                  let httpResponse = response as? HTTPURLResponse,
                  (200..<300).contains(httpResponse.statusCode),
                  let data = data else {
                completion([])
                return
            }

            let decoder = JSONDecoder()
            if let messages = try? decoder.decode([RemoteMessageRecord].self, from: data) {
                completion(messages)
            } else {
                completion([])
            }
        }.resume()
    }
    
    func downloadMessage(messageId: String, completion: @escaping (URL?) -> Void) {
        guard let downloadURL = URL(string: "\(serverURL)/api/download/\(messageId)") else {
            completion(nil)
            return
        }

        var request = URLRequest(url: downloadURL)
        if let authToken, !authToken.isEmpty {
            request.setValue("Bearer \(authToken)", forHTTPHeaderField: "Authorization")
        }

        httpSession.dataTask(with: request) { data, response, error in
            guard let httpResponse = response as? HTTPURLResponse,
                  (200..<300).contains(httpResponse.statusCode),
                  let data = data,
                  error == nil else {
                completion(nil)
                return
            }
            
            let tempFileURL = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("\(messageId).zali")
            do {
                try data.write(to: tempFileURL)
                completion(tempFileURL)
            } catch {
                print("Failed to save downloaded file: \(error)")
                completion(nil)
            }
        }.resume()
    }

    private static func makeDataURL(data: Data, mimeType: String) -> String {
        let base64 = data.base64EncodedString()
        return "data:\(mimeType);base64,\(base64)"
    }
    
    func urlSession(_ session: URLSession, webSocketTask: URLSessionWebSocketTask, didCloseWith closeCode: URLSessionWebSocketTask.CloseCode, reason: Data?) {
        print("WebSocket closed, reconnecting...")
        connectionQueue.async { [weak self] in
            guard let self else { return }
            self.scheduleReconnect(reason: "didCloseWith", generation: self.connectionGeneration)
        }
    }
}
