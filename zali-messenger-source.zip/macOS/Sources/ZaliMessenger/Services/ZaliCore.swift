import Foundation
import CoreBridge

class ZaliCore {
    static let shared = ZaliCore()

    struct AttachmentPayload: Codable {
        let name: String
        let archivePath: String
        let mimeType: String
        let kind: String
        let size: UInt64
    }

    struct MessagePayload: Codable {
        let sender: String
        let text: String
        let timestamp: UInt64
        let attachments: [AttachmentPayload]?
    }
    
    /// Sends a JSON-serialized command payload to the Rust ZaliBus and returns the result.
    func dispatch(addressCommand: String, args: [String: Any]) -> [String: Any]? {
        guard let argsData = try? JSONSerialization.data(withJSONObject: args, options: []),
              let argsStr = String(data: argsData, encoding: .utf8) else {
            return ["success": false, "error": "Failed to serialize arguments to JSON"]
        }
        
        guard let cResult = zali_bus_dispatch(addressCommand, argsStr) else {
            return nil
        }
        defer {
            zali_bus_free_string(cResult)
        }
        
        let resultStr = String(cString: cResult)
        guard let resultData = resultStr.data(using: .utf8),
              let dict = try? JSONSerialization.jsonObject(with: resultData, options: []) as? [String: Any] else {
            return ["success": false, "error": "Failed to parse JSON result from bus"]
        }
        
        return dict
    }
    
    func packMessage(
        sender: String,
        text: String,
        output: String,
        key: String = "ZALI_SECRET_E2E_KEY_2026",
        attachments: [[String: Any]] = []
    ) -> Bool {
        var args: [String: Any] = [
            "sender": sender,
            "text": text,
            "key": key,
            "output_path": output
        ]
        if !attachments.isEmpty {
            args["attachments"] = attachments
        }
        if let result = dispatch(addressCommand: "zali_net:pack_message", args: args),
           let success = result["success"] as? Bool {
            return success
        }
        return false
    }
    
    func unpackMessage(archivePath: String, tempDir: String, key: String = "ZALI_SECRET_E2E_KEY_2026") -> MessagePayload? {
        let args: [String: Any] = [
            "archive_path": archivePath,
            "temp_dir": tempDir,
            "key": key
        ]
        if let result = dispatch(addressCommand: "zali_net:unpack_message", args: args),
           let success = result["success"] as? Bool, success,
           let data = result["data"] {
            guard let json = try? JSONSerialization.data(withJSONObject: data, options: []),
                  let payload = try? JSONDecoder().decode(MessagePayload.self, from: json) else {
                return nil
            }
            return payload
        }
        return nil
    }
}
